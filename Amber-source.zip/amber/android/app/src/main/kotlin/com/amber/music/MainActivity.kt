package com.amber.music

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

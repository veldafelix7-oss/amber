package com.amber.music

import android.content.ContentUris
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Jembatan native Amber.
 *
 * Semua bagian berat (baca daftar lagu dari MediaStore, ambil cover, catat
 * crash) dikerjakan di sini, dengan tiga prinsip:
 *
 *  1. TIDAK memakai plugin pihak ketiga untuk baca MediaStore. Query-nya kecil,
 *     dibagi per halaman (offset/limit), jadi ribuan lagu pun tidak
 *     menghabiskan memori sekaligus.
 *  2. TIDAK menyentuh izin foto sama sekali (cover dibaca dari dalam file).
 *  3. Setiap langkah dibungkus try/catch + jalan di thread terpisah. Kalau
 *     gagal, yang dikembalikan null/kosong — proses app tidak ikut mati.
 *
 * Kalau app tetap mati, "kotak hitam" (uncaught exception handler) menulis
 * file amber-crash.txt ke folder Download, bisa dibuka pakai File Manager.
 */
class MainActivity : FlutterActivity() {

    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        installCrashLogger()
        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "amber/media")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "querySongs" -> {
                        val offset = call.argument<Int>("offset") ?: 0
                        val limit = call.argument<Int>("limit") ?: 400
                        val minDuration = call.argument<Int>("minDurationMs") ?: 0
                        worker.execute {
                            val rows: List<Map<String, Any?>> = try {
                                querySongs(offset, limit, minDuration)
                            } catch (t: Throwable) {
                                emptyList()
                            }
                            runOnUiThread { result.success(rows) }
                        }
                    }
                    "embeddedArt" -> {
                        val path = call.argument<String>("path")
                        val maxSize = call.argument<Int>("maxSize") ?: 300
                        if (path.isNullOrEmpty()) {
                            result.success(null)
                            return@setMethodCallHandler
                        }
                        worker.execute {
                            val bytes: ByteArray? = try {
                                extractEmbeddedArt(path, maxSize)
                            } catch (t: Throwable) {
                                null
                            }
                            runOnUiThread { result.success(bytes) }
                        }
                    }
                    "readCrashLog" -> result.success(readCrashLog())
                    "clearCrashLog" -> {
                        try {
                            File(filesDir, CRASH_FILE).delete()
                        } catch (_: Throwable) {
                        }
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // ------------------------------------------------------------- MediaStore

    private fun querySongs(offset: Int, limit: Int, minDurationMs: Int): List<Map<String, Any?>> {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val args = arrayOf(minDurationMs.toString())
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        val rows = ArrayList<Map<String, Any?>>(limit)
        val cursor = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            args,
            sortOrder,
        ) ?: return rows

        try {
            if (!cursor.moveToPosition(offset)) return rows
            var taken = 0
            while (taken < limit) {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID))
                val title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE))
                    ?: ""
                val artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)) ?: ""
                val album = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)) ?: ""
                val albumId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID))
                val duration = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION))
                val size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE))
                val dateAdded = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED))
                val trackNo = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK))
                val data = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)) ?: ""
                val displayName =
                    cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)) ?: ""

                val path = when {
                    data.isNotEmpty() -> data
                    else -> try {
                        ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            id,
                        ).toString()
                    } catch (_: Throwable) {
                        ""
                    }
                }

                rows.add(
                    mapOf(
                        "id" to id,
                        "title" to title,
                        "artist" to artist,
                        "album" to album,
                        "albumId" to albumId,
                        "duration" to duration,
                        "size" to size,
                        "dateAdded" to dateAdded,
                        "track" to trackNo,
                        "path" to path,
                        "displayName" to displayName,
                    ),
                )
                taken++
                if (!cursor.moveToNext()) break
            }
        } finally {
            try {
                cursor.close()
            } catch (_: Throwable) {
            }
        }
        return rows
    }

    // ---------------------------------------------------------------- artwork

    private fun extractEmbeddedArt(path: String, maxSize: Int): ByteArray? {
        if (!path.startsWith("/")) return null
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(path)
            val raw = retriever.embeddedPicture ?: return null
            if (raw.isEmpty() || raw.size > 12 * 1024 * 1024) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            val longest = maxOf(bounds.outWidth, bounds.outHeight)
            while (longest / (sample * 2) >= maxSize) sample *= 2

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = BitmapFactory.decodeByteArray(raw, 0, raw.size, decodeOptions) ?: return null

            val scaled = scaleDown(decoded, maxSize)
            val output = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, output)
            if (scaled !== decoded) scaled.recycle()
            decoded.recycle()
            return output.toByteArray()
        } finally {
            try {
                retriever.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun scaleDown(source: Bitmap, maxSize: Int): Bitmap {
        val longest = maxOf(source.width, source.height)
        if (longest <= maxSize) return source
        val ratio = maxSize.toFloat() / longest.toFloat()
        val width = (source.width * ratio).toInt().coerceAtLeast(1)
        val height = (source.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, width, height, true)
    }

    // ------------------------------------------------------------ crash log

    private fun crashFile(): File = File(filesDir, CRASH_FILE)

    private fun readCrashLog(): String? = try {
        val file = crashFile()
        if (file.exists()) file.readText() else null
    } catch (t: Throwable) {
        null
    }

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                val text = buildString {
                    appendLine("Amber crash $stamp")
                    appendLine("thread: ${thread.name}")
                    appendLine("android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
                    appendLine("device: ${Build.MANUFACTURER} ${Build.MODEL}")
                    appendLine(
                        android.util.Log.getStackTraceString(error),
                    )
                }
                crashFile().writeText(text)
                saveCrashToDownloads(text)
            } catch (_: Throwable) {
            }
            // Serahkan ke handler bawaan supaya sistem tetap menampilkan dialog.
            previous?.uncaughtException(thread, error)
                ?: run {
                    android.os.Process.killProcess(android.os.Process.myPid())
                    kotlin.system.exitProcess(10)
                }
        }
    }

    /** Supaya log bisa dibuka tanpa PC: muncul di folder Download. */
    private fun saveCrashToDownloads(text: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, DOWNLOAD_NAME)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            contentResolver.openOutputStream(uri)?.use { stream ->
                stream.write(text.toByteArray())
            }
        } catch (_: Throwable) {
        }
    }

    private companion object {
        const val CRASH_FILE = "amber-crash.log"
        const val DOWNLOAD_NAME = "amber-crash.txt"
    }
}

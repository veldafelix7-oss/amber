package com.amber.music

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Jembatan native kecil untuk Amber.
 *
 * Kenapa ada file ini:
 * Pengambilan cover lewat MediaStore (album art) di Android 13 butuh izin
 * READ_MEDIA_IMAGES. Amber sengaja TIDAK meminta izin foto — akibatnya kalau
 * cover diambil dari MediaStore, sistem melempar SecurityException di thread
 * native dan seluruh proses app dimatikan (muncul "Amber telah berhenti").
 *
 * Solusi: cover diambil langsung dari dalam file MP3-nya sendiri
 * (MediaMetadataRetriever / embedded picture). Itu cuma butuh izin audio,
 * tidak menyentuh izin foto, dan seluruh proses dibungkus try/catch +
 * dijalankan di thread terpisah supaya app tidak pernah ikut mati.
 */
class MainActivity : FlutterActivity() {

    private val artExecutor = Executors.newSingleThreadExecutor()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "amber/media")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "embeddedArt" -> {
                        val path = call.argument<String>("path")
                        val maxSize = call.argument<Int>("maxSize") ?: 300
                        if (path.isNullOrEmpty()) {
                            result.success(null)
                            return@setMethodCallHandler
                        }
                        artExecutor.execute {
                            val bytes: ByteArray? = try {
                                extractEmbeddedArt(path, maxSize)
                            } catch (t: Throwable) {
                                null
                            }
                            runOnUiThread { result.success(bytes) }
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun extractEmbeddedArt(path: String, maxSize: Int): ByteArray? {
        if (!path.startsWith("/")) return null
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(path)
            val raw = retriever.embeddedPicture ?: return null
            if (raw.isEmpty() || raw.size > 12 * 1024 * 1024) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            val longest = maxOf(bounds.outWidth, bounds.outHeight)
            while (longest / (sample * 2) >= maxSize) sample *= 2

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = BitmapFactory.decodeByteArray(raw, 0, raw.size, decodeOptions)
                ?: return null

            val scaled = scaleDown(decoded, maxSize)
            val output = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, output)
            if (scaled !== decoded) scaled.recycle()
            decoded.recycle()
            return output.toByteArray()
        } finally {
            try {
                retriever.release()
            } catch (_: Throwable) {
                // abaikan
            }
        }
    }

    private fun scaleDown(source: Bitmap, maxSize: Int): Bitmap {
        val longest = maxOf(source.width, source.height)
        if (longest <= maxSize) return source
        val ratio = maxSize.toFloat() / longest.toFloat()
        val width = (source.width * ratio).toInt().coerceAtLeast(1)
        val height = (source.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, width, height, true)
    }
}

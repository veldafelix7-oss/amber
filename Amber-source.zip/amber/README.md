# 🎧 Amber — Pemutar Musik Offline

Pemutar musik lokal untuk Android dengan gaya Apple Music dan tema **warm ivory + oranye**.
100% offline: **tidak ada izin INTERNET** di manifest, tidak ada API key, tidak ada server, tidak ada analytics.

---

## Status

| Item | Status |
|---|---|
| `flutter analyze` | ✅ **No issues found** (Flutter 3.47.9 / Dart 3.13.7) |
| `flutter test` | ✅ lulus (unit test util format) |
| 35 file Dart | ✅ lengkap: tema, audio handler, state, 11 layar, 8 widget |
| Konfigurasi Android | ✅ manifest + permission + audio_service + adaptive icon |
| APK | ⏳ belum di-compile (sandbox dev-nya cuma 1,9 GB RAM — Gradle kehabisan memori). Build di mesin/cloud lu, lihat bagian **Build APK** |

---

## Fitur yang sudah jalan

**Perpustakaan**
- Scan otomatis semua audio di HP via MediaStore (MP3, M4A, FLAC, WAV, OGG)
- Tab Songs dengan pencarian instan + sortir (Judul / Artis / Terbaru / Durasi) + header huruf A–Z
- Library: **Album** (grid 2 kolom), **Artis** (avatar bulat), **Folder** (pemisah MP3 download vs WhatsApp)
- Filter: hanya MP3, abaikan audio < 30 detik, kecualikan folder tertentu
- Playlist lokal: buat, rename, hapus, tambah lagu, drag untuk urut ulang
- Favorit (hati) & riwayat dengar

**Pemutaran**
- One `AudioPlayer` only, dimiliki `AmberAudioHandler` (tidak ada player liar di UI)
- Queue dengan MediaItem, gapless, shuffle asli (bisa dibalikin), repeat off/all/one
- **Foreground service**: musik tidak mati saat layar off / app di-swipe dari recents
- **MediaSession**: kontrol di lock screen & notification shade, 3 tombol (prev / play-pause / next)
- **Audio focus**: pause otomatis saat telepon masuk / app lain ambil fokus, resume setelahnya, duck ke 0.3 untuk notifikasi
- **Headset & bluetooth**: tombol play/pause/next jalan; cabut headset → pause
- **Resume tanpa auto-play**: posisi disnapshot tiap 5 detik, dipulihkan saat app dibuka (batas 3 detik)
- Sleep timer 15/30/45/60 menit + "akhir lagu ini", dengan fade-out 3 detik
- Volume in-app (bukan slider sistem) + fade saat pause 200 ms

**Tampilan**
- Tema warm ivory `#FFFBF5` + aksen `#FF8A00`, dark mode `#0E0D0C`, 4 pilihan aksen
- Now Playing: artwork blur 60px sebagai latar, progress bar custom, tombol play 68px gradasi, swipe-down untuk tutup, swipe horizontal ganti lagu
- Mini player mengapung di atas tab bar, progress 2px di tepi bawah, gesture lengkap
- Splash, empty state, icon adaptive oranye

---

## Cara Build APK

### Opsi A — GitHub Actions (gratis, tanpa install apa pun, paling gampang)

1. Buat repo di GitHub, upload seluruh folder `amber/` (drag & drop di github.com juga bisa).
2. Workflow sudah disiapkan di `.github/workflows/build-apk.yml`.
3. Push → tab **Actions** → tunggu ±6 menit → download artifact **Amber-APK**.
4. Kirim APK ke HP → install (aktifkan "Install dari sumber tidak dikenal").

### Opsi B — Codemagic

1. codemagic.io → login GitHub → pilih repo.
2. Workflow **Android / Flutter**.
3. Build command: `flutter build apk --release`
4. Download APK dari artifacts.

### Opsi C — Lokal (paling enak kalau mau ngoprek)

Butuh **Flutter SDK** + **Android Studio** (atau JDK 17 + Android SDK cmdline-tools).

```bash
cd amber
flutter pub get
flutter analyze          # harus: No issues found!
flutter test
flutter run              # debug ke HP yang dicolok USB
flutter build apk --release
# hasil: build/app/outputs/flutter-apk/app-release.apk
```

> APK release saat ini ditandatangani dengan **debug keystore** (lihat `android/app/build.gradle.kts`).
> Cukup untuk dipakai sendiri di HP. Untuk Play Store, baru perlu signing key sendiri.

### Kalau Gradle kehabisan memori (RAM ≤ 4 GB)

`android/gradle.properties` sudah diset konservatif (`-Xmx1200m`, `workers.max=1`, Kotlin in-process).
Kalau masih OOM, turunkan lagi ke `-Xmx900m` atau build di cloud (Opsi A/B).

---

## Struktur Kode

```
lib/
├── main.dart                     # init AudioService SEBELUM runApp
├── app.dart                      # MultiProvider, MaterialApp, RootGate (splash→izin→shell)
├── audio/amber_audio_handler.dart # SATU-SATUNYA pemilik AudioPlayer + MediaSession
├── core/theme/                   # app_palette, app_text, app_theme, app_tokens
├── core/utils/format.dart        # durasi, ukuran file, sapaan
├── data/
│   ├── models/track.dart         # Track + AlbumGroup/ArtistGroup/FolderGroup
│   ├── models/playlist.dart      # Playlist + RepeatMode
│   ├── media_store_repository.dart  # query MediaStore + permission + artwork cache
│   └── prefs_repository.dart     # setting, favorit, riwayat, snapshot, playlist
├── state/
│   ├── player_controller.dart    # jembatan handler → UI, sleep timer, artwork notifikasi
│   ├── library_controller.dart   # scan, filter, grup, playlist, favorit
│   └── settings_controller.dart  # tema, aksen, semua switch
└── ui/                           # 11 layar + 8 widget (lihat daftar di atas)
```

### Tiga aturan yang dipegang arsitektur ini

1. **Satu `AudioPlayer`** — dimiliki `AmberAudioHandler`. Tidak ada widget/provider yang membuat player sendiri (penyebab klasik lagu dobel/hantu).
2. **State UI dari `handler.playbackState` + `mediaItem`**, bukan variabel lokal. Posisi pemutaran pakai `ValueNotifier` terpisah supaya progress bar 4×/detik tanpa rebuild seluruh layar.
3. **Interface dipisah per lapisan**: `MediaStoreRepository` (data) → `LibraryController` (state) → widget. Ganti sumber data cukup sentuh 1 file.

---

## Izin Android

| Izin | Kenapa |
|---|---|
| `READ_MEDIA_AUDIO` (API 33+) / `READ_EXTERNAL_STORAGE` (≤32) | baca file MP3 |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | musik hidup saat layar mati |
| `WAKE_LOCK` | CPU tidak tidur saat memutar |
| `POST_NOTIFICATIONS` | kontrol pemutar di notifikasi |
| `BLUETOOTH_CONNECT` | tombol headset bluetooth |
| `RECEIVE_BOOT_COMPLETED` | siapkan opsi "lanjutkan setelah reboot" |
| ~~`INTERNET`~~ | **sengaja tidak ada** — app tidak bisa kirim data ke mana pun |

---

## Uji Manual (setelah APK terpasang)

| # | Uji | Harusnya |
|---|---|---|
| 1 | Install di Android 13+ | hanya minta izin "Musik dan audio" |
| 2 | Taruh 20 MP3 di `Music/`, buka app | jumlah lagu cocok |
| 3 | Putar lagu, tekan tombol power | musik **tetap jalan** |
| 4 | Tekan tombol headset | play/pause |
| 5 | Buka notifikasi, tekan ⏭ | lagu ganti, judul notifikasi ikut berubah |
| 6 | Lock screen | kontrol media muncul + artwork |
| 7 | Swipe app dari recents | musik tetap jalan |
| 8 | Telepon masuk | pause, lanjut sendiri setelah telepon |
| 9 | Cabut headset | pause |
| 10 | Force close + buka lagi | mini player terisi lagu terakhir, posisi mendekati, **tidak auto-play** |
| 11 | Hapus 1 MP3 dari HP, scan ulang | lagu hilang dari list, tidak crash |
| 12 | Shuffle → matikan | urutan kembali seperti semula |
| 13 | Sleep timer 15 menit | berhenti sendiri setelah fade-out |
| 14 | Airplane mode | semua tetap jalan |
| 15 | Ganti tema/aksen di Settings | langsung berubah + tersimpan |
| 16 | Putar 3 jam nonstop | tidak force close, baterai wajar |

---

## Batasan yang jujur

1. **Notifikasi tidak bisa 100% mirip iOS** — layout MediaStyle dirender sistem. Yang bisa diatur: artwork, judul/artis, 3 tombol, accent, ikon. Layout custom butuh native `MediaNotification.Provider` (fase 2).
2. **Blur (`BackdropFilter`) berat di HP murah** — ada switch "Artwork blur di Now Playing" untuk mematikannya.
3. **Playlist hilang kalau app di-uninstall** — belum ada export/import JSON.
4. **Toast "Scan" pertama bisa 2–10 detik** untuk ribuan lagu (tampil spinner di Settings).
5. **`on_audio_query_pluse` butuh Android-only** — kalau nanti build ke iOS, bagian MediaStore harus ditulis ulang.

---

## Fase 2 (belum dikerjakan)

Equalizer 5-band + bass boost · lirik `.lrc` sinkron · home screen widget · tag editor · Android Auto · statistik dengar · crossfade · custom notification layout.

---

*Amber 1.0.0 · Flutter · MVVM ringan dengan provider · 100% offline.*

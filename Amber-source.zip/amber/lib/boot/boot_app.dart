import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';

import '../app.dart';
import '../audio/amber_audio_handler.dart';
import '../core/boot_log.dart';
import '../core/theme/app_palette.dart';
import '../core/theme/app_text.dart';
import '../core/theme/app_theme.dart';
import '../core/theme/app_tokens.dart';
import '../data/media_store_repository.dart';
import '../data/prefs_repository.dart';
import '../state/library_controller.dart';
import '../state/player_controller.dart';
import '../state/settings_controller.dart';

/// Pembungkus start-up.
///
/// Kenapa ada lapisan ini:
/// * `AudioService.init()` bisa menggantung selamanya kalau sistem (mis. HiOS di
///   Tecno) memblokir foreground service. Dulu app jadi nyangkut di splash
///   native tanpa pesan apa pun.
/// * Sekarang setiap langkah dibatasi waktu (timeout), dicatat, dan kalau
///   layanan notifikasi gagal, app tetap jalan dalam MODE DARURAT (pemutaran
///   tetap normal, hanya kontrol notifikasi/lock screen yang absen).
class BootApp extends StatefulWidget {
  const BootApp({super.key});

  @override
  State<BootApp> createState() => _BootAppState();
}

class _BootAppState extends State<BootApp> {
  AmberApp? _app;
  String? _fatal;
  bool _running = true;

  @override
  void initState() {
    super.initState();

    // Tangkap semua error tak tertangani supaya kelihatan di layar.
    final previousOnError = FlutterError.onError;
    FlutterError.onError = (details) {
      BootLog.add('FLUTTER: ${details.exceptionAsString()}');
      previousOnError?.call(details);
    };

    runZonedGuarded(_boot, (error, stack) {
      BootLog.add('FATAL: $error');
      if (!mounted) return;
      setState(() {
        _running = false;
        _fatal = '$error';
      });
    });
  }

  Future<void> _boot() async {
    BootLog.clear();
    BootLog.add('Mulai start-up');

    PrefsRepository prefs;
    try {
      prefs = await PrefsRepository.create().timeout(const Duration(seconds: 6));
      BootLog.add('OK preferensi dibaca');
    } catch (error) {
      BootLog.add('GAGAL preferensi: $error');
      if (mounted) {
        setState(() {
          _running = false;
          _fatal = 'Preferensi tidak bisa dibaca: $error';
        });
      }
      return;
    }

    // 0. Penjaga anti-mati: kalau sesi sebelumnya berhenti mendadak, matikan
    //    pemuatan cover otomatis (mode aman) supaya app tetap bisa dibuka.
    try {
      if (prefs.startPending) {
        await prefs.setLoadArtwork(false);
        await prefs.setUseAudioService(false);
        BootLog.add('MODE AMAN: sesi sebelumnya berhenti mendadak → cover album dimatikan otomatis');
      }
      await prefs.setStartPending(true);
    } catch (error) {
      BootLog.add('PERINGATAN penjaga start: $error');
    }

    // 0b. Kalau sesi sebelumnya mati total, penyebabnya sudah dicatat native.
    try {
      final crash = await MediaStoreRepository().lastCrashReport();
      if (crash != null && crash.trim().isNotEmpty) {
        final summary = crash.trim().split('\n').take(8).join(' | ');
        BootLog.add('LAPORAN CRASH sebelumnya: $summary');
      }
    } catch (_) {
      // tidak penting, abaikan
    }

    // 1. Layanan audio (foreground service + notifikasi + lock screen).
    AmberAudioHandler handler;
    var serviceReady = false;
    if (!prefs.useAudioService) {
      // Mode aman: sesi sebelumnya mati mendadak, jadi layanan latar belakang
      // (foreground service) tidak dijalankan dulu. Pemutar tetap jalan penuh,
      // hanya kontrol di notifikasi/lock screen yang absen.
      handler = AmberAudioHandler(prefs);
      BootLog.add('MODE AMAN: layanan notifikasi dilewati (bisa dinyalakan lagi di Pengaturan)');
    } else {
      try {
        handler = await AudioService.init<AmberAudioHandler>(
          builder: () => AmberAudioHandler(prefs),
          config: buildAudioServiceConfig(accent: prefs.accent.c2),
        ).timeout(const Duration(seconds: 6));
        serviceReady = true;
        BootLog.add('OK layanan audio siap (notifikasi & lock screen aktif)');
      } catch (error) {
        BootLog.add('GAGAL layanan audio: $error');
        // Mode darurat: tetap ada pemutar, tanpa service.
        handler = AmberAudioHandler(prefs);
        BootLog.add('MODE DARURAT: lanjut tanpa layanan notifikasi');
      }
    }

    // 2. Mesin pemutar.
    try {
      await handler.init().timeout(const Duration(seconds: 8));
      BootLog.add('OK mesin pemutar siap');
    } catch (error) {
      BootLog.add('PERINGATAN mesin pemutar: $error');
    }

    // 3. Controller aplikasi (dibungkus supaya error di sini tidak mematikan app).
    late final SettingsController settings;
    late final LibraryController library;
    late final PlayerController player;
    try {
      settings = SettingsController(prefs);
      library = LibraryController(
        repository: MediaStoreRepository(),
        prefs: prefs,
        settings: settings,
      );
      player = PlayerController(handler: handler, prefs: prefs, library: library);
      BootLog.add('OK controller siap');
    } catch (error) {
      BootLog.add('GAGAL controller: $error');
      if (mounted) {
        setState(() {
          _running = false;
          _fatal = 'Controller gagal dibuat: $error';
        });
      }
      return;
    }
    BootLog.add(serviceReady
        ? 'OK aplikasi siap'
        : 'OK aplikasi siap (tanpa notifikasi — aktifkan Auto-start Kola di setelan HP)');

    if (!mounted) return;
    setState(() {
      _running = false;
      _app = AmberApp(
        prefs: prefs,
        settings: settings,
        library: library,
        player: player,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = _app;
    if (app != null) return app;

    // Layar start-up / diagnosa. Selalu tampil instan, jadi tidak akan
    // menggantung di splash native lagi.
    final palette = AppPalette.light(AccentPreset.fallback);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(accent: AccentPreset.fallback, brightness: Brightness.light),
      home: Scaffold(
        backgroundColor: palette.bg,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const SizedBox(height: AppSpacing.xxl),
                Row(
                  children: <Widget>[
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: palette.accentGradient,
                        borderRadius: BorderRadius.circular(AppRadius.artworkMedium),
                      ),
                      child: const Icon(Icons.graphic_eq_rounded, color: Colors.white),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Text('Kola', style: AppText.display(palette.textPrimary)),
                  ],
                ),
                const SizedBox(height: AppSpacing.lg),
                Text(
                  _fatal == null ? 'Menyiapkan aplikasi…' : 'Start-up gagal',
                  style: AppText.section(_fatal == null ? palette.textPrimary : palette.danger),
                ),
                if (_running) ...<Widget>[
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    'Kalau layar ini diam lebih dari 15 detik, screenshot dan kirim ke pengembang.',
                    style: AppText.caption(palette.textSecondary),
                  ),
                ],
                const SizedBox(height: AppSpacing.md),
                Expanded(
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSpacing.sm),
                    decoration: BoxDecoration(
                      color: palette.surface,
                      borderRadius: BorderRadius.circular(AppRadius.button),
                      border: Border.all(color: palette.divider),
                    ),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        BootLog.text,
                        style: AppText.caption(palette.textSecondary).copyWith(height: 1.6),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() {
                        _fatal = null;
                        _running = true;
                      });
                      _boot();
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: palette.accentDeep,
                      side: BorderSide(color: palette.divider),
                      padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppRadius.button),
                      ),
                    ),
                    child: const Text('Coba lagi'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

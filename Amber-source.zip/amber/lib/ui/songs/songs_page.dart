import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../settings/settings_page.dart';
import '../widgets/empty_state.dart';
import '../widgets/song_tile.dart';
import '../widgets/track_menu.dart';

class SongsPage extends StatefulWidget {
  const SongsPage({super.key});

  @override
  State<SongsPage> createState() => _SongsPageState();
}

class _SongsPageState extends State<SongsPage> {
  final TextEditingController _searchController = TextEditingController();
  bool _searching = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final player = context.read<PlayerController>();
    final tracks = library.visibleTracks;

    return SafeArea(
      bottom: false,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.xs, 0),
            child: Row(
              children: <Widget>[
                Expanded(child: Text('Lagu', style: AppText.display(palette.textPrimary))),
                IconButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (context) => const SettingsPage()),
                  ),
                  icon: Icon(Icons.settings_outlined, color: palette.textSecondary),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.sm, AppSpacing.screenH, 0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Container(
                    height: 44,
                    padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
                    decoration: BoxDecoration(
                      color: palette.surfaceAlt,
                      borderRadius: BorderRadius.circular(AppRadius.chip),
                      border: Border.all(color: palette.divider),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.search_rounded, size: 18, color: palette.textTertiary),
                        const SizedBox(width: AppSpacing.xs),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            onChanged: library.setQuery,
                            onTap: () => setState(() => _searching = true),
                            style: AppText.title(palette.textPrimary).copyWith(fontWeight: FontWeight.w500),
                            decoration: InputDecoration(
                              isDense: true,
                              border: InputBorder.none,
                              hintText: 'Cari lagu, artis, album',
                              hintStyle: AppText.subtitle(palette.textTertiary),
                            ),
                          ),
                        ),
                        if (_searching)
                          GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              library.setQuery('');
                              setState(() => _searching = false);
                              FocusScope.of(context).unfocus();
                            },
                            child: Text('Batal', style: AppText.caption(palette.accentDeep)),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.xs),
                IconButton(
                  tooltip: 'Putar acak semua',
                  onPressed: () {
                    if (tracks.isEmpty) return;
                    player.toggleShuffle();
                    player.playTracks(tracks);
                  },
                  icon: Icon(Icons.shuffle_rounded, color: palette.accent),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH, vertical: AppSpacing.xs),
              children: <Widget>[
                for (final mode in SortMode.values)
                  Padding(
                    padding: const EdgeInsets.only(right: AppSpacing.xs),
                    child: ChoiceChip(
                      label: Text(mode.label),
                      selected: library.sort == mode,
                      onSelected: (_) => library.setSort(mode),
                      labelStyle: AppText.caption(
                        library.sort == mode ? Colors.white : palette.textSecondary,
                      ).copyWith(fontWeight: FontWeight.w600),
                      backgroundColor: palette.surface,
                      selectedColor: palette.accent,
                      side: BorderSide(color: palette.divider),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.chip)),
                      showCheckmark: false,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: tracks.isEmpty
                ? EmptyState(
                    title: library.query.isEmpty ? 'Belum ada lagu' : 'Tidak ditemukan',
                    message: library.query.isEmpty
                        ? 'Tambahkan file audio ke perangkat, lalu jalankan pemindaian dari tab Pindai.'
                        : 'Coba kata kunci lain.',
                    icon: library.query.isEmpty ? Icons.music_off_rounded : Icons.search_off_rounded,
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 120),
                    itemCount: tracks.length,
                    itemBuilder: (context, index) {
                      final track = tracks[index];
                      final showHeader = index == 0 || _headerFor(tracks[index - 1]) != _headerFor(track);
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          if (showHeader)
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                AppSpacing.screenH,
                                AppSpacing.sm,
                                AppSpacing.screenH,
                                AppSpacing.xxs,
                              ),
                              child: Text(_headerFor(track), style: AppText.caption(palette.textTertiary)),
                            ),
                          SongTile(
                            track: track,
                            onTap: () => player.playOne(track, context: tracks),
                            onLongPress: () => showTrackMenu(context, track),
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  String _headerFor(Track track) {
    final letter = track.title.trim().isEmpty ? '#' : track.title.trim()[0].toUpperCase();
    return RegExp(r'[A-Z]').hasMatch(letter) ? letter : '#';
  }
}

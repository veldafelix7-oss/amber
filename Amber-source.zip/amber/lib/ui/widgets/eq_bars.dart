import 'package:flutter/material.dart';

import '../../core/theme/app_palette.dart';

/// Tiga bar equalizer kecil — penanda "lagu ini sedang diputar".
class EqBars extends StatefulWidget {
  const EqBars({super.key, this.size = 14, this.playing = true});

  final double size;
  final bool playing;

  @override
  State<EqBars> createState() => _EqBarsState();
}

class _EqBarsState extends State<EqBars> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void initState() {
    super.initState();
    if (widget.playing) _controller.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(covariant EqBars oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.playing && !_controller.isAnimating) {
      _controller.repeat(reverse: true);
    } else if (!widget.playing && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: List<Widget>.generate(3, (index) {
              final phase = (_controller.value + index * 0.33) % 1;
              final heightFactor = 0.35 + (phase < 0.5 ? phase : 1 - phase) * 1.3;
              return Container(
                width: widget.size * 0.22,
                height: widget.size * heightFactor.clamp(0.3, 1.0),
                decoration: BoxDecoration(
                  color: palette.accent,
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}

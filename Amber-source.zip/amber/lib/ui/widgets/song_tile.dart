import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/format.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import 'artwork.dart';
import 'eq_bars.dart';

/// Baris lagu standar (tinggi 64). Dipakai di hampir semua list.
class SongTile extends StatelessWidget {
  const SongTile({
    super.key,
    required this.track,
    required this.onTap,
    this.onLongPress,
    this.leading,
    this.trailing,
    this.showArtwork = true,
    this.highlight = true,
  });

  final Track track;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final Widget? leading;
  final Widget? trailing;
  final bool showArtwork;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final player = context.watch<PlayerController>();
    final isCurrent = highlight && player.isCurrent(track);
    final isFavorite = context.select<LibraryController, bool>((l) => l.favoriteIds.contains(track.id));

    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        height: AppSpacing.rowHeight,
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
        child: Row(
          children: <Widget>[
            if (leading != null) ...<Widget>[leading!, const SizedBox(width: AppSpacing.sm)],
            if (showArtwork) ...<Widget>[
              Artwork(trackId: track.id, size: 48, radius: AppRadius.artworkSmall, label: track.title),
              const SizedBox(width: AppSpacing.sm),
            ],
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppText.title(isCurrent ? palette.accentDeep : palette.textPrimary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${track.displayArtist} · ${track.displayAlbum}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppText.subtitle(palette.textSecondary),
                  ),
                ],
              ),
            ),
            const SizedBox(width: AppSpacing.xs),
            if (isFavorite)
              Padding(
                padding: const EdgeInsets.only(right: AppSpacing.xs),
                child: Icon(Icons.favorite_rounded, size: 14, color: palette.accent),
              ),
            if (trailing != null)
              trailing!
            else if (isCurrent && player.playing)
              EqBars(size: 14)
            else
              Text(Fmt.duration(track.duration), style: AppText.duration(palette.textTertiary)),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_tokens.dart';

/// Membungkus apa pun dengan animasi "mengecil lalu balik" saat ditekan.
///
/// Dipakai di tombol, kartu, dan navigasi supaya sentuhan terasa hidup tanpa
/// perlu animasi berat — hanya `scale` + kurva, jadi tetap 60 fps di HP kelas
/// menengah seperti Tecno/Redmi.
class PressableScale extends StatefulWidget {
  const PressableScale({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.scale = 0.96,
  });

  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double scale;

  @override
  State<PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<PressableScale> {
  bool _down = false;

  void _set(bool value) {
    if (_down == value) return;
    setState(() => _down = value);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.onTap == null ? null : (_) => _set(true),
      onTapUp: widget.onTap == null ? null : (_) => _set(false),
      onTapCancel: widget.onTap == null ? null : () => _set(false),
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _down ? widget.scale : 1,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}

/// Panel kaca: putih semi-transparan dengan tepi tipis dan gradasi oren halus.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpacing.md),
    this.radius = AppRadius.card,
    this.tint = false,
    this.border = true,
    this.elevated = true,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final bool tint;
  final bool border;
  final bool elevated;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: tint
            ? LinearGradient(
                colors: <Color>[
                  Color.alphaBlend(palette.accentSoft.withValues(alpha: 0.55), palette.glassStrong),
                  palette.glass,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: tint ? null : palette.glass,
        borderRadius: BorderRadius.circular(radius),
        border: border ? Border.all(color: palette.glassBorder, width: 1.2) : null,
        boxShadow: elevated ? AppShadow.l1(palette.accent) : null,
      ),
      child: child,
    );
  }
}

/// Sakelar on/off dengan animasi lembut (bukan Switch bawaan yang "patah").
class AmberSwitch extends StatelessWidget {
  const AmberSwitch({
    super.key,
    required this.value,
    required this.onChanged,
    this.width = 48,
    this.height = 28,
  });

  final bool value;
  final ValueChanged<bool> onChanged;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final knob = height - 6;
    return GestureDetector(
      onTap: () => onChanged(!value),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: AppMotion.fast,
        curve: Curves.easeOutCubic,
        width: width,
        height: height,
        padding: const EdgeInsets.symmetric(horizontal: 3),
        decoration: BoxDecoration(
          gradient: value ? palette.accentGradient : null,
          color: value ? null : palette.isDark ? palette.surfaceAlt : palette.divider,
          borderRadius: BorderRadius.circular(height),
          border: Border.all(
            color: value ? Colors.transparent : palette.divider,
          ),
        ),
        child: AnimatedAlign(
          duration: AppMotion.fast,
          curve: Curves.easeOutCubic,
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: knob,
            height: knob,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: <BoxShadow>[
                BoxShadow(color: Colors.black.withValues(alpha: 0.14), blurRadius: 6, offset: const Offset(0, 2)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Permukaan gradasi oren→putih, dipakai untuk tombol utama.
class WarmButton extends StatelessWidget {
  const WarmButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.busy = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final enabled = onPressed != null && !busy;
    return PressableScale(
      onTap: enabled ? onPressed : null,
      scale: 0.97,
      child: AnimatedOpacity(
        duration: AppMotion.fast,
        opacity: enabled ? 1 : 0.55,
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
          decoration: BoxDecoration(
            gradient: palette.warmGradient,
            borderRadius: BorderRadius.circular(AppRadius.button),
            boxShadow: AppShadow.accent(palette.accent),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              if (busy)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
              else if (icon != null)
                Icon(icon, size: 20, color: Colors.white),
              if (busy || icon != null) const SizedBox(width: AppSpacing.xs),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

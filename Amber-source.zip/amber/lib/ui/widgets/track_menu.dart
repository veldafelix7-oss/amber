import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../data/models/playlist.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';

/// Menu aksi untuk satu lagu (long-press / tombol ⋯).
Future<void> showTrackMenu(BuildContext context, Track track, {List<Track>? context2}) async {
  final player = context.read<PlayerController>();
  final library = context.read<LibraryController>();

  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: false,
    backgroundColor: AppPalette.of(context).surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.sheet)),
    ),
    builder: (sheetContext) {
      final palette = AppPalette.of(sheetContext);
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(height: AppSpacing.sm),
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(color: palette.divider, borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: AppSpacing.md),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppText.title(palette.textPrimary)),
                        Text(track.displayArtist, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppText.subtitle(palette.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.xs),
            Divider(color: palette.divider),
            _MenuItem(
              icon: Icons.playlist_play_rounded,
              label: 'Putar berikutnya',
              onTap: () {
                Navigator.of(sheetContext).pop();
                player.playNext(track);
              },
            ),
            _MenuItem(
              icon: Icons.queue_music_rounded,
              label: 'Tambahkan ke antrian',
              onTap: () {
                Navigator.of(sheetContext).pop();
                player.addToQueue(track);
              },
            ),
            _MenuItem(
              icon: library.favoriteIds.contains(track.id) ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              label: library.favoriteIds.contains(track.id) ? 'Hapus dari favorit' : 'Tambahkan ke favorit',
              onTap: () {
                Navigator.of(sheetContext).pop();
                library.toggleFavorite(track.id);
              },
            ),
            _MenuItem(
              icon: Icons.playlist_add_rounded,
              label: 'Tambahkan ke playlist',
              onTap: () {
                Navigator.of(sheetContext).pop();
                _showPlaylistPicker(context, track);
              },
            ),
            _MenuItem(
              icon: Icons.info_outline_rounded,
              label: 'Detail file',
              onTap: () {
                Navigator.of(sheetContext).pop();
                _showFileDetail(context, track);
              },
            ),
            const SizedBox(height: AppSpacing.xs),
          ],
        ),
      );
    },
  );
}

Future<void> _showPlaylistPicker(BuildContext context, Track track) async {
  final library = context.read<LibraryController>();
  final playlists = library.playlists;
  final palette = AppPalette.of(context);

  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: palette.surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.sheet)),
    ),
    builder: (sheetContext) {
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(height: AppSpacing.lg),
            Text('Tambahkan ke playlist', style: AppText.section(palette.textPrimary)),
            const SizedBox(height: AppSpacing.sm),
            _MenuItem(
              icon: Icons.add_rounded,
              label: 'Playlist baru…',
              onTap: () async {
                Navigator.of(sheetContext).pop();
                final name = await _askPlaylistName(context);
                if (name == null) return;
                await library.createPlaylist(name, trackIds: <int>[track.id]);
              },
            ),
            if (playlists.isEmpty)
              Padding(
                padding: const EdgeInsets.all(AppSpacing.xl),
                child: Text('Belum ada playlist.', style: AppText.subtitle(palette.textSecondary)),
              )
            else
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: playlists.length,
                  itemBuilder: (context, index) {
                    final Playlist playlist = playlists[index];
                    return _MenuItem(
                      icon: Icons.queue_music_rounded,
                      label: '${playlist.name} · ${playlist.trackIds.length} lagu',
                      onTap: () {
                        Navigator.of(sheetContext).pop();
                        library.addToPlaylist(playlist.id, <int>[track.id]);
                      },
                    );
                  },
                ),
              ),
            const SizedBox(height: AppSpacing.xs),
          ],
        ),
      );
    },
  );
}

Future<String?> _askPlaylistName(BuildContext context) async {
  final controller = TextEditingController();
  final result = await showDialog<String>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Playlist baru'),
      content: TextField(
        controller: controller,
        autofocus: true,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(hintText: 'Nama playlist'),
        onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text), child: const Text('Simpan')),
      ],
    ),
  );
  controller.dispose();
  return (result == null || result.trim().isEmpty) ? null : result.trim();
}

Future<void> _showFileDetail(BuildContext context, Track track) async {
  final palette = AppPalette.of(context);
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Detail file'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Judul: ${track.title}', style: AppText.subtitle(palette.textSecondary)),
          Text('Artis: ${track.displayArtist}', style: AppText.subtitle(palette.textSecondary)),
          Text('Album: ${track.displayAlbum}', style: AppText.subtitle(palette.textSecondary)),
          Text('Folder: ${track.displayFolder}', style: AppText.subtitle(palette.textSecondary)),
          Text('Durasi: ${track.duration.inMinutes} menit', style: AppText.subtitle(palette.textSecondary)),
          Text('Ukuran: ${_megabytes(track.size)}', style: AppText.subtitle(palette.textSecondary)),
          const SizedBox(height: AppSpacing.xs),
          Text(track.path, style: AppText.caption(palette.textTertiary)),
        ],
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Tutup')),
      ],
    ),
  );
}

String _megabytes(int bytes) {
  if (bytes <= 0) return '-';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
}

class _MenuItem extends StatelessWidget {
  const _MenuItem({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg, vertical: AppSpacing.md),
        child: Row(
          children: <Widget>[
            Icon(icon, size: 22, color: palette.accent),
            const SizedBox(width: AppSpacing.md),
            Expanded(child: Text(label, style: AppText.title(palette.textPrimary))),
          ],
        ),
      ),
    );
  }
}

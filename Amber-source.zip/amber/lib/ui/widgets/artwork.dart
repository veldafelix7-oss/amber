import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../state/library_controller.dart';

/// Cover lagu. Kalau tidak ada artwork, tampil gradasi aksen + inisial.
class Artwork extends StatelessWidget {
  const Artwork({
    super.key,
    required this.trackId,
    required this.size,
    this.radius = 12,
    this.label,
    this.circular = false,
  });

  final int trackId;
  final double size;
  final double radius;
  final String? label;
  final bool circular;

  @override
  Widget build(BuildContext context) {
    final library = context.read<LibraryController>();
    return ClipRRect(
      borderRadius: BorderRadius.circular(circular ? size : radius),
      child: SizedBox(
        width: size,
        height: size,
        child: FutureBuilder<Uint8List?>(
          future: library.artworkFor(trackId, size: (size * 2).round()),
          builder: (context, snapshot) {
            final bytes = snapshot.data;
            if (bytes != null && bytes.isNotEmpty) {
              return Image.memory(
                bytes,
                width: size,
                height: size,
                fit: BoxFit.cover,
                cacheWidth: (size * 2).round().clamp(48, 1200),
                gaplessPlayback: true,
                errorBuilder: (context, error, stack) => _Placeholder(size: size, label: label),
              );
            }
            return _Placeholder(size: size, label: label);
          },
        ),
      ),
    );
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder({required this.size, this.label});

  final double size;
  final String? label;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final text = (label ?? '').trim();
    final initials = text.isEmpty
        ? '♪'
        : text
            .split(RegExp(r'\s+'))
            .where((w) => w.isNotEmpty)
            .take(2)
            .map((w) => w.substring(0, 1).toUpperCase())
            .join();
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(gradient: palette.accentGradient),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: AppText.title(Colors.white).copyWith(
          fontSize: size * 0.3,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';

/// Banner mengapung dengan gradasi tema (oren-putih atau warna tema lain).
///
/// Dipakai untuk pemberitahuan hasil pindai maupun pesan error pemutaran,
/// supaya konsisten dengan tema yang sedang dipilih user.
void showAmberBanner(
  BuildContext context,
  String message, {
  IconData icon = Icons.info_outline_rounded,
  bool error = false,
  Duration duration = const Duration(seconds: 4),
}) {
  final palette = AppPalette.of(context);
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(AppSpacing.md, 0, AppSpacing.md, AppSpacing.md),
      duration: duration,
      padding: EdgeInsets.zero,
      content: Container(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
        decoration: BoxDecoration(
          gradient: error
              ? LinearGradient(
                  colors: <Color>[
                    palette.danger,
                    Color.alphaBlend(Colors.white.withValues(alpha: 0.25), palette.danger),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : palette.warmGradient,
          borderRadius: BorderRadius.circular(AppRadius.card),
          border: Border.all(color: Colors.white.withValues(alpha: 0.35), width: 1.2),
          boxShadow: AppShadow.accent(error ? palette.danger : palette.accent),
        ),
        child: Row(
          children: <Widget>[
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: AppSpacing.xs),
            Expanded(
              child: Text(
                message,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: AppText.subtitle(Colors.white).copyWith(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

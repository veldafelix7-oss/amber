import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/track.dart';
import '../../state/player_controller.dart';
import '../player/now_playing_page.dart';

/// Satu ketukan pada lagu = layar pemutar terbuka DAN lagu langsung berbunyi.
///
/// Layar dibuka lebih dulu supaya terasa instan, sementara pemuatan audio
/// berjalan di belakangnya. `PlayerController.playTracks` sudah menandai lagu
/// aktif lebih dulu, jadi layar pemutar tidak pernah kosong.
Future<void> playAndOpen(BuildContext context, Track track, List<Track> queue) async {
  final player = context.read<PlayerController>();
  NowPlayingPage.open(context);
  await player.playOne(track, context: queue);
}

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/player_controller.dart';
import '../player/now_playing_page.dart';
import 'artwork.dart';

/// Kartu pemutar kecil yang mengapung di atas bottom navigation.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerController>();
    final track = player.current;
    if (track == null) return const SizedBox.shrink();

    final palette = AppPalette.of(context);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => NowPlayingPage.open(context),
      onVerticalDragEnd: (details) {
        if ((details.primaryVelocity ?? 0) < -50) NowPlayingPage.open(context);
      },
      onHorizontalDragEnd: (details) {
        final velocity = details.primaryVelocity ?? 0;
        if (velocity < -200) {
          player.next();
        } else if (velocity > 200) {
          player.previous();
        }
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.card),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              height: AppSpacing.rowHeight,
              decoration: BoxDecoration(
                color: palette.surface.withValues(alpha: 0.94),
                borderRadius: BorderRadius.circular(AppRadius.card),
                border: Border.all(color: palette.divider),
                boxShadow: AppShadow.l2(palette.accent),
              ),
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: <Widget>[
                        const SizedBox(width: AppSpacing.xs),
                        Artwork(
                          trackId: track.id,
                          size: 44,
                          radius: AppRadius.artworkMedium,
                          label: track.title,
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                track.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: AppText.title(palette.textPrimary),
                              ),
                              const SizedBox(height: 1),
                              Text(
                                track.displayArtist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: AppText.subtitle(palette.textSecondary),
                              ),
                            ],
                          ),
                        ),
                        _MiniButton(
                          icon: Icons.skip_previous_rounded,
                          onTap: player.previous,
                        ),
                        _MiniButton(
                          icon: player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                          color: palette.accent,
                          big: true,
                          onTap: player.togglePlay,
                        ),
                        _MiniButton(
                          icon: Icons.skip_next_rounded,
                          onTap: player.next,
                        ),
                        const SizedBox(width: AppSpacing.xs),
                      ],
                    ),
                  ),
                  // Progress 2px di tepi bawah kartu.
                  _MiniProgress(
                    position: player.position,
                    duration: player.duration,
                    color: palette.accent,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MiniProgress extends StatelessWidget {
  const _MiniProgress({required this.position, required this.duration, required this.color});

  final ValueNotifier<Duration> position;
  final Duration duration;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Duration>(
      valueListenable: position,
      builder: (context, value, _) {
        final total = duration.inMilliseconds;
        final ratio = total <= 0 ? 0.0 : (value.inMilliseconds / total).clamp(0.0, 1.0);
        return SizedBox(
          height: 2,
          child: Row(
            children: <Widget>[
              Expanded(
                flex: (ratio * 1000).round().clamp(1, 1000),
                child: Container(color: color),
              ),
              Expanded(
                flex: ((1 - ratio) * 1000).round().clamp(0, 999),
                child: Container(color: Colors.transparent),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MiniButton extends StatelessWidget {
  const _MiniButton({
    required this.icon,
    required this.onTap,
    this.color,
    this.big = false,
  });

  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  final bool big;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return InkResponse(
      onTap: onTap,
      radius: 24,
      child: SizedBox(
        width: big ? 44 : 38,
        height: 44,
        child: Icon(icon, size: big ? 30 : 22, color: color ?? palette.textPrimary),
      ),
    );
  }
}

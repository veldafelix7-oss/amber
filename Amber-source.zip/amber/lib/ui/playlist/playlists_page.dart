import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/library_controller.dart';
import '../settings/settings_page.dart';
import '../widgets/artwork.dart';
import '../widgets/empty_state.dart';
import 'playlist_detail_page.dart';

class PlaylistsPage extends StatelessWidget {
  const PlaylistsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final playlists = library.playlists;

    return SafeArea(
      bottom: false,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.xs, 0),
            child: Row(
              children: <Widget>[
                Expanded(child: Text('Playlists', style: AppText.display(palette.textPrimary))),
                IconButton(
                  onPressed: () => _createPlaylist(context),
                  icon: Icon(Icons.add_rounded, color: palette.accent, size: 26),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (context) => const SettingsPage()),
                  ),
                  icon: Icon(Icons.settings_outlined, color: palette.textSecondary),
                ),
              ],
            ),
          ),
          Expanded(
            child: playlists.isEmpty
                ? EmptyState(
                    title: 'Belum ada playlist',
                    message: 'Bikin playlist pertama lu — kumpulkan lagu sesuai mood.',
                    actionLabel: 'Playlist baru',
                    onAction: () => _createPlaylist(context),
                    icon: Icons.queue_music_rounded,
                  )
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(
                      AppSpacing.screenH,
                      AppSpacing.sm,
                      AppSpacing.screenH,
                      120,
                    ),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: AppSpacing.md,
                      crossAxisSpacing: AppSpacing.md,
                      childAspectRatio: 0.82,
                    ),
                    itemCount: playlists.length,
                    itemBuilder: (context, index) {
                      final playlist = playlists[index];
                      return GestureDetector(
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (context) => PlaylistDetailPage(playlistId: playlist.id),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            AspectRatio(
                              aspectRatio: 1,
                              child: playlist.coverTrackId != null
                                  ? Artwork(
                                      trackId: playlist.coverTrackId!,
                                      size: 400,
                                      radius: AppRadius.artwork,
                                      label: playlist.name,
                                    )
                                  : Container(
                                      decoration: BoxDecoration(
                                        gradient: palette.accentGradient,
                                        borderRadius: BorderRadius.circular(AppRadius.artwork),
                                      ),
                                      child: const Icon(
                                        Icons.queue_music_rounded,
                                        color: Colors.white,
                                        size: 40,
                                      ),
                                    ),
                            ),
                            const SizedBox(height: AppSpacing.xs),
                            Text(
                              playlist.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppText.title(palette.textPrimary),
                            ),
                            Text(
                              '${playlist.trackIds.length} lagu',
                              style: AppText.caption(palette.textSecondary),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _createPlaylist(BuildContext context) async {
    final library = context.read<LibraryController>();
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Playlist baru'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(hintText: 'Nama playlist'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text), child: const Text('Simpan')),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.trim().isEmpty) return;
    await library.createPlaylist(name);
  }
}

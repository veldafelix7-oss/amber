import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../widgets/play_action.dart';
import '../widgets/song_tile.dart';
import '../widgets/track_menu.dart';

class PlaylistDetailPage extends StatelessWidget {
  const PlaylistDetailPage({super.key, required this.playlistId});

  final String playlistId;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final player = context.read<PlayerController>();

    final playlist = library.playlists.where((p) => p.id == playlistId).firstOrNull;
    if (playlist == null) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: Text('Playlist tidak ditemukan', style: AppText.subtitle(palette.textSecondary))),
      );
    }
    final tracks = library.tracksOfPlaylist(playlist);

    return Scaffold(
      backgroundColor: palette.bg,
      appBar: AppBar(
        title: Text(playlist.name, style: AppText.section(palette.textPrimary)),
        actions: <Widget>[
          IconButton(
            onPressed: () async {
              final titleController = TextEditingController(text: playlist.name);
              final newName = await showDialog<String>(
                context: context,
                builder: (dialogContext) => AlertDialog(
                  title: const Text('Ganti nama playlist'),
                  content: TextField(controller: titleController, autofocus: true),
                  actions: <Widget>[
                    TextButton(
                      onPressed: () => Navigator.of(dialogContext).pop(),
                      child: const Text('Batal'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.of(dialogContext).pop(titleController.text),
                      child: const Text('Simpan'),
                    ),
                  ],
                ),
              );
              titleController.dispose();
              if (newName == null || newName.trim().isEmpty) return;
              await library.renamePlaylist(playlistId, newName);
            },
            icon: const Icon(Icons.edit_outlined, size: 20),
          ),
          IconButton(
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (dialogContext) => AlertDialog(
                  title: const Text('Hapus playlist?'),
                  content: const Text('Playlist ini akan dihapus. File MP3 di HP lu tidak terhapus.'),
                  actions: <Widget>[
                    TextButton(
                      onPressed: () => Navigator.of(dialogContext).pop(false),
                      child: const Text('Batal'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.of(dialogContext).pop(true),
                      child: const Text('Hapus'),
                    ),
                  ],
                ),
              );
              if (confirmed != true) return;
              await library.deletePlaylist(playlistId);
              if (context.mounted) Navigator.of(context).maybePop();
            },
            icon: Icon(Icons.delete_outline_rounded, size: 20, color: palette.danger),
          ),
        ],
      ),
      body: tracks.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(AppSpacing.xxl),
                child: Text(
                  'Playlist masih kosong.\nTekan lama lagu mana pun → "Tambahkan ke playlist".',
                  textAlign: TextAlign.center,
                  style: AppText.subtitle(palette.textSecondary),
                ),
              ),
            )
          : Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => player.playTracks(tracks),
                          icon: const Icon(Icons.play_arrow_rounded, size: 22),
                          label: const Text('Putar'),
                          style: FilledButton.styleFrom(
                            backgroundColor: palette.accent,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(AppRadius.button),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Text('${tracks.length} lagu', style: AppText.caption(palette.textTertiary)),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.xs),
                Expanded(
                  child: ReorderableListView.builder(
                    padding: const EdgeInsets.only(bottom: 140),
                    itemCount: tracks.length,
                    onReorderItem: (oldIndex, newIndex) {
                      library.reorderPlaylist(playlistId, oldIndex, newIndex);
                    },
                    itemBuilder: (context, index) {
                      final Track track = tracks[index];
                      return SongTile(
                        key: ValueKey<String>('pl-${track.id}-$index'),
                        track: track,
                        onTap: () => playAndOpen(context, track, tracks),
                        onLongPress: () => showTrackMenu(context, track),
                        leading: Icon(Icons.drag_handle_rounded, color: palette.textTertiary, size: 20),
                        trailing: IconButton(
                          onPressed: () => library.removeFromPlaylist(playlistId, track.id),
                          icon: Icon(Icons.close_rounded, size: 18, color: palette.textTertiary),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}

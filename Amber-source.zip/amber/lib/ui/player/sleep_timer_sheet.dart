import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/player_controller.dart';

Future<void> showSleepTimerSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppPalette.of(context).surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.sheet)),
    ),
    builder: (sheetContext) => const _SleepTimerBody(),
  );
}

class _SleepTimerBody extends StatelessWidget {
  const _SleepTimerBody();

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final player = context.watch<PlayerController>();
    final remaining = player.sleepRemaining.value;

    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const SizedBox(height: AppSpacing.sm),
          Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(color: palette.divider, borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: AppSpacing.md),
          Text('Sleep timer', style: AppText.section(palette.textPrimary)),
          const SizedBox(height: AppSpacing.xxs),
          Text(
            remaining == null
                ? 'Musik berhenti otomatis setelah durasi tertentu.'
                : 'Aktif — sisa ${remaining.inMinutes} menit ${remaining.inSeconds % 60} detik',
            style: AppText.subtitle(palette.textSecondary),
          ),
          const SizedBox(height: AppSpacing.md),
          for (final minutes in <int>[15, 30, 45, 60])
            ListTile(
              title: Text('$minutes menit', style: AppText.title(palette.textPrimary)),
              leading: Icon(Icons.timer_outlined, color: palette.accent),
              onTap: () {
                player.startSleepTimer(Duration(minutes: minutes));
                Navigator.of(context).pop();
              },
            ),
          ListTile(
            title: Text('Akhir lagu ini', style: AppText.title(palette.textPrimary)),
            leading: Icon(Icons.music_note_outlined, color: palette.accent),
            onTap: () {
              player.startSleepTimer(Duration.zero, afterCurrentTrack: true);
              Navigator.of(context).pop();
            },
          ),
          if (remaining != null)
            ListTile(
              title: Text('Matikan sleep timer', style: AppText.title(palette.danger)),
              leading: Icon(Icons.timer_off_outlined, color: palette.danger),
              onTap: () {
                player.cancelSleepTimer();
                Navigator.of(context).pop();
              },
            ),
          const SizedBox(height: AppSpacing.xs),
        ],
      ),
    );
  }
}

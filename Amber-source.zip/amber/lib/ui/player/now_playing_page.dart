import 'dart:typed_data';
import 'dart:ui';

import 'package:flutter/material.dart' hide RepeatMode;
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/format.dart';
import '../../data/models/playlist.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../../state/settings_controller.dart';
import '../widgets/artwork.dart';
import 'queue_sheet.dart';
import 'sleep_timer_sheet.dart';

/// Layar utama pemutar. Buka dengan slide-up, tutup dengan swipe-down.
class NowPlayingPage extends StatefulWidget {
  const NowPlayingPage({super.key});

  static void open(BuildContext context) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: AppMotion.page,
        reverseTransitionDuration: AppMotion.normal,
        pageBuilder: (context, animation, secondary) => const NowPlayingPage(),
        transitionsBuilder: (context, animation, secondary, child) {
          final curved = CurvedAnimation(parent: animation, curve: AppMotion.easeOut);
          return SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero).animate(curved),
            child: FadeTransition(opacity: curved, child: child),
          );
        },
      ),
    );
  }

  @override
  State<NowPlayingPage> createState() => _NowPlayingPageState();
}

class _NowPlayingPageState extends State<NowPlayingPage> {
  double _dragOffset = 0;

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerController>();
    final settings = context.watch<SettingsController>();
    final palette = AppPalette.of(context);
    final track = player.current;

    if (track == null) {
      return Scaffold(
        backgroundColor: palette.bg,
        body: SafeArea(
          child: Center(
            child: Text('Belum ada lagu yang diputar', style: AppText.subtitle(palette.textSecondary)),
          ),
        ),
      );
    }

    final width = MediaQuery.sizeOf(context).width;
    final artSize = (width - 72).clamp(160.0, 420.0);
    final library = context.read<LibraryController>();

    return Scaffold(
      backgroundColor: palette.bg,
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onVerticalDragUpdate: (details) {
          if (details.delta.dy > 0) {
            setState(() => _dragOffset += details.delta.dy);
          }
        },
        onVerticalDragEnd: (details) {
          final shouldClose = _dragOffset > MediaQuery.sizeOf(context).height * 0.25 ||
              (details.primaryVelocity ?? 0) > 700;
          if (shouldClose) {
            Navigator.of(context).maybePop();
          } else {
            setState(() => _dragOffset = 0);
          }
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          transform: Matrix4.translationValues(0, _dragOffset.clamp(0, 400), 0),
          child: Stack(
            children: <Widget>[
              // Latar: artwork blur + overlay palet.
              Positioned.fill(
                child: settings.blurArtwork
                    ? FutureBuilder<Uint8List?>(
                        future: library.artworkFor(track.id, size: 400),
                        builder: (context, snapshot) {
                          final bytes = snapshot.data;
                          if (bytes == null || bytes.isEmpty) {
                            return Container(color: palette.bg);
                          }
                          return Stack(
                            fit: StackFit.expand,
                            children: <Widget>[
                              Image.memory(bytes, fit: BoxFit.cover),
                              BackdropFilter(
                                filter: ImageFilter.blur(sigmaX: 60, sigmaY: 60),
                                child: const SizedBox.expand(),
                              ),
                              Container(color: palette.bg.withValues(alpha: 0.86)),
                            ],
                          );
                        },
                      )
                    : Container(color: palette.bg),
              ),
              SafeArea(
                child: Column(
                  children: <Widget>[
                    _TopBar(player: player),
                    const Spacer(),
                    _ArtworkBlock(
                      trackId: track.id,
                      title: track.title,
                      size: artSize,
                      playing: player.playing,
                    ),
                    SizedBox(height: AppSpacing.xl),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            track.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: AppText.playerTitle(palette.textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            track.displayArtist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppText.subtitle(palette.textSecondary).copyWith(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    _ProgressBar(player: player),
                    const SizedBox(height: AppSpacing.xs),
                    _Controls(player: player),
                    const SizedBox(height: AppSpacing.sm),
                    _BottomBar(player: player),
                    const Spacer(flex: 2),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.player});

  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final sleep = player.sleepRemaining.value;
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.xs, AppSpacing.xs, AppSpacing.xs, 0),
      child: Row(
        children: <Widget>[
          IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: Icon(Icons.keyboard_arrow_down_rounded, size: 30, color: palette.textPrimary),
          ),
          Expanded(
            child: Column(
              children: <Widget>[
                Text('SEDANG DIPUTAR', style: AppText.overline(palette.textSecondary)),
                if (sleep != null)
                  Text(
                    'Sleep timer · ${Fmt.duration(sleep)}',
                    style: AppText.caption(palette.accentDeep),
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => showSleepTimerSheet(context),
            icon: Icon(Icons.more_horiz_rounded, size: 26, color: palette.textPrimary),
          ),
        ],
      ),
    );
  }
}

class _ArtworkBlock extends StatelessWidget {
  const _ArtworkBlock({
    required this.trackId,
    required this.title,
    required this.size,
    required this.playing,
  });

  final int trackId;
  final String title;
  final double size;
  final bool playing;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return AnimatedScale(
      duration: AppMotion.normal,
      curve: Curves.easeOut,
      scale: playing ? 1 : 0.94,
      child: AnimatedOpacity(
        duration: AppMotion.normal,
        opacity: playing ? 1 : 0.9,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.card),
            boxShadow: AppShadow.accent(palette.accent),
          ),
          child: Artwork(
            trackId: trackId,
            size: size,
            radius: AppRadius.card,
            label: title,
          ),
        ),
      ),
    );
  }
}

class _ProgressBar extends StatefulWidget {
  const _ProgressBar({required this.player});

  final PlayerController player;

  @override
  State<_ProgressBar> createState() => _ProgressBarState();
}

class _ProgressBarState extends State<_ProgressBar> {
  double? _dragValue;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final total = widget.player.duration.inMilliseconds.toDouble();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
      child: ValueListenableBuilder<Duration>(
        valueListenable: widget.player.position,
        builder: (context, value, _) {
          final current = _dragValue ?? value.inMilliseconds.toDouble().clamp(0, total == 0 ? 1 : total);
          final ratio = total <= 0 ? 0.0 : (current / total).clamp(0.0, 1.0);
          return Column(
            children: <Widget>[
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackShape: const _FlatTrackShape(),
                  thumbShape: RoundSliderThumbShape(enabledThumbRadius: _dragValue == null ? 0 : 6),
                  overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                ),
                child: Slider(
                  value: ratio,
                  onChanged: (next) => setState(() => _dragValue = next * total),
                  onChangeEnd: (next) {
                    widget.player.seek(Duration(milliseconds: (next * total).round()));
                    setState(() => _dragValue = null);
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xs),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      Fmt.duration(Duration(milliseconds: current.round())),
                      style: AppText.duration(palette.textTertiary),
                    ),
                    Text(Fmt.duration(widget.player.duration), style: AppText.duration(palette.textTertiary)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _FlatTrackShape extends RoundedRectSliderTrackShape {
  const _FlatTrackShape();

  @override
  void paint(
    PaintingContext context,
    Offset offset, {
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required Animation<double> enableAnimation,
    required TextDirection textDirection,
    required Offset thumbCenter,
    Offset? secondaryOffset,
    bool isDiscrete = false,
    bool isEnabled = false,
    double additionalActiveTrackHeight = 2,
  }) {
    final canvas = context.canvas;
    final rect = getPreferredRect(
      parentBox: parentBox,
      offset: offset,
      sliderTheme: sliderTheme,
      isEnabled: isEnabled,
      isDiscrete: isDiscrete,
    );
    final radius = Radius.circular(rect.height / 2);
    final paintActive = Paint()..color = sliderTheme.activeTrackColor ?? Colors.orange;
    final paintInactive = Paint()..color = sliderTheme.inactiveTrackColor ?? Colors.grey;
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, radius),
      paintInactive,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(rect.left, rect.top, thumbCenter.dx - rect.left, rect.height),
        radius,
      ),
      paintActive,
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.player});

  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _IconToggle(
            icon: Icons.shuffle_rounded,
            active: player.shuffle,
            onTap: player.toggleShuffle,
            alwaysShowDot: false,
          ),
          _RoundButton(icon: Icons.skip_previous_rounded, size: 30, onTap: player.previous),
          _PlayButton(player: player),
          _RoundButton(icon: Icons.skip_next_rounded, size: 30, onTap: player.next),
          _RepeatButton(player: player),
        ],
      ),
    );
  }
}

class _PlayButton extends StatelessWidget {
  const _PlayButton({required this.player});

  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return GestureDetector(
      onTap: player.togglePlay,
      child: AnimatedScale(
        duration: AppMotion.spring,
        scale: player.playing ? 1 : 0.96,
        child: Container(
          width: 68,
          height: 68,
          decoration: BoxDecoration(
            gradient: palette.accentGradient,
            shape: BoxShape.circle,
            boxShadow: AppShadow.accent(palette.accent),
          ),
          child: Icon(
            player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
            color: Colors.white,
            size: 34,
          ),
        ),
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({required this.icon, required this.onTap, this.size = 24});

  final IconData icon;
  final VoidCallback onTap;
  final double size;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return IconButton(
      onPressed: onTap,
      iconSize: size,
      color: palette.textPrimary,
      icon: Icon(icon),
    );
  }
}

class _IconToggle extends StatelessWidget {
  const _IconToggle({
    required this.icon,
    required this.active,
    required this.onTap,
    this.alwaysShowDot = true,
  });

  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  final bool alwaysShowDot;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        IconButton(
          onPressed: onTap,
          iconSize: 22,
          color: active ? palette.accent : palette.textSecondary,
          icon: Icon(icon),
        ),
        Container(
          width: 4,
          height: 4,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? palette.accent : Colors.transparent,
          ),
        ),
      ],
    );
  }
}

class _RepeatButton extends StatelessWidget {
  const _RepeatButton({required this.player});

  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final one = player.repeatMode == RepeatMode.one;
    final active = player.repeatMode != RepeatMode.off;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        IconButton(
          onPressed: player.cycleRepeat,
          iconSize: 22,
          color: active ? palette.accent : palette.textSecondary,
          icon: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Icon(one ? Icons.repeat_one_rounded : Icons.repeat_rounded),
            ],
          ),
        ),
        Container(
          width: 4,
          height: 4,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? palette.accent : Colors.transparent,
          ),
        ),
      ],
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({required this.player});

  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final track = player.current;
    final isFavorite = track != null && player.isFavorite(track.id);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      child: Row(
        children: <Widget>[
          IconButton(
            onPressed: player.toggleFavoriteCurrent,
            iconSize: 24,
            color: isFavorite ? palette.accent : palette.textSecondary,
            icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
          ),
          const SizedBox(width: AppSpacing.xs),
          Expanded(
            child: Row(
              children: <Widget>[
                Icon(Icons.volume_down_rounded, size: 20, color: palette.textTertiary),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 2,
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
                    ),
                    child: Slider(
                      value: player.volume,
                      onChanged: player.setVolume,
                    ),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => showQueueSheet(context),
            iconSize: 24,
            color: palette.textSecondary,
            icon: const Icon(Icons.queue_music_rounded),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/player_controller.dart';
import '../widgets/artwork.dart';

Future<void> showQueueSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppPalette.of(context).surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.sheet)),
    ),
    builder: (sheetContext) {
      return DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        builder: (context, scrollController) => _QueueBody(scrollController: scrollController),
      );
    },
  );
}

class _QueueBody extends StatelessWidget {
  const _QueueBody({required this.scrollController});

  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final player = context.watch<PlayerController>();
    final tracks = player.handler.tracks;
    final currentIndex = player.handler.currentIndex;

    return Column(
      children: <Widget>[
        const SizedBox(height: AppSpacing.sm),
        Container(
          width: 36,
          height: 4,
          decoration: BoxDecoration(color: palette.divider, borderRadius: BorderRadius.circular(2)),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.md, AppSpacing.sm, AppSpacing.sm),
          child: Row(
            children: <Widget>[
              Expanded(child: Text('Antrian', style: AppText.section(palette.textPrimary))),
              Text('${tracks.length} lagu', style: AppText.caption(palette.textTertiary)),
            ],
          ),
        ),
        Divider(color: palette.divider),
        Expanded(
          child: tracks.isEmpty
              ? Center(child: Text('Antrian kosong', style: AppText.subtitle(palette.textSecondary)))
              : ListView.builder(
                  controller: scrollController,
                  itemCount: tracks.length,
                  itemBuilder: (context, index) {
                    final track = tracks[index];
                    final isCurrent = index == currentIndex;
                    return InkWell(
                      onTap: () => player.handler.skipToQueueItem(index),
                      child: Container(
                        height: AppSpacing.rowHeight,
                        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                        color: isCurrent ? palette.surfaceAlt : null,
                        child: Row(
                          children: <Widget>[
                            SizedBox(
                              width: 24,
                              child: isCurrent
                                  ? Icon(Icons.graphic_eq_rounded, size: 18, color: palette.accent)
                                  : Text('${index + 1}', style: AppText.caption(palette.textTertiary)),
                            ),
                            const SizedBox(width: AppSpacing.sm),
                            Artwork(
                              trackId: track.id,
                              size: 40,
                              radius: AppRadius.artworkSmall,
                              label: track.title,
                            ),
                            const SizedBox(width: AppSpacing.sm),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    track.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: AppText.title(isCurrent ? palette.accentDeep : palette.textPrimary),
                                  ),
                                  Text(
                                    track.displayArtist,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: AppText.subtitle(palette.textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: () => player.removeFromQueue(index),
                              icon: Icon(Icons.close_rounded, size: 18, color: palette.textTertiary),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

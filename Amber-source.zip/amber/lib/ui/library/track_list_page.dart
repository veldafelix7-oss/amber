import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/format.dart';
import '../../data/models/track.dart';
import '../../state/player_controller.dart';
import '../widgets/artwork.dart';
import '../widgets/play_action.dart';
import '../widgets/song_tile.dart';
import '../widgets/track_menu.dart';

/// Halaman daftar lagu generik: dipakai untuk album, artis, folder, favorit.
class TrackListPage extends StatelessWidget {
  const TrackListPage({
    super.key,
    required this.title,
    required this.tracks,
    this.subtitle,
    this.coverTrackId,
    this.circularCover = false,
    this.onTrackRemoved,
  });

  final String title;
  final List<Track> tracks;
  final String? subtitle;
  final int? coverTrackId;
  final bool circularCover;
  final void Function(Track track)? onTrackRemoved;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final player = context.read<PlayerController>();
    final totalDuration = tracks.fold<Duration>(Duration.zero, (sum, t) => sum + t.duration);

    return Scaffold(
      backgroundColor: palette.bg,
      appBar: AppBar(title: Text(title, style: AppText.section(palette.textPrimary))),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 140),
        children: <Widget>[
          if (coverTrackId != null)
            Center(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(circularCover ? 200 : AppRadius.card),
                  boxShadow: AppShadow.accent(palette.accent),
                ),
                child: Artwork(
                  trackId: coverTrackId!,
                  size: 200,
                  radius: circularCover ? 100 : AppRadius.card,
                  label: title,
                  circular: circularCover,
                ),
              ),
            ),
          const SizedBox(height: AppSpacing.lg),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: AppText.playerTitle(palette.textPrimary)),
                if (subtitle != null) ...<Widget>[
                  const SizedBox(height: 2),
                  Text(subtitle!, style: AppText.subtitle(palette.textSecondary)),
                ],
                const SizedBox(height: AppSpacing.xxs),
                Text(
                  '${tracks.length} lagu · ${Fmt.duration(totalDuration)}',
                  style: AppText.caption(palette.textTertiary),
                ),
                const SizedBox(height: AppSpacing.md),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: tracks.isEmpty ? null : () => player.playTracks(tracks),
                        icon: const Icon(Icons.play_arrow_rounded, size: 22),
                        label: const Text('Putar'),
                        style: FilledButton.styleFrom(
                          backgroundColor: palette.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(AppRadius.button),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: tracks.isEmpty
                            ? null
                            : () async {
                                await player.toggleShuffle();
                                await player.playTracks(tracks);
                              },
                        icon: const Icon(Icons.shuffle_rounded, size: 20),
                        label: const Text('Acak'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: palette.accentDeep,
                          side: BorderSide(color: palette.divider),
                          padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(AppRadius.button),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          Divider(color: palette.divider),
          for (final track in tracks)
            Dismissible(
              key: ValueKey<String>('track-${track.id}'),
              direction: onTrackRemoved == null ? DismissDirection.none : DismissDirection.endToStart,
              background: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: AppSpacing.xl),
                color: palette.danger.withValues(alpha: 0.12),
                child: Icon(Icons.delete_outline_rounded, color: palette.danger),
              ),
              onDismissed: (_) => onTrackRemoved?.call(track),
              child: SongTile(
                track: track,
                showArtwork: coverTrackId == null,
                onTap: () => playAndOpen(context, track, tracks),
                onLongPress: () => showTrackMenu(context, track),
              ),
            ),
        ],
      ),
    );
  }
}

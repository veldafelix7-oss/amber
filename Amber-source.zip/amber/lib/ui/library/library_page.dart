import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../settings/settings_page.dart';
import '../widgets/artwork.dart';
import '../widgets/empty_state.dart';
import 'track_list_page.dart';

enum LibraryTab { album, artist, folder }

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});

  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  LibraryTab _tab = LibraryTab.album;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();

    return SafeArea(
      bottom: false,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.xs, 0),
            child: Row(
              children: <Widget>[
                Expanded(child: Text('Library', style: AppText.display(palette.textPrimary))),
                IconButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (context) => const SettingsPage()),
                  ),
                  icon: Icon(Icons.settings_outlined, color: palette.textSecondary),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.sm, AppSpacing.screenH, AppSpacing.sm),
            child: Container(
              height: 44,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: palette.surfaceAlt,
                borderRadius: BorderRadius.circular(AppRadius.chip),
                border: Border.all(color: palette.divider),
              ),
              child: Row(
                children: <Widget>[
                  for (final tab in LibraryTab.values)
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _tab = tab),
                        child: AnimatedContainer(
                          duration: AppMotion.fast,
                          decoration: BoxDecoration(
                            color: _tab == tab ? palette.surface : Colors.transparent,
                            borderRadius: BorderRadius.circular(AppRadius.chip),
                            boxShadow: _tab == tab ? AppShadow.l1(palette.accent) : null,
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            switch (tab) {
                              LibraryTab.album => 'Album',
                              LibraryTab.artist => 'Artis',
                              LibraryTab.folder => 'Folder',
                            },
                            style: AppText.subtitle(
                              _tab == tab ? palette.textPrimary : palette.textSecondary,
                            ).copyWith(fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Expanded(child: _body(context, library)),
        ],
      ),
    );
  }

  Widget _body(BuildContext context, LibraryController library) {
    if (!library.scanned) {
      return EmptyState(
        title: 'Perpustakaan kosong',
        message: 'Scan dulu musik di HP lu.',
        actionLabel: 'Scan Sekarang',
        onAction: library.rescan,
        icon: Icons.album_outlined,
      );
    }

    switch (_tab) {
      case LibraryTab.album:
        final albums = library.albums;
        if (albums.isEmpty) return const EmptyState(title: 'Belum ada album');
        return GridView.builder(
          padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.xs, AppSpacing.screenH, 120),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: AppSpacing.md,
            crossAxisSpacing: AppSpacing.md,
            childAspectRatio: 0.78,
          ),
          itemCount: albums.length,
          itemBuilder: (context, index) {
            final album = albums[index];
            return _AlbumTile(album: album);
          },
        );
      case LibraryTab.artist:
        final artists = library.artists;
        if (artists.isEmpty) return const EmptyState(title: 'Belum ada artis');
        return ListView.builder(
          padding: const EdgeInsets.only(bottom: 120),
          itemCount: artists.length,
          itemBuilder: (context, index) {
            final artist = artists[index];
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH, vertical: 4),
              leading: Artwork(
                trackId: artist.coverTrackId,
                size: 52,
                radius: 26,
                circular: true,
                label: artist.name,
              ),
              title: Text(artist.name, style: AppText.title(AppPalette.of(context).textPrimary)),
              subtitle: Text(
                '${artist.albumCount} album · ${artist.count} lagu',
                style: AppText.caption(AppPalette.of(context).textSecondary),
              ),
              trailing: Icon(Icons.chevron_right_rounded, color: AppPalette.of(context).textTertiary),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (context) => TrackListPage(
                    title: artist.name,
                    subtitle: 'Artis',
                    tracks: artist.tracks,
                    coverTrackId: artist.coverTrackId,
                    circularCover: true,
                  ),
                ),
              ),
            );
          },
        );
      case LibraryTab.folder:
        final folders = library.folders;
        if (folders.isEmpty) return const EmptyState(title: 'Belum ada folder');
        return ListView.builder(
          padding: const EdgeInsets.only(bottom: 120),
          itemCount: folders.length,
          itemBuilder: (context, index) {
            final folder = folders[index];
            final palette = AppPalette.of(context);
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH, vertical: 4),
              leading: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: palette.surfaceAlt,
                  borderRadius: BorderRadius.circular(AppRadius.artworkSmall),
                ),
                child: Icon(Icons.folder_rounded, color: palette.accent),
              ),
              title: Text(folder.name, style: AppText.title(palette.textPrimary)),
              subtitle: Text(
                '${folder.count} lagu · ${folder.path}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppText.caption(palette.textSecondary),
              ),
              trailing: Icon(Icons.chevron_right_rounded, color: palette.textTertiary),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (context) => TrackListPage(
                    title: folder.name,
                    subtitle: 'Folder',
                    tracks: folder.tracks,
                  ),
                ),
              ),
            );
          },
        );
    }
  }
}

class _AlbumTile extends StatelessWidget {
  const _AlbumTile({required this.album});

  final AlbumGroup album;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final player = context.read<PlayerController>();
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (context) => TrackListPage(
            title: album.name,
            subtitle: album.artist,
            tracks: album.tracks,
            coverTrackId: album.coverTrackId,
          ),
        ),
      ),
      onLongPress: () => player.playTracks(album.tracks),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          AspectRatio(
            aspectRatio: 1,
            child: Artwork(
              trackId: album.coverTrackId,
              size: 400,
              radius: AppRadius.artwork,
              label: album.name,
            ),
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            album.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppText.title(palette.textPrimary),
          ),
          Text(
            '${album.count} lagu',
            style: AppText.caption(palette.textSecondary),
          ),
        ],
      ),
    );
  }
}

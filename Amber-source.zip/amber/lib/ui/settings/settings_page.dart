import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/boot_log.dart';
import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/format.dart';
import '../../state/library_controller.dart';
import '../../state/settings_controller.dart';
import '../widgets/pressable.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final settings = context.watch<SettingsController>();
    final library = context.watch<LibraryController>();

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text('Pengaturan', style: AppText.section(palette.textPrimary)),
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 240),
        children: <Widget>[
          _SectionTitle('Tampilan'),
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, 0, AppSpacing.screenH, AppSpacing.xs),
            child: Row(
              children: <Widget>[
                for (final mode in ThemeMode.values)
                  Padding(
                    padding: const EdgeInsets.only(right: AppSpacing.xs),
                    child: ChoiceChip(
                      label: Text(switch (mode) {
                        ThemeMode.light => 'Light',
                        ThemeMode.dark => 'Dark',
                        ThemeMode.system => 'System',
                      }),
                      selected: settings.themeMode == mode,
                      onSelected: (_) => settings.setThemeMode(mode),
                      showCheckmark: false,
                      backgroundColor: palette.surface,
                      selectedColor: palette.accent,
                      labelStyle: AppText.caption(
                        settings.themeMode == mode ? Colors.white : palette.textSecondary,
                      ).copyWith(fontWeight: FontWeight.w600),
                      side: BorderSide(color: palette.divider),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.chip)),
                    ),
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 92,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH, vertical: AppSpacing.xs),
              itemCount: AccentPreset.values.length,
              separatorBuilder: (context, index) => const SizedBox(width: AppSpacing.md),
              itemBuilder: (context, index) {
                final accent = AccentPreset.values[index];
                final selected = settings.accentPreset == accent;
                return PressableScale(
                  onTap: () => settings.setAccent(accent),
                  scale: 0.92,
                  child: Column(
                    children: <Widget>[
                      AnimatedContainer(
                        duration: AppMotion.fast,
                        curve: Curves.easeOutCubic,
                        width: selected ? 54 : 48,
                        height: selected ? 54 : 48,
                        decoration: BoxDecoration(
                          gradient: accent.gradient,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: selected ? palette.textPrimary : Colors.white,
                            width: selected ? 2.4 : 2,
                          ),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: accent.c2.withValues(alpha: selected ? 0.45 : 0.22),
                              blurRadius: selected ? 14 : 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: selected
                            ? const Icon(Icons.check_rounded, size: 20, color: Colors.white)
                            : null,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        accent.label,
                        style: AppText.caption(
                          selected ? palette.textPrimary : palette.textTertiary,
                        ).copyWith(fontWeight: selected ? FontWeight.w700 : FontWeight.w500),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          _SwitchTile(
            title: 'Muat cover album',
            subtitle: 'Matikan kalau app terasa berat atau bermasalah saat memuat cover.',
            value: settings.loadArtwork,
            onChanged: settings.setLoadArtwork,
          ),
          _SwitchTile(
            title: 'Artwork blur di Now Playing',
            subtitle: 'Latar berwarna lembut dari cover lagu.',
            value: settings.blurArtwork,
            onChanged: settings.setBlurArtwork,
          ),
          _SectionTitle('Pemutaran'),
          _SwitchTile(
            title: 'Pulihkan lagu terakhir',
            subtitle: 'Buka app langsung ke lagu terakhir (tanpa auto-play).',
            value: settings.resumeOnOpen,
            onChanged: settings.setResumeOnOpen,
          ),
          _SwitchTile(
            title: 'Lanjutkan setelah HP reboot',
            subtitle: 'Posisi lagu disimpan, musik tidak auto-play.',
            value: settings.resumeAfterReboot,
            onChanged: settings.setResumeAfterReboot,
          ),
          _SwitchTile(
            title: 'Tombol headset & bluetooth',
            subtitle: 'Play/pause/next dari headset kabel maupun bluetooth.',
            value: settings.handleHeadset,
            onChanged: settings.setHandleHeadset,
          ),
          _SwitchTile(
            title: 'Fade saat pause',
            subtitle: 'Volume menurun halus 200 ms sebelum berhenti.',
            value: settings.fadeOnPause,
            onChanged: settings.setFadeOnPause,
          ),
          _SectionTitle('Perpustakaan'),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
            title: Text('Scan sekarang', style: AppText.title(palette.textPrimary)),
            subtitle: Text(
              library.loading ? 'Memindai…' : '${library.totalTracks} lagu ditemukan',
              style: AppText.caption(palette.textSecondary),
            ),
            trailing: library.loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Icon(Icons.refresh_rounded, color: palette.accent),
            onTap: library.loading ? null : library.rescan,
          ),
          _SwitchTile(
            title: 'Abaikan audio < 30 detik',
            subtitle: 'Menyembunyikan notifikasi suara & voice note pendek.',
            value: settings.ignoreShortAudio,
            onChanged: (value) async {
              await settings.setIgnoreShortAudio(value);
              await library.rescan();
            },
          ),
          _SwitchTile(
            title: 'Hanya file MP3',
            subtitle: 'Sembunyikan format lain (M4A, FLAC, WAV).',
            value: settings.onlyMp3,
            onChanged: (value) async {
              await settings.setOnlyMp3(value);
              await library.rescan();
            },
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
            title: Text('Kecualikan folder', style: AppText.title(palette.textPrimary)),
            subtitle: Text(
              settings.excludedFolders.isEmpty
                  ? 'Belum ada folder yang dikecualikan'
                  : '${settings.excludedFolders.length} folder dikecualikan',
              style: AppText.caption(palette.textSecondary),
            ),
            trailing: Icon(Icons.chevron_right_rounded, color: palette.textTertiary),
            onTap: () => _showExcludeFolders(context),
          ),
          _SectionTitle('Notifikasi'),
          _SwitchTile(
            title: 'Layanan notifikasi & kontrol lock screen',
            subtitle: 'Nyalakan untuk kontrol di notifikasi & lock screen. Kalau app jadi bermasalah saat dibuka, matikan lagi. Berlaku setelah app dibuka ulang.',
            value: settings.useAudioService,
            onChanged: settings.setUseAudioService,
          ),
          _SwitchTile(
            title: 'Kontrol di lock screen',
            subtitle: 'Tampilkan tombol pemutar di layar kunci.',
            value: settings.lockScreenControls,
            onChanged: settings.setLockScreenControls,
          ),
          _SectionTitle('Diagnostik'),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
            title: Text('Log start-up', style: AppText.title(palette.textPrimary)),
            subtitle: Text(
              'Status layanan audio & catatan start-up',
              style: AppText.caption(palette.textSecondary),
            ),
            trailing: Icon(Icons.chevron_right_rounded, color: palette.textTertiary),
            onTap: () => _showBootLog(context),
          ),
          _SectionTitle('Tentang'),
          _InfoTile(label: 'Versi', value: '2.1.0'),
          _InfoTile(label: 'Lagu ter-scan', value: '${settings.libraryCount}'),
          _InfoTile(label: 'Ukuran library', value: Fmt.fileSize(settings.libraryBytes)),
          _InfoTile(label: 'Dibuat dengan', value: 'Flutter'),
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.screenH, AppSpacing.xl),
            child: Text(
              'Amber tidak mengirim data apa pun ke mana pun. Semua musik dan playlist '
              'tersimpan di HP lu. Aplikasi ini bahkan tidak meminta izin internet.',
              style: AppText.caption(palette.textTertiary),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showExcludeFolders(BuildContext context) async {
    final settings = context.read<SettingsController>();
    final library = context.read<LibraryController>();
    final palette = AppPalette.of(context);

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: palette.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.sheet)),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final folders = library.folderNames;
            return SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  Text('Kecualikan folder', style: AppText.section(palette.textPrimary)),
                  const SizedBox(height: AppSpacing.xxs),
                  Text(
                    'Folder terpilih tidak akan muncul di perpustakaan.',
                    style: AppText.caption(palette.textSecondary),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: folders.length,
                      itemBuilder: (context, index) {
                        final folder = folders[index];
                        final selected = settings.excludedFolders.contains(folder);
                        return CheckboxListTile(
                          value: selected,
                          title: Text(folder, style: AppText.title(palette.textPrimary)),
                          activeColor: palette.accent,
                          onChanged: (_) async {
                            await settings.toggleExcludedFolder(folder);
                            setSheetState(() {});
                          },
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    child: SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: () async {
                          Navigator.of(sheetContext).pop();
                          await library.rescan();
                        },
                        style: FilledButton.styleFrom(
                          backgroundColor: palette.accent,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(AppRadius.button),
                          ),
                        ),
                        child: const Text('Simpan & scan ulang'),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showBootLog(BuildContext context) async {
    final palette = AppPalette.of(context);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Log start-up'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SelectableText(
              BootLog.text,
              style: AppText.caption(palette.textSecondary).copyWith(height: 1.6),
            ),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title);

  final String title;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.xl, AppSpacing.screenH, AppSpacing.xs),
      child: Text(title.toUpperCase(), style: AppText.overline(palette.textTertiary)),
    );
  }
}

class _SwitchTile extends StatelessWidget {
  const _SwitchTile({
    required this.title,
    required this.value,
    required this.onChanged,
    this.subtitle,
  });

  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return SwitchListTile(
      value: value,
      onChanged: onChanged,
      activeThumbColor: Colors.white,
      activeTrackColor: palette.accent,
      contentPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
      title: Text(title, style: AppText.title(palette.textPrimary)),
      subtitle: subtitle == null
          ? null
          : Text(subtitle!, style: AppText.caption(palette.textSecondary)),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH, vertical: AppSpacing.xs),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(label, style: AppText.subtitle(palette.textSecondary)),
          Text(value, style: AppText.subtitle(palette.textPrimary).copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }


}

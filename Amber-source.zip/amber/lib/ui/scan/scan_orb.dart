import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/library_controller.dart';
import '../widgets/pressable.dart';
import '../widgets/themed_banner.dart';

/// Tombol pindai yang menonjol di tengah navigasi (gaya tombol tengah GoPay).
///
/// Animasi pemindai berjalan **di dalam tombol ini** — tidak ada halaman scan
/// terpisah. Selesai memindai, hasilnya muncul sebagai banner tema.
class ScanOrb extends StatefulWidget {
  const ScanOrb({super.key, this.size = 62});

  final double size;

  @override
  State<ScanOrb> createState() => _ScanOrbState();
}

class _ScanOrbState extends State<ScanOrb> with SingleTickerProviderStateMixin {
  late final AnimationController _sweep = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
    value: 0.5,
  );
  LibraryController? _library;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final library = context.read<LibraryController>();
    if (!identical(library, _library)) {
      _library?.removeListener(_sync);
      _library = library..addListener(_sync);
      _sync();
    }
  }

  void _sync() {
    final loading = _library?.loading ?? false;
    if (loading && !_sweep.isAnimating) {
      _sweep.repeat(reverse: true);
    } else if (!loading && _sweep.isAnimating) {
      _sweep.stop();
      _sweep.value = 0.5;
    }
  }

  @override
  void dispose() {
    _library?.removeListener(_sync);
    _sweep.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final library = context.read<LibraryController>();
    if (library.loading) return;
    final before = library.totalTracks;
    final granted = await library.scanWithPermission();
    if (!mounted) return;
    if (!granted) {
      showAmberBanner(
        context,
        'Izin akses audio diperlukan untuk memindai musik.',
        icon: Icons.lock_outline_rounded,
        error: true,
      );
      return;
    }
    final found = library.totalTracks;
    showAmberBanner(
      context,
      found == 0
          ? 'Tidak ada file audio yang ditemukan.'
          : '$found lagu siap diputar${before > 0 && found != before ? ' ($found total)' : ''}.',
      icon: found == 0 ? Icons.search_off_rounded : Icons.library_music_rounded,
    );
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final loading = library.loading;

    return PressableScale(
      scale: 0.92,
      onTap: _start,
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            // Cincin cahaya lembut di belakang tombol.
            AnimatedContainer(
              duration: AppMotion.normal,
              width: widget.size + (loading ? 14 : 8),
              height: widget.size + (loading ? 14 : 8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: palette.gradientMid.withValues(alpha: loading ? 0.28 : 0.16),
              ),
            ),
            Container(
              width: widget.size,
              height: widget.size,
              decoration: BoxDecoration(
                gradient: palette.warmGradient,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: 0.65), width: 1.6),
                boxShadow: AppShadow.accent(palette.accent),
              ),
              clipBehavior: Clip.antiAlias,
              child: AnimatedBuilder(
                animation: _sweep,
                builder: (context, _) {
                  return RepaintBoundary(
                    child: CustomPaint(
                      painter: _OrbPainter(
                        progress: _sweep.value,
                        active: loading,
                      ),
                      child: Center(
                        child: loading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.qr_code_scanner_rounded, color: Colors.white, size: 26),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Garis pemindai naik-turun di dalam lingkaran.
class _OrbPainter extends CustomPainter {
  _OrbPainter({required this.progress, required this.active});

  final double progress;
  final bool active;

  @override
  void paint(Canvas canvas, Size size) {
    if (!active) return;
    final y = size.height * progress;
    final lineRect = Rect.fromLTWH(0, y - 14, size.width, 28);
    final glow = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          Colors.white.withValues(alpha: 0),
          Colors.white.withValues(alpha: 0.30),
          Colors.white.withValues(alpha: 0),
        ],
      ).createShader(lineRect);
    canvas.drawRect(lineRect, glow);

    final line = Paint()
      ..color = Colors.white.withValues(alpha: 0.95)
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(10, y), Offset(size.width - 10, y), line);
  }

  @override
  bool shouldRepaint(_OrbPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.active != active;
}

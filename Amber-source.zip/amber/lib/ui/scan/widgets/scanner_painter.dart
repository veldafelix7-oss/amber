import 'package:flutter/material.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/theme/app_tokens.dart';

/// Bingkai pemindai dengan garis yang naik-turun.
///
/// Digambar dengan CustomPainter + RepaintBoundary, jadi animasinya hanya
/// me-repaint kotak kecil ini — sisa layar tidak ikut dihitung ulang.
class ScannerPanel extends StatelessWidget {
  const ScannerPanel({
    super.key,
    required this.progress,
    required this.active,
    required this.child,
  });

  final double progress;
  final bool active;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Container(
      height: 240,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[
            Color.alphaBlend(palette.accentSoft.withValues(alpha: 0.55), palette.glassStrong),
            palette.glass,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppRadius.sheet),
        border: Border.all(color: palette.glassBorder, width: 1.2),
        boxShadow: AppShadow.l2(palette.accent),
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: <Widget>[
          Positioned.fill(
            child: RepaintBoundary(
              child: CustomPaint(
                painter: _ScannerPainter(
                  progress: progress,
                  active: active,
                  accent: palette.accent,
                  accentSoft: palette.accentSoft,
                  guide: palette.accent.withValues(alpha: 0.14),
                ),
              ),
            ),
          ),
          Positioned.fill(child: child),
        ],
      ),
    );
  }
}

class _ScannerPainter extends CustomPainter {
  _ScannerPainter({
    required this.progress,
    required this.active,
    required this.accent,
    required this.accentSoft,
    required this.guide,
  });

  final double progress;
  final bool active;
  final Color accent;
  final Color accentSoft;
  final Color guide;

  @override
  void paint(Canvas canvas, Size size) {
    // Sudut bingkai ala kamera.
    final corner = Paint()
      ..color = accent.withValues(alpha: active ? 0.85 : 0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    const inset = 14.0;
    const arm = 26.0;
    final path = Path()
      ..moveTo(inset, inset + arm)
      ..lineTo(inset, inset)
      ..lineTo(inset + arm, inset)
      ..moveTo(size.width - inset - arm, inset)
      ..lineTo(size.width - inset, inset)
      ..lineTo(size.width - inset, inset + arm)
      ..moveTo(inset, size.height - inset - arm)
      ..lineTo(inset, size.height - inset)
      ..lineTo(inset + arm, size.height - inset)
      ..moveTo(size.width - inset - arm, size.height - inset)
      ..lineTo(size.width - inset, size.height - inset)
      ..lineTo(size.width - inset, size.height - inset - arm);
    canvas.drawPath(path, corner);

    // Garis bantu tipis.
    final grid = Paint()
      ..color = guide
      ..strokeWidth = 1;
    for (var i = 1; i < 5; i++) {
      final y = size.height * i / 5;
      canvas.drawLine(Offset(inset + 8, y), Offset(size.width - inset - 8, y), grid);
    }

    // Garis pemindai.
    final y = (size.height - 40) * progress + 20;
    final lineRect = Rect.fromLTWH(inset + 8, y - 22, size.width - (inset + 8) * 2, 44);
    final glow = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          accent.withValues(alpha: 0),
          accent.withValues(alpha: active ? 0.22 : 0.10),
          accent.withValues(alpha: 0),
        ],
      ).createShader(lineRect);
    canvas.drawRect(lineRect, glow);

    final line = Paint()
      ..shader = LinearGradient(
        colors: <Color>[
          accent.withValues(alpha: 0),
          accent,
          accentSoft,
          accent.withValues(alpha: 0),
        ],
      ).createShader(Rect.fromLTWH(inset + 8, y - 1.5, size.width - (inset + 8) * 2, 3))
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(inset + 8, y),
      Offset(size.width - inset - 8, y),
      line,
    );
  }

  @override
  bool shouldRepaint(_ScannerPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.active != active;
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../data/media_store_repository.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../songs/songs_page.dart';
import '../widgets/pressable.dart';
import '../widgets/song_tile.dart';
import '../widgets/track_menu.dart';
import 'widgets/scanner_painter.dart';

/// Tab Pindai — pemindaian dijalankan HANYA saat user menekan tombol.
class ScanPage extends StatefulWidget {
  const ScanPage({super.key});

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> with SingleTickerProviderStateMixin {
  late final AnimationController _sweep =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1500), value: 0.5);
  LibraryController? _library;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final library = context.read<LibraryController>();
    if (!identical(library, _library)) {
      _library?.removeListener(_syncSweep);
      _library = library..addListener(_syncSweep);
      _syncSweep();
    }
  }

  void _syncSweep() {
    final loading = _library?.loading ?? false;
    if (loading && !_sweep.isAnimating) {
      _sweep.repeat(reverse: true);
    } else if (!loading && _sweep.isAnimating) {
      _sweep.stop();
      _sweep.value = 0.5;
    }
  }

  @override
  void dispose() {
    _library?.removeListener(_syncSweep);
    _sweep.dispose();
    super.dispose();
  }

  Future<void> _startScan() async {
    final library = context.read<LibraryController>();
    if (library.loading) return;
    final granted = await library.scanWithPermission();
    if (!mounted || granted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Izin akses audio diperlukan untuk memindai musik.'),
      ),
    );
  }

  void _openSongs() {
    final palette = AppPalette.of(context);
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DecoratedBox(
          decoration: BoxDecoration(gradient: palette.pageGradient),
          child: const Scaffold(backgroundColor: Colors.transparent, body: SongsPage()),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final player = context.read<PlayerController>();
    final preview = library.allTracks.take(5).toList();

    final status = library.loading
        ? 'Memindai… ${library.totalTracks} lagu ditemukan'
        : library.scanned
            ? '${library.totalTracks} lagu siap diputar'
            : 'Belum dipindai';

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.screenH, 190),
        children: <Widget>[
          Text('Pindai musik', style: AppText.display(palette.textPrimary)),
          const SizedBox(height: 2),
          Text(
            'Amber mencari file audio yang sudah ada di perangkat ini. Tidak ada data yang dikirim keluar.',
            style: AppText.subtitle(palette.textSecondary),
          ),
          const SizedBox(height: AppSpacing.lg),
          AnimatedBuilder(
            animation: _sweep,
            builder: (context, _) {
              return ScannerPanel(
                progress: _sweep.value,
                active: library.loading,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        width: 66,
                        height: 66,
                        decoration: BoxDecoration(
                          gradient: palette.warmGradient,
                          shape: BoxShape.circle,
                          boxShadow: AppShadow.accent(palette.accent),
                        ),
                        child: const Icon(Icons.graphic_eq_rounded, color: Colors.white, size: 30),
                      ),
                      const SizedBox(height: AppSpacing.sm),
                      Text(
                        library.loading ? 'Memindai perangkat…' : status,
                        style: AppText.title(palette.textPrimary),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: AppSpacing.lg),
          WarmButton(
            label: library.scanned ? 'Pindai ulang' : 'Mulai pemindaian',
            icon: Icons.search_rounded,
            busy: library.loading,
            onPressed: library.loading ? null : _startScan,
          ),
          if (library.scanned && library.totalTracks > 0) ...<Widget>[
            const SizedBox(height: AppSpacing.sm),
            PressableScale(
              onTap: _openSongs,
              child: Container(
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: palette.glass,
                  borderRadius: BorderRadius.circular(AppRadius.button),
                  border: Border.all(color: palette.glassBorder, width: 1.2),
                ),
                child: Text(
                  'Lihat semua lagu',
                  style: AppText.title(palette.textPrimary),
                ),
              ),
            ),
          ],
          if (library.permission == PermissionState.permanentlyDenied) ...<Widget>[
            const SizedBox(height: AppSpacing.sm),
            PressableScale(
              onTap: library.openSystemSettings,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
                child: Text(
                  'Izin ditolak permanen — buka pengaturan aplikasi',
                  style: AppText.caption(palette.accentDeep),
                ),
              ),
            ),
          ],
          if (preview.isNotEmpty) ...<Widget>[
            const SizedBox(height: AppSpacing.xl),
            Text('Pratinjau', style: AppText.section(palette.textPrimary)),
            const SizedBox(height: AppSpacing.xxs),
            for (final track in preview)
              SongTile(
                track: track,
                onTap: () => player.playOne(track, context: library.allTracks),
                onLongPress: () => showTrackMenu(context, track),
              ),
          ],
        ],
      ),
    );
  }
}

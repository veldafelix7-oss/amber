import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/player_controller.dart';
import '../home/home_page.dart';
import '../library/library_page.dart';
import '../playlist/playlists_page.dart';
import '../songs/songs_page.dart';
import '../widgets/mini_player.dart';

/// Kerangka utama: 4 tab + mini player mengapung di atas nav bar.
class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  static const List<_TabSpec> _tabs = <_TabSpec>[
    _TabSpec(label: 'Home', icon: Icons.home_outlined, activeIcon: Icons.home_rounded),
    _TabSpec(label: 'Songs', icon: Icons.music_note_outlined, activeIcon: Icons.music_note_rounded),
    _TabSpec(label: 'Library', icon: Icons.album_outlined, activeIcon: Icons.album_rounded),
    _TabSpec(label: 'Playlists', icon: Icons.queue_music_outlined, activeIcon: Icons.queue_music_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final hasTrack = context.select<PlayerController, bool>((p) => p.hasTrack);

    return Scaffold(
      backgroundColor: palette.bg,
      body: Stack(
        children: <Widget>[
          IndexedStack(
            index: _index,
            children: const <Widget>[
              HomePage(),
              SongsPage(),
              LibraryPage(),
              PlaylistsPage(),
            ],
          ),
          if (hasTrack)
            Positioned(
              left: 0,
              right: 0,
              bottom: AppSpacing.xs,
              child: const MiniPlayer(),
            ),
        ],
      ),
      bottomNavigationBar: _BottomBar(
        index: _index,
        tabs: _tabs,
        onSelect: (value) => setState(() => _index = value),
      ),
    );
  }
}

class _TabSpec {
  const _TabSpec({required this.label, required this.icon, required this.activeIcon});

  final String label;
  final IconData icon;
  final IconData activeIcon;
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({required this.index, required this.tabs, required this.onSelect});

  final int index;
  final List<_TabSpec> tabs;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          decoration: BoxDecoration(
            color: palette.surface.withValues(alpha: 0.92),
            border: Border(top: BorderSide(color: palette.divider)),
          ),
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: AppSpacing.navBarHeight,
              child: Row(
                children: <Widget>[
                  for (var i = 0; i < tabs.length; i++)
                    Expanded(
                      child: InkResponse(
                        onTap: () => onSelect(i),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              i == index ? tabs[i].activeIcon : tabs[i].icon,
                              size: 24,
                              color: i == index ? palette.accent : palette.textTertiary,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              tabs[i].label,
                              style: AppText.caption(
                                i == index ? palette.accent : palette.textTertiary,
                              ).copyWith(fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../state/player_controller.dart';
import '../home/home_page.dart';
import '../scan/scan_orb.dart';
import '../settings/settings_page.dart';
import '../widgets/mini_player.dart';
import '../widgets/pressable.dart';

/// Kerangka utama:
/// Beranda · [tombol Pindai menonjol di tengah] · Pengaturan.
///
/// Tombol tengah itu bukan tab — dia langsung menjalankan pemindaian dan
/// menampilkan animasinya sendiri, tanpa membuka halaman baru.
class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final hasTrack = context.select<PlayerController, bool>((p) => p.hasTrack);
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final navHeight = AppSpacing.navBarHeight + inset + AppSpacing.xs;

    return Scaffold(
      backgroundColor: palette.bg,
      extendBody: true,
      body: DecoratedBox(
        decoration: BoxDecoration(gradient: palette.pageGradient),
        child: Stack(
          children: <Widget>[
            IndexedStack(
              index: _index,
              children: const <Widget>[
                HomePage(),
                SettingsPage(),
              ],
            ),
            if (hasTrack)
              Positioned(
                left: 0,
                right: 0,
                bottom: navHeight + AppSpacing.xs,
                child: const MiniPlayer(),
              ),
            Positioned(
              left: AppSpacing.sm,
              right: AppSpacing.sm,
              bottom: hasTrack
                  ? navHeight + AppSpacing.xs + 72
                  : navHeight + AppSpacing.xs,
              child: const _PlaybackErrorBanner(),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _NavBar(
        index: _index,
        onSelect: (value) => setState(() => _index = value),
      ),
    );
  }
}

class _NavBar extends StatelessWidget {
  const _NavBar({required this.index, required this.onSelect});

  final int index;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final inset = MediaQuery.viewPaddingOf(context).bottom;
    final barTopFromBottom = AppSpacing.xs + inset + AppSpacing.navBarHeight;
    return SizedBox(
      height: barTopFromBottom + 34,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.sm, 0, AppSpacing.sm, AppSpacing.xs),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.sheet),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: <Color>[
                        Color.alphaBlend(
                          palette.gradientMid.withValues(alpha: 0.18),
                          palette.glassStrong,
                        ),
                        palette.glass,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(AppRadius.sheet),
                    border: Border.all(color: palette.glassBorder, width: 1.2),
                    boxShadow: AppShadow.l1(palette.accent),
                  ),
                  child: SafeArea(
                    top: false,
                    child: SizedBox(
                      height: AppSpacing.navBarHeight,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: _NavItem(
                              label: 'Beranda',
                              icon: Icons.home_outlined,
                              activeIcon: Icons.home_rounded,
                              selected: index == 0,
                              onTap: () => onSelect(0),
                            ),
                          ),
                          // Ruang untuk tombol tengah yang menonjol ke atas.
                          const SizedBox(width: 84),
                          Expanded(
                            child: _NavItem(
                              label: 'Pengaturan',
                              icon: Icons.tune_outlined,
                              activeIcon: Icons.tune_rounded,
                              selected: index == 1,
                              onTap: () => onSelect(1),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Tombol pindai menonjol: separuh badannya naik di atas bar.
          Positioned(
            bottom: barTopFromBottom - 31,
            child: const ScanOrb(),
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final IconData activeIcon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return PressableScale(
      scale: 0.94,
      onTap: onTap,
      child: Center(
        child: AnimatedContainer(
          duration: AppMotion.normal,
          curve: Curves.easeOutCubic,
          padding: EdgeInsets.symmetric(horizontal: selected ? AppSpacing.sm : AppSpacing.xs, vertical: 6),
          decoration: BoxDecoration(
            gradient: selected ? palette.accentGradient : null,
            borderRadius: BorderRadius.circular(AppRadius.chip),
            boxShadow: selected ? AppShadow.accent(palette.accent) : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(
                selected ? activeIcon : icon,
                size: 21,
                color: selected ? Colors.white : palette.textTertiary,
              ),
              AnimatedSize(
                duration: AppMotion.normal,
                curve: Curves.easeOutCubic,
                child: selected
                    ? Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Text(
                          label,
                          style: AppText.caption(Colors.white).copyWith(fontWeight: FontWeight.w700),
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PlaybackErrorBanner extends StatelessWidget {
  const _PlaybackErrorBanner();

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final player = context.read<PlayerController>();
    return ValueListenableBuilder<String?>(
      valueListenable: player.playbackError,
      builder: (context, message, _) {
        final visible = message != null && message.isNotEmpty;
        return IgnorePointer(
          ignoring: !visible,
          child: AnimatedSlide(
            offset: visible ? Offset.zero : const Offset(0, 0.4),
            duration: AppMotion.normal,
            curve: Curves.easeOutCubic,
            child: AnimatedOpacity(
              duration: AppMotion.normal,
              opacity: visible ? 1 : 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 8),
                decoration: BoxDecoration(
                  color: palette.danger.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(AppRadius.button),
                  border: Border.all(color: palette.danger.withValues(alpha: 0.35)),
                ),
                child: Row(
                  children: <Widget>[
                    Icon(Icons.error_outline_rounded, size: 18, color: palette.danger),
                    const SizedBox(width: AppSpacing.xs),
                    Expanded(
                      child: Text(
                        message ?? '',
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: AppText.caption(palette.danger).copyWith(fontSize: 11.5),
                      ),
                    ),
                    PressableScale(
                      onTap: () => player.playbackError.value = null,
                      child: Icon(Icons.close_rounded, size: 16, color: palette.danger),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../core/theme/app_palette.dart';
import '../core/theme/app_text.dart';
import '../core/theme/app_tokens.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 600),
  )..forward();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Scaffold(
      backgroundColor: palette.bg,
      body: Center(
        child: FadeTransition(
          opacity: _controller,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.9, end: 1).animate(
              CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    gradient: palette.accentGradient,
                    shape: BoxShape.circle,
                    boxShadow: AppShadow.accent(palette.accent),
                  ),
                  child: const Icon(Icons.graphic_eq_rounded, color: Colors.white, size: 44),
                ),
                const SizedBox(height: AppSpacing.lg),
                Text('Amber', style: AppText.display(palette.textPrimary)),
                const SizedBox(height: AppSpacing.xxs),
                Text('Musik lu, offline, tanpa gangguan.', style: AppText.subtitle(palette.textSecondary)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

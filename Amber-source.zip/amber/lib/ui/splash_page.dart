import 'package:flutter/material.dart';

import '../core/theme/app_palette.dart';
import '../core/theme/app_text.dart';
import '../core/theme/app_tokens.dart';

/// Layar pembuka: logo Kola muncul, garis cahaya menyapu, lalu nama aplikasi.
///
/// Semua gerak memakai satu AnimationController (1,9 detik) supaya ringan dan
/// tidak "berlebihan": tanpa bounce, tanpa efek neon — hanya skala, fade, dan
/// sapuan gradasi tipis.
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1900),
  )..forward();

  late final Animation<double> _logoFade = CurvedAnimation(
    parent: _controller,
    curve: const Interval(0.05, 0.45, curve: Curves.easeOut),
  );

  late final Animation<double> _logoScale = Tween<double>(begin: 0.86, end: 1).animate(
    CurvedAnimation(parent: _controller, curve: const Interval(0.05, 0.55, curve: Curves.easeOutCubic)),
  );

  late final Animation<double> _ringSpread = CurvedAnimation(
    parent: _controller,
    curve: const Interval(0.20, 0.85, curve: Curves.easeOutCubic),
  );

  late final Animation<double> _textFade = CurvedAnimation(
    parent: _controller,
    curve: const Interval(0.45, 0.85, curve: Curves.easeOut),
  );

  late final Animation<Offset> _textSlide = Tween<Offset>(
    begin: const Offset(0, 0.35),
    end: Offset.zero,
  ).animate(CurvedAnimation(parent: _controller, curve: const Interval(0.45, 0.9, curve: Curves.easeOutCubic)));

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return Scaffold(
      backgroundColor: palette.bg,
      body: DecoratedBox(
        decoration: BoxDecoration(gradient: palette.pageGradient),
        child: SizedBox.expand(
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              // Dua cincin tipis yang melebar pelan di belakang logo.
              AnimatedBuilder(
                animation: _ringSpread,
                builder: (context, _) {
                  return Stack(
                    alignment: Alignment.center,
                    children: <Widget>[
                      _Ring(progress: _ringSpread.value, size: 190, color: palette.gradientStart),
                      _Ring(
                        progress: (_ringSpread.value - 0.18).clamp(0.0, 1.0),
                        size: 150,
                        color: palette.gradientEnd,
                      ),
                    ],
                  );
                },
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  FadeTransition(
                    opacity: _logoFade,
                    child: ScaleTransition(
                      scale: _logoScale,
                      child: Container(
                        width: 132,
                        height: 132,
                        decoration: BoxDecoration(
                          gradient: palette.warmGradient,
                          borderRadius: BorderRadius.circular(36),
                          boxShadow: AppShadow.accent(palette.accent),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: Stack(
                          children: <Widget>[
                            Center(
                              child: Image.asset(
                                'assets/branding/kola_mark_white.png',
                                width: 84,
                                filterQuality: FilterQuality.medium,
                              ),
                            ),
                            // Sapuan cahaya diagonal, sekali jalan.
                            AnimatedBuilder(
                              animation: _controller,
                              builder: (context, _) {
                                final t = _controller.value;
                                if (t < 0.15 || t > 0.75) return const SizedBox.shrink();
                                final progress = ((t - 0.15) / 0.6).clamp(0.0, 1.0);
                                return Positioned(
                                  left: -140 + progress * 280,
                                  top: 0,
                                  bottom: 0,
                                  child: Transform.rotate(
                                    angle: 0.35,
                                    child: Container(
                                      width: 46,
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: <Color>[
                                            Colors.white.withValues(alpha: 0.0),
                                            Colors.white.withValues(alpha: 0.22),
                                            Colors.white.withValues(alpha: 0.0),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  FadeTransition(
                    opacity: _textFade,
                    child: SlideTransition(
                      position: _textSlide,
                      child: Column(
                        children: <Widget>[
                          Text(
                            'KOLA',
                            style: AppText.display(palette.textPrimary).copyWith(
                              fontSize: 30,
                              letterSpacing: 7,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'OFFLINE MUSIC',
                            style: AppText.overline(palette.textTertiary).copyWith(letterSpacing: 3.2),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Ring extends StatelessWidget {
  const _Ring({required this.progress, required this.size, required this.color});

  final double progress;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    if (progress <= 0 || progress >= 1) return const SizedBox.shrink();
    final scale = 0.7 + progress * 0.75;
    return Transform.scale(
      scale: scale,
      child: Opacity(
        opacity: (1 - progress).clamp(0.0, 1.0) * 0.45,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: color.withValues(alpha: 0.7), width: 1.4),
          ),
        ),
      ),
    );
  }
}

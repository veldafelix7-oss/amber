import 'package:flutter/material.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/theme/app_text.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../data/models/track.dart';
import '../../widgets/artwork.dart';
import '../../widgets/pressable.dart';

/// Kartu lagu horizontal (cover + judul + artis) untuk baris "Terakhir diputar".
class TrackCard extends StatelessWidget {
  const TrackCard({
    super.key,
    required this.track,
    required this.onTap,
    this.onLongPress,
    this.size = 132,
  });

  final Track track;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final double size;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return PressableScale(
      onTap: onTap,
      onLongPress: onLongPress,
      scale: 0.96,
      child: SizedBox(
        width: size,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.artwork),
                boxShadow: AppShadow.l1(palette.accent),
              ),
              child: Artwork(
                trackId: track.id,
                size: size,
                radius: AppRadius.artwork,
                label: track.title,
              ),
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              track.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppText.title(palette.textPrimary).copyWith(fontSize: 13.5, height: 1.25),
            ),
            const SizedBox(height: 2),
            Text(
              track.displayArtist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppText.caption(palette.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

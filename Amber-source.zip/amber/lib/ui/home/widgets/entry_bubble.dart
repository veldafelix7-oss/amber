import 'package:flutter/material.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/theme/app_text.dart';
import '../../../core/theme/app_tokens.dart';
import '../../widgets/pressable.dart';

/// Kartu masuk beranda (Lagu · Pustaka · Playlist).
///
/// Bentuknya bulat penuh dengan gradasi oren→putih, ikon putih di tengah, dan
/// sedikit kaca di tepinya supaya menyatu dengan latar.
class EntryBubble extends StatelessWidget {
  const EntryBubble({
    super.key,
    required this.label,
    required this.caption,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final String caption;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return PressableScale(
      onTap: onTap,
      scale: 0.95,
      child: Column(
        children: <Widget>[
          AspectRatio(
            aspectRatio: 1,
            child: Container(
              decoration: BoxDecoration(
                gradient: palette.warmGradient,
                borderRadius: BorderRadius.circular(AppRadius.sheet),
                border: Border.all(color: Colors.white.withValues(alpha: 0.55), width: 1.2),
                boxShadow: AppShadow.accent(palette.accent),
              ),
              child: Center(
                child: Icon(icon, color: Colors.white, size: 30),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppText.caption(palette.textPrimary).copyWith(fontWeight: FontWeight.w700, fontSize: 12),
          ),
          Text(
            caption,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppText.caption(palette.textTertiary),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/format.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../library/library_page.dart';
import '../playlist/playlists_page.dart';
import '../songs/songs_page.dart';
import '../widgets/pressable.dart';
import '../widgets/section_header.dart';
import '../widgets/song_tile.dart';
import '../widgets/track_menu.dart';
import 'widgets/entry_bubble.dart';
import 'widgets/track_card.dart';

/// Beranda: tanpa sapaan, langsung ke isi.
///
/// Susunan: judul aplikasi → tiga kartu masuk (Lagu, Pustaka, Playlist) →
/// Terakhir diputar → Baru ditambahkan → Favorit.
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final player = context.read<PlayerController>();

    final recents = library.recentlyPlayed;
    final added = library.recentlyAdded;
    final favorites = library.favoriteTracks;
    final totalBytes = library.allTracks.fold<int>(0, (sum, track) => sum + track.size);

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 250),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.screenH, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        gradient: palette.warmGradient,
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: const Icon(Icons.graphic_eq_rounded, size: 18, color: Colors.white),
                    ),
                    const SizedBox(width: AppSpacing.xs),
                    Text('Amber', style: AppText.display(palette.textPrimary)),
                  ],
                ),
                const SizedBox(height: AppSpacing.xxs),
                Text(
                  library.totalTracks == 0
                      ? 'Belum ada lagu di perangkat ini'
                      : '${library.totalTracks} lagu · ${Fmt.fileSize(totalBytes)}',
                  style: AppText.subtitle(palette.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.lg),

          // ---- Tiga kartu masuk utama ----
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: EntryBubble(
                    label: 'Lagu',
                    caption: '${library.totalTracks}',
                    icon: Icons.music_note_rounded,
                    onTap: () => _open(context, const SongsPage()),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: EntryBubble(
                    label: 'Pustaka',
                    caption: '${library.albums.length} album',
                    icon: Icons.album_rounded,
                    onTap: () => _open(context, const LibraryPage()),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: EntryBubble(
                    label: 'Playlist',
                    caption: '${library.playlists.length}',
                    icon: Icons.queue_music_rounded,
                    onTap: () => _open(context, const PlaylistsPage()),
                  ),
                ),
              ],
            ),
          ),

          if (library.totalTracks == 0) ...<Widget>[
            const SizedBox(height: AppSpacing.xl),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
              child: GlassPanel(
                tint: true,
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Perpustakaan masih kosong', style: AppText.section(palette.textPrimary)),
                    const SizedBox(height: AppSpacing.xxs),
                    Text(
                      'Tekan tombol pindai di tengah navigasi untuk mencari file audio di perangkat ini.',
                      style: AppText.subtitle(palette.textSecondary),
                    ),
                  ],
                ),
              ),
            ),
          ],

          // ---- Baru ditambahkan (paling atas, kartu ke samping) ----
          if (added.isNotEmpty) ...<Widget>[
            const SectionHeader(title: 'Baru ditambahkan'),
            SizedBox(
              height: 196,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
                itemCount: added.length.clamp(0, 12),
                separatorBuilder: (context, index) => const SizedBox(width: AppSpacing.sm),
                itemBuilder: (context, index) {
                  final track = added[index];
                  return TrackCard(
                    track: track,
                    onTap: () => player.playOne(track, context: added),
                    onLongPress: () => showTrackMenu(context, track),
                  );
                },
              ),
            ),
          ],

          // ---- Terakhir diputar (daftar ke bawah, bukan ke samping) ----
          if (recents.isNotEmpty) ...<Widget>[
            SectionHeader(
              title: 'Terakhir diputar',
              actionLabel: recents.length > 6 ? 'Lihat semua' : null,
              onAction: recents.length > 6 ? () => _open(context, _RecentPage(tracks: recents)) : null,
            ),
            for (final track in recents.take(6))
              SongTile(
                track: track,
                onTap: () => player.playOne(track, context: recents),
                onLongPress: () => showTrackMenu(context, track),
              ),
          ],

          if (favorites.isNotEmpty) ...<Widget>[
            SectionHeader(
              title: 'Favorit',
              actionLabel: 'Lihat semua',
              onAction: () => _open(context, _RecentPage(tracks: favorites, title: 'Favorit')),
            ),
            for (final track in favorites.take(4))
              SongTile(
                track: track,
                onTap: () => player.playOne(track, context: favorites),
                onLongPress: () => showTrackMenu(context, track),
              ),
          ],
        ],
      ),
    );
  }

  void _open(BuildContext context, Widget page) {
    final palette = AppPalette.of(context);
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DecoratedBox(
          decoration: BoxDecoration(gradient: palette.pageGradient),
          child: Scaffold(backgroundColor: Colors.transparent, body: page),
        ),
      ),
    );
  }
}

class _RecentPage extends StatelessWidget {
  const _RecentPage({required this.tracks, this.title = 'Terakhir diputar'});

  final List<Track> tracks;
  final String title;

  @override
  Widget build(BuildContext context) {
    final player = context.read<PlayerController>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: Text(title)),
      body: ListView.builder(
        padding: const EdgeInsets.only(bottom: 120),
        itemCount: tracks.length,
        itemBuilder: (context, index) {
          final track = tracks[index];
          return SongTile(
            track: track,
            onTap: () => player.playOne(track, context: tracks),
            onLongPress: () => showTrackMenu(context, track),
          );
        },
      ),
    );
  }
}

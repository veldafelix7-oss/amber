import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_palette.dart';
import '../../core/theme/app_text.dart';
import '../../core/theme/app_tokens.dart';
import '../../core/utils/format.dart';
import '../../data/models/track.dart';
import '../../state/library_controller.dart';
import '../../state/player_controller.dart';
import '../settings/settings_page.dart';
import '../widgets/artwork.dart';
import '../widgets/empty_state.dart';
import '../widgets/section_header.dart';
import '../widgets/song_tile.dart';
import '../widgets/track_menu.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final player = context.read<PlayerController>();

    if (library.loading && !library.scanned) {
      return const Center(child: CircularProgressIndicator());
    }

    if (library.scanned && library.totalTracks == 0) {
      return SafeArea(
        child: Center(
          child: EmptyState(
            title: 'Belum ada musik',
            message: 'Taruh file MP3 di folder Music HP lu, terus tap Scan Sekarang.',
            actionLabel: 'Scan Sekarang',
            onAction: library.rescan,
            icon: Icons.library_music_rounded,
          ),
        ),
      );
    }

    final recentlyPlayed = library.recentlyPlayed;
    final recentlyAdded = library.recentlyAdded;
    final favorites = library.favoriteTracks;

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 120),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpacing.screenH, AppSpacing.md, AppSpacing.xs, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        Fmt.greeting(DateTime.now()),
                        style: AppText.caption(palette.textSecondary),
                      ),
                      const SizedBox(height: 2),
                      Text('Perpustakaan lu', style: AppText.display(palette.textPrimary)),
                      const SizedBox(height: AppSpacing.xxs),
                      Text(
                        '${library.totalTracks} lagu · ${Fmt.fileSize(library.allTracks.fold<int>(0, (s, t) => s + t.size))}',
                        style: AppText.subtitle(palette.textSecondary),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (context) => const SettingsPage()),
                  ),
                  icon: Icon(Icons.settings_outlined, color: palette.textSecondary),
                ),
              ],
            ),
          ),
          if (recentlyPlayed.isNotEmpty) ...<Widget>[
            const SectionHeader(title: 'Dengar lagi'),
            SizedBox(
              height: 210,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
                itemCount: recentlyPlayed.length.clamp(0, 10),
                separatorBuilder: (context, index) => const SizedBox(width: AppSpacing.sm),
                itemBuilder: (context, index) {
                  final track = recentlyPlayed[index];
                  return _TrackCard(
                    track: track,
                    onTap: () => player.playOne(track, context: recentlyPlayed),
                  );
                },
              ),
            ),
          ],
          if (recentlyAdded.isNotEmpty) ...<Widget>[
            const SectionHeader(title: 'Baru ditambah'),
            SizedBox(
              height: 210,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
                itemCount: recentlyAdded.length.clamp(0, 10),
                separatorBuilder: (context, index) => const SizedBox(width: AppSpacing.sm),
                itemBuilder: (context, index) {
                  final track = recentlyAdded[index];
                  return _TrackCard(
                    track: track,
                    onTap: () => player.playOne(track, context: recentlyAdded),
                  );
                },
              ),
            ),
          ],
          if (favorites.isNotEmpty) ...<Widget>[
            SectionHeader(
              title: 'Favorit lu',
              actionLabel: 'Lihat semua',
              onAction: () => _openAllFavorites(context, favorites),
            ),
            for (final track in favorites.take(3))
              SongTile(
                track: track,
                onTap: () => player.playOne(track, context: favorites),
                onLongPress: () => showTrackMenu(context, track),
              ),
          ],
        ],
      ),
    );
  }

  void _openAllFavorites(BuildContext context, List<Track> favorites) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) => Scaffold(
          appBar: AppBar(title: const Text('Favorit lu')),
          body: ListView.builder(
            itemCount: favorites.length,
            itemBuilder: (context, index) {
              final track = favorites[index];
              return SongTile(
                track: track,
                onTap: () => context.read<PlayerController>().playOne(track, context: favorites),
                onLongPress: () => showTrackMenu(context, track),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _TrackCard extends StatelessWidget {
  const _TrackCard({required this.track, required this.onTap});

  final Track track;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    return GestureDetector(
      onTap: onTap,
      onLongPress: () => showTrackMenu(context, track),
      child: SizedBox(
        width: 156,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Artwork(trackId: track.id, size: 156, radius: AppRadius.artwork, label: track.title),
            const SizedBox(height: AppSpacing.xs),
            Text(
              track.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppText.title(palette.textPrimary).copyWith(fontSize: 14),
            ),
            const SizedBox(height: 2),
            Text(
              track.displayArtist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppText.caption(palette.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

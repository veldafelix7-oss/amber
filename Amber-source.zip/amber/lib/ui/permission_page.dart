import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme/app_palette.dart';
import '../core/theme/app_text.dart';
import '../core/theme/app_tokens.dart';
import '../data/media_store_repository.dart';
import '../state/library_controller.dart';

/// Layar izin. Muncul kalau app belum boleh baca file audio.
class PermissionPage extends StatelessWidget {
  const PermissionPage({super.key});

  @override
  Widget build(BuildContext context) {
    final palette = AppPalette.of(context);
    final library = context.watch<LibraryController>();
    final permanentlyDenied = library.permission == PermissionState.permanentlyDenied;

    return Scaffold(
      backgroundColor: palette.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                width: 110,
                height: 110,
                decoration: BoxDecoration(color: palette.accentSoft, shape: BoxShape.circle),
                child: Icon(Icons.library_music_rounded, size: 48, color: palette.accent),
              ),
              const SizedBox(height: AppSpacing.xl),
              Text(
                'Izinkan Amber membaca musik',
                textAlign: TextAlign.center,
                style: AppText.display(palette.textPrimary),
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'Amber butuh izin baca file audio di HP lu. Tidak ada data yang dikirim keluar — '
                'lagu lu tetap di HP lu.',
                textAlign: TextAlign.center,
                style: AppText.subtitle(palette.textSecondary),
              ),
              const SizedBox(height: AppSpacing.xxl),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () async {
                    if (permanentlyDenied) {
                      await library.repository.openSettings();
                      return;
                    }
                    final granted = await library.requestPermission();
                    if (!granted && context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Izin ditolak. Amber belum bisa memindai musik.')),
                      );
                    }
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: palette.accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
                  ),
                  child: Text(
                    permanentlyDenied ? 'Buka pengaturan izin' : 'Izinkan',
                    style: AppText.title(Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              TextButton(
                onPressed: () async {
                  await library.rescan();
                },
                child: Text('Coba pindai tanpa izin', style: AppText.subtitle(palette.textSecondary)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

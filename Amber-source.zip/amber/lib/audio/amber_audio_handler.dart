import 'dart:async';
import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

import '../core/boot_log.dart';
import '../data/models/playlist.dart';
import '../data/models/track.dart';
import '../data/prefs_repository.dart';

/// Konfigurasi service notifikasi.
///
/// [accent] dipakai sebagai warna aksen kartu pemutar di panel notifikasi
/// (mengikuti tema yang dipilih user). Latar kartu tetap digambar Android,
/// jadi transparansi penuh tidak bisa dipaksa dari sini.
AudioServiceConfig buildAudioServiceConfig({Color? accent}) => AudioServiceConfig(
      androidNotificationChannelId: 'com.kola.music.channel.audio',
      androidNotificationChannelName: 'Pemutaran musik',
      androidNotificationChannelDescription: 'Kontrol pemutar musik Kola',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
      androidNotificationIcon: 'mipmap/ic_launcher',
      androidShowNotificationBadge: false,
      androidNotificationClickStartsActivity: true,
      notificationColor: accent,
      preloadArtwork: true,
      fastForwardInterval: Duration(seconds: 10),
      rewindInterval: Duration(seconds: 10),
    );

/// Sesi pemutaran yang dipulihkan dari snapshot.
class RestoredSession {
  const RestoredSession({
    required this.track,
    required this.position,
    required this.queueLength,
    required this.index,
  });

  final Track track;
  final Duration position;
  final int queueLength;
  final int index;
}

/// SATU-SATUNYA pemilik AudioPlayer di seluruh aplikasi.
///
/// Sejak v2.0.0 antrian dikelola manual: satu file dimuat sekali lewat
/// `setFilePath()` (cara paling langsung untuk file lokal), bukan playlist
/// AudioSource. Ini yang membuat tombol putar benar-benar memutar suara —
/// sebelumnya file tidak pernah termuat, jadi tombol berubah jadi pause tapi
/// posisi tetap 0:00.
///
/// Kalau satu file gagal dimuat (korup / hilang), lagu berikutnya dicoba dan
/// pesan errornya muncul di layar — tidak lagi diam-diam.
class AmberAudioHandler extends BaseAudioHandler with QueueHandler, SeekHandler {
  AmberAudioHandler(this._prefs);

  final PrefsRepository _prefs;
  final AudioPlayer _player = AudioPlayer();

  List<Track> _tracks = const <Track>[];
  int _index = 0;
  RepeatMode _repeat = RepeatMode.off;
  bool _shuffle = false;
  bool _resumeAfterInterruption = false;
  double _lastVolume = 1;
  Timer? _snapshotTimer;
  bool _advancing = false;
  int _loadToken = 0;

  /// Jalur mana yang terakhir berhasil (content:// atau path). Dipakai lebih
  /// dulu supaya lagu berikutnya tidak menunggu percobaan yang gagal.
  bool _preferContentUri = true;
  static const MethodChannel _mediaChannel = MethodChannel('amber/media');

  final StreamController<String?> _errorController = StreamController<String?>.broadcast();
  String? _lastError;

  AudioPlayer get player => _player;
  List<Track> get tracks => _tracks;
  bool get shuffleEnabled => _shuffle;
  RepeatMode get repeatMode => _repeat;
  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<String?> get errorStream => _errorController.stream;
  String? get lastError => _lastError;

  int get currentIndex {
    if (_tracks.isEmpty) return 0;
    return _index.clamp(0, _tracks.length - 1);
  }

  Track? get currentTrack => _tracks.isEmpty ? null : _tracks[currentIndex];

  void _reportError(String? message) {
    _lastError = message;
    if (!_errorController.isClosed) _errorController.add(message);
  }

  // ------------------------------------------------------------------ init

  Future<void> init() async {
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration.music());

      session.interruptionEventStream.listen((event) {
        if (event.begin) {
          _resumeAfterInterruption = _player.playing;
          switch (event.type) {
            case AudioInterruptionType.duck:
              _player.setVolume(0.3);
            case AudioInterruptionType.pause:
            case AudioInterruptionType.unknown:
              pause();
          }
        } else {
          switch (event.type) {
            case AudioInterruptionType.duck:
              _player.setVolume(_lastVolume);
            case AudioInterruptionType.pause:
              if (_resumeAfterInterruption) play();
              _resumeAfterInterruption = false;
            case AudioInterruptionType.unknown:
              _resumeAfterInterruption = false;
          }
        }
      });

      session.becomingNoisyEventStream.listen((_) => pause());
    } catch (error) {
      BootLog.add('audio session: $error');
    }

    _player.playbackEventStream.listen(
      _broadcastState,
      onError: (Object error, StackTrace stack) {
        BootLog.add('pemutar: $error');
      },
    );

    // Satu lagu selesai → lanjut sendiri.
    _player.processingStateStream.listen((state) {
      if (state != ProcessingState.completed) return;
      if (_advancing) return;
      _advancing = true;
      Future<void>(() async {
        try {
          if (_repeat == RepeatMode.one) {
            await _player.seek(Duration.zero);
            await _player.play();
          } else {
            await skipToNext(autoAdvance: true);
          }
        } finally {
          _advancing = false;
        }
      });
    });

    _broadcastState(_player.playbackEvent);
    _startSnapshotTimer();
  }

  // -------------------------------------------------------- broadcast state

  void _broadcastState(PlaybackEvent event) {
    final playing = _player.playing;
    playbackState.add(
      PlaybackState(
        controls: <MediaControl>[
          MediaControl.skipToPrevious,
          if (playing) MediaControl.pause else MediaControl.play,
          MediaControl.skipToNext,
        ],
        systemActions: const <MediaAction>{MediaAction.seek},
        androidCompactActionIndices: const <int>[0, 1, 2],
        processingState: switch (_player.processingState) {
          ProcessingState.idle => AudioProcessingState.idle,
          ProcessingState.loading => AudioProcessingState.loading,
          ProcessingState.buffering => AudioProcessingState.buffering,
          ProcessingState.ready => AudioProcessingState.ready,
          ProcessingState.completed => AudioProcessingState.completed,
        },
        playing: playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
        queueIndex: currentIndex,
      ),
    );
  }

  // --------------------------------------------------------------- queue

  Future<void> loadQueue(
    List<Track> tracks, {
    int startIndex = 0,
    Duration? initialPosition,
    bool autoPlay = true,
    bool shuffle = false,
    RepeatMode? repeat,
  }) async {
    if (tracks.isEmpty) return;
    _tracks = List<Track>.unmodifiable(tracks);
    _shuffle = shuffle;
    if (repeat != null) _repeat = repeat;
    queue.add(_tracks.map((track) => track.toMediaItem()).toList());
    await _loadIndex(
      startIndex.clamp(0, _tracks.length - 1),
      position: initialPosition ?? Duration.zero,
      autoPlay: autoPlay,
    );
  }

  /// Muat satu lagu ke pemutar.
  ///
  /// Ada tiga percobaan berurutan, karena di Android 11+ file yang berada di
  /// folder Download kadang tidak bisa dibuka lewat path biasa (dibatasi
  /// scoped storage) padahal bisa lewat MediaStore:
  ///   1. path file langsung
  ///   2. content:// MediaStore (butuh izin audio saja — sama seperti app
  ///      pemutar musik lain)
  ///   3. path file sekali lagi setelah jeda singkat (mengatasi error
  ///      "Loading interrupted" saat dua pemuatan bertabrakan)
  Future<void> _loadIndex(
    int index, {
    Duration position = Duration.zero,
    required bool autoPlay,
    int attempt = 0,
  }) async {
    if (_tracks.isEmpty) return;
    _index = index.clamp(0, _tracks.length - 1);
    final track = _tracks[_index];
    final token = ++_loadToken;

    mediaItem.add(track.toMediaItem());
    _prefs.pushRecent(track.id);
    _reportError(null);

    try {
      final duration = await _loadWithFallbacks(track, token);
      if (token != _loadToken) return; // sudah digantikan lagu lain
      if (duration != null) {
        mediaItem.add(track.toMediaItem().copyWith(duration: duration));
      }
      if (position > Duration.zero) {
        await _player.seek(position);
      }
      if (autoPlay) await _player.play();
    } catch (error) {
      if (token != _loadToken) return;
      BootLog.add('GAGAL memutar "${track.title}": $error');
      final probe = await _probeAudio(track);
      BootLog.add('cek berkas "${track.title}": $probe');
      _reportError(_readableError(error, track));
      if (attempt + 1 < _tracks.length) {
        final next = (_index + 1) % _tracks.length;
        await _loadIndex(next, autoPlay: autoPlay, attempt: attempt + 1);
      }
    }
  }

  /// Diagnosa berkas (dicatat di Log start-up, tidak mengganggu user).
  Future<String> _probeAudio(Track track) async {
    try {
      final result = await _mediaChannel
          .invokeMethod<String>('probeAudio', <String, Object?>{
            'path': track.path,
            'mediaId': track.id.toString(),
          })
          .timeout(const Duration(seconds: 6), onTimeout: () => null);
      return result ?? 'tidak ada jawaban';
    } catch (error) {
      return 'gagal: $error';
    }
  }

  Uri _contentUri(Track track) =>
      Uri.parse('content://media/external/audio/media/${track.id}');

  Future<Duration?> _loadWithFallbacks(Track track, int token) async {
    final errors = <String>[];
    const attempt = Duration(seconds: 6);

    Future<Duration?> viaContentUri() async {
      final duration = await _player
          .setAudioSource(AudioSource.uri(_contentUri(track)))
          .timeout(attempt, onTimeout: () => null);
      if (duration != null) _preferContentUri = true;
      return duration;
    }

    Future<Duration?> viaPath() async {
      final duration = await _player
          .setFilePath(track.path)
          .timeout(attempt, onTimeout: () => null);
      if (duration != null) _preferContentUri = false;
      return duration;
    }

    Future<Duration?> tryLoader(Future<Duration?> Function() loader, String label) async {
      try {
        final duration = await loader();
        if (duration != null) return duration;
        errors.add('$label: durasi kosong');
      } catch (error) {
        errors.add('$label: $error');
      }
      return null;
    }

    // Urutan mengikuti jalur yang terakhir berhasil.
    final first = _preferContentUri
        ? await tryLoader(viaContentUri, 'mediastore')
        : await tryLoader(viaPath, 'path');
    if (first != null) return first;
    if (token != _loadToken) return null;

    final second = _preferContentUri
        ? await tryLoader(viaPath, 'path')
        : await tryLoader(viaContentUri, 'mediastore');
    if (second != null) return second;
    if (token != _loadToken) return null;

    // Percobaan terakhir setelah jeda (mengatasi tabrakan pemuatan).
    try {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      if (token != _loadToken) return null;
      final last = await tryLoader(
        _preferContentUri ? viaContentUri : viaPath,
        'ulang',
      );
      if (last != null) {
        BootLog.add('pemutaran berhasil pada percobaan ketiga: ${track.title}');
        return last;
      }
    } catch (error) {
      errors.add('ulang: $error');
    }
    _preferContentUri = !_preferContentUri;
    throw Exception(errors.join(' | '));
  }

  String _readableError(Object error, Track track) {
    final raw = error.toString();
    String short = raw.length > 150 ? '${raw.substring(0, 150)}…' : raw;

    if (raw.contains('ENOENT') || raw.contains('No such file')) {
      return 'File hilang dari perangkat: ${track.title}';
    }
    if (raw.contains('Permission') || raw.contains('EACCES') || raw.contains('SecurityException')) {
      return 'Sistem menolak akses file. Jalankan Pindai ulang.';
    }
    if (raw.contains('Loading interrupted')) {
      return 'Berkas tidak bisa dibaca (dibatasi sistem). Coba lagi atau pindai ulang.';
    }
    if (raw.contains('UnrecognizedInputFormat') || raw.contains('Source error')) {
      return 'Berkas ini tidak bisa dibaca Amber, padahal bisa di app lain — kirim screenshot ini ke pengembang.';
    }
    return 'Gagal memutar ${track.title}: $short';
  }

  Future<void> appendToQueue(List<Track> tracks, {bool playNext = false}) async {
    if (tracks.isEmpty) return;
    final merged = <Track>[..._tracks];
    final insertAt = playNext ? currentIndex + 1 : merged.length;
    merged.insertAll(insertAt.clamp(0, merged.length), tracks);
    final current = currentTrack;
    final position = _player.position;
    final wasPlaying = _player.playing;
    _tracks = List<Track>.unmodifiable(merged);
    if (current != null) {
      _index = merged.indexWhere((t) => t.id == current.id);
    }
    queue.add(_tracks.map((track) => track.toMediaItem()).toList());
    if (playNext) {
      // Biarkan lagu aktif tetap berbunyi; antrian saja yang berubah.
      await _player.seek(position);
      if (!wasPlaying) await _player.pause();
    }
  }

  Future<void> playTracks(List<Track> tracks, {int startIndex = 0}) =>
      loadQueue(tracks, startIndex: startIndex, autoPlay: true, shuffle: _shuffle, repeat: _repeat);

  Future<void> setShuffle(bool enabled) async {
    _shuffle = enabled;
    if (_tracks.length <= 2) return;
    final current = currentTrack;
    final rest = <Track>[..._tracks]..removeWhere((track) => track.id == current?.id);
    if (enabled) {
      rest.shuffle();
    } else {
      rest.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    }
    _tracks = List<Track>.unmodifiable(<Track>[
      ?current,
      ...rest,
    ]);
    _index = 0;
    queue.add(_tracks.map((track) => track.toMediaItem()).toList());
    _broadcastState(_player.playbackEvent);
  }

  Future<void> setRepeat(RepeatMode mode) async {
    _repeat = mode;
    _broadcastState(_player.playbackEvent);
  }

  Future<void> removeFromQueue(int index) async {
    if (index < 0 || index >= _tracks.length) return;
    final remaining = <Track>[..._tracks]..removeAt(index);
    if (remaining.isEmpty) {
      await stop();
      _tracks = const <Track>[];
      return;
    }
    final wasCurrent = index == _index;
    _tracks = List<Track>.unmodifiable(remaining);
    queue.add(_tracks.map((track) => track.toMediaItem()).toList());
    if (wasCurrent) {
      await _loadIndex(index.clamp(0, _tracks.length - 1), autoPlay: _player.playing);
    } else if (index < _index) {
      _index--;
    }
  }

  // ------------------------------------------------------ BaseAudioHandler

  @override
  Future<void> play() async {
    if (_tracks.isEmpty) return;
    if (_player.processingState == ProcessingState.idle) {
      await _loadIndex(currentIndex, autoPlay: true);
      return;
    }
    await _player.play();
  }

  @override
  Future<void> pause() async {
    if (_prefs.fadeOnPause) {
      await _fadeTo(0, const Duration(milliseconds: 200));
    }
    await _player.pause();
    await _player.setVolume(_lastVolume);
    await _saveSnapshot();
  }

  @override
  Future<void> stop() async {
    await _saveSnapshot();
    await _player.stop();
    await super.stop();
  }

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> skipToNext({bool autoAdvance = false}) async {
    if (_tracks.isEmpty) return;
    final last = _tracks.length - 1;
    if (!autoAdvance && _repeat == RepeatMode.one) {
      await _loadIndex(currentIndex, autoPlay: true);
      return;
    }
    final next = currentIndex >= last ? 0 : currentIndex + 1;
    await _loadIndex(next, autoPlay: true);
  }

  @override
  Future<void> skipToPrevious() async {
    if (_tracks.isEmpty) return;
    if (_player.position.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    final prev = currentIndex <= 0 ? _tracks.length - 1 : currentIndex - 1;
    await _loadIndex(prev, autoPlay: true);
  }

  @override
  Future<void> skipToQueueItem(int index) async {
    if (index < 0 || index >= _tracks.length) return;
    await _loadIndex(index, autoPlay: true);
  }

  @override
  Future<void> seekForward(bool begin) async {
    if (begin) await _player.seek(_player.position + const Duration(seconds: 10));
  }

  @override
  Future<void> seekBackward(bool begin) async {
    if (begin) await _player.seek(_player.position - const Duration(seconds: 10));
  }

  @override
  Future<void> setSpeed(double speed) => _player.setSpeed(speed);

  // ------------------------------------------------------------- utilities

  Future<void> setVolume(double value) async {
    _lastVolume = value.clamp(0.0, 1.0);
    await _player.setVolume(_lastVolume);
  }

  double get volume => _lastVolume;

  Future<void> _fadeTo(double target, Duration duration) async {
    const steps = 8;
    final stepTime = Duration(milliseconds: duration.inMilliseconds ~/ steps);
    final start = _player.volume;
    for (var i = 1; i <= steps; i++) {
      await _player.setVolume(start + (target - start) * (i / steps));
      await Future<void>.delayed(stepTime);
    }
  }

  /// Fade-out halus lalu pause — dipakai sleep timer.
  Future<void> fadeOutAndPause({Duration fade = const Duration(seconds: 3)}) async {
    await _fadeTo(0, fade);
    await _player.pause();
    await _player.setVolume(_lastVolume);
    await _saveSnapshot();
  }

  /// Sisipkan artwork ke mediaItem (supaya notifikasi punya cover).
  Future<void> updateArtwork(Uri? artUri) async {
    final current = mediaItem.value;
    if (current == null) return;
    mediaItem.add(current.copyWith(artUri: artUri));
  }

  /// Simpan artwork ke file cache supaya bisa dipakai notifikasi.
  Future<Uri?> cacheArtworkBytes(List<int> bytes, int trackId) async {
    try {
      final dir = Directory('${Directory.systemTemp.path}/amber_art');
      if (!dir.existsSync()) dir.createSync(recursive: true);
      final file = File('${dir.path}/art_$trackId.jpg');
      if (!file.existsSync()) file.writeAsBytesSync(bytes, flush: true);
      return Uri.file(file.path);
    } catch (error) {
      debugPrint('[Amber] gagal cache artwork: $error');
      return null;
    }
  }

  // ------------------------------------------------------------- snapshot

  void _startSnapshotTimer() {
    _snapshotTimer?.cancel();
    _snapshotTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (_player.playing) _saveSnapshot();
    });
  }

  Future<void> _saveSnapshot() async {
    final track = currentTrack;
    if (track == null) return;
    final start = (currentIndex - 20).clamp(0, _tracks.length);
    final end = (currentIndex + 180).clamp(0, _tracks.length);
    final window = _tracks.sublist(start, end);
    await _prefs.saveSnapshot(
      trackId: track.id,
      positionMs: _player.position.inMilliseconds,
      queue: window,
      queueIndex: currentIndex - start,
    );
  }

  /// Pulihkan sesi terakhir TANPA auto-play (anti kaget jam 3 pagi).
  Future<RestoredSession?> restoreSession({bool autoPlay = false}) async {
    final snapshot = _prefs.snapshot;
    if (snapshot == null) return null;
    try {
      final rawQueue = (snapshot['queue'] as List<dynamic>? ?? const <dynamic>[]);
      final restored = <Track>[];
      for (final item in rawQueue) {
        final track = Track.fromJson(item as Map<String, dynamic>);
        if (track.path.isEmpty) continue;
        if (!File(track.path).existsSync()) continue;
        restored.add(track);
      }
      if (restored.isEmpty) return null;

      final index = ((snapshot['queueIndex'] as num?)?.toInt() ?? 0).clamp(0, restored.length - 1);
      final position = Duration(milliseconds: (snapshot['positionMs'] as num?)?.toInt() ?? 0);

      await loadQueue(
        restored,
        startIndex: index,
        initialPosition: position,
        autoPlay: autoPlay,
        shuffle: false,
        repeat: _repeat,
      );
      return RestoredSession(
        track: restored[index],
        position: position,
        queueLength: restored.length,
        index: index,
      );
    } catch (error) {
      BootLog.add('pulihkan sesi: $error');
      return null;
    }
  }

  @override
  Future<void> onTaskRemoved() async {
    await _saveSnapshot();
    await super.onTaskRemoved();
  }

  Future<void> disposePlayer() async {
    _snapshotTimer?.cancel();
    await _errorController.close();
    await _player.dispose();
  }
}

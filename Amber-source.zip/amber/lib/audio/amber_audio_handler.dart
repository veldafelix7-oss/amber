import 'dart:async';
import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../data/models/playlist.dart';
import '../data/models/track.dart';
import '../data/prefs_repository.dart';

/// Konfigurasi service: notifikasi tidak bisa di-swipe saat playing,
/// artwork di-preload, dan channel notifikasi punya nama sendiri.
AudioServiceConfig buildAudioServiceConfig() => const AudioServiceConfig(
      androidNotificationChannelId: 'com.amber.music.channel.audio',
      androidNotificationChannelName: 'Pemutaran musik',
      androidNotificationChannelDescription: 'Kontrol pemutar musik Amber',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
      androidNotificationIcon: 'mipmap/ic_launcher',
      androidShowNotificationBadge: false,
      androidNotificationClickStartsActivity: true,
      preloadArtwork: true,
      fastForwardInterval: Duration(seconds: 10),
      rewindInterval: Duration(seconds: 10),
    );

/// Sesi pemutaran yang dipulihkan dari snapshot.
class RestoredSession {
  const RestoredSession({
    required this.track,
    required this.position,
    required this.queueLength,
    required this.index,
  });

  final Track track;
  final Duration position;
  final int queueLength;
  final int index;
}

/// SATU-SATUNYA pemilik AudioPlayer di seluruh aplikasi.
///
/// Aturan yang dipegang file ini:
/// 1. Widget/provider tidak boleh membuat AudioPlayer sendiri.
/// 2. Semua state yang dilihat UI berasal dari playbackState + mediaItem.
/// 3. Audio focus dijaga lewat audio_session (telepon masuk, headset dicabut).
/// 4. Posisi disnapshot tiap 5 detik supaya bisa dipulihkan tanpa auto-play.
class AmberAudioHandler extends BaseAudioHandler with QueueHandler, SeekHandler {
  AmberAudioHandler(this._prefs);

  final PrefsRepository _prefs;
  final AudioPlayer _player = AudioPlayer();

  List<Track> _tracks = const <Track>[];
  RepeatMode _repeat = RepeatMode.off;
  bool _shuffle = false;
  bool _resumeAfterInterruption = false;
  double _lastVolume = 1;
  Timer? _snapshotTimer;

  AudioPlayer get player => _player;
  List<Track> get tracks => _tracks;
  bool get shuffleEnabled => _shuffle;
  RepeatMode get repeatMode => _repeat;
  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;

  int get currentIndex {
    final index = _player.currentIndex;
    if (index == null || index < 0 || index >= _tracks.length) return 0;
    return index;
  }

  Track? get currentTrack => _tracks.isEmpty ? null : _tracks[currentIndex];

  LoopMode get _loopMode => switch (_repeat) {
        RepeatMode.off => LoopMode.off,
        RepeatMode.all => LoopMode.all,
        RepeatMode.one => LoopMode.one,
      };

  // ------------------------------------------------------------------ init

  Future<void> init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());

    // Telepon masuk / app lain minta fokus → pause; selesai → lanjut lagi.
    session.interruptionEventStream.listen((event) {
      if (event.begin) {
        _resumeAfterInterruption = _player.playing;
        switch (event.type) {
          case AudioInterruptionType.duck:
            _player.setVolume(0.3);
          case AudioInterruptionType.pause:
          case AudioInterruptionType.unknown:
            pause();
        }
      } else {
        switch (event.type) {
          case AudioInterruptionType.duck:
            _player.setVolume(_lastVolume);
          case AudioInterruptionType.pause:
            if (_resumeAfterInterruption) play();
            _resumeAfterInterruption = false;
          case AudioInterruptionType.unknown:
            _resumeAfterInterruption = false;
        }
      }
    });

    // Headset kabel dicabut / bluetooth putus → pause.
    session.becomingNoisyEventStream.listen((_) => pause());

    _player.playbackEventStream.listen(
      _broadcastState,
      onError: (Object error, StackTrace stack) {
        debugPrint('[Amber] playback error: $error');
        _skipBrokenTrack();
      },
    );

    _player.currentIndexStream.listen((index) {
      if (index == null || index < 0 || index >= _tracks.length) return;
      final track = _tracks[index];
      mediaItem.add(track.toMediaItem());
      _prefs.pushRecent(track.id);
    });

    _startSnapshotTimer();
  }

  // -------------------------------------------------------- broadcast state

  void _broadcastState(PlaybackEvent event) {
    final playing = _player.playing;
    playbackState.add(
      PlaybackState(
        controls: <MediaControl>[
          MediaControl.skipToPrevious,
          if (playing) MediaControl.pause else MediaControl.play,
          MediaControl.skipToNext,
        ],
        systemActions: const <MediaAction>{MediaAction.seek},
        androidCompactActionIndices: const <int>[0, 1, 2],
        processingState: switch (_player.processingState) {
          ProcessingState.idle => AudioProcessingState.idle,
          ProcessingState.loading => AudioProcessingState.loading,
          ProcessingState.buffering => AudioProcessingState.buffering,
          ProcessingState.ready => AudioProcessingState.ready,
          ProcessingState.completed => AudioProcessingState.completed,
        },
        playing: playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
        queueIndex: event.currentIndex,
      ),
    );
  }

  // --------------------------------------------------------------- queue

  /// Muat antrian baru lalu (opsional) langsung main.
  Future<void> loadQueue(
    List<Track> tracks, {
    int startIndex = 0,
    Duration? initialPosition,
    bool autoPlay = true,
    bool shuffle = false,
    RepeatMode? repeat,
  }) async {
    if (tracks.isEmpty) return;

    _tracks = List<Track>.unmodifiable(tracks);
    _shuffle = shuffle;
    if (repeat != null) _repeat = repeat;

    queue.add(_tracks.map((track) => track.toMediaItem()).toList());

    final index = startIndex.clamp(0, _tracks.length - 1);
    await _player.setAudioSources(
      <AudioSource>[
        for (final track in _tracks) AudioSource.uri(Uri.file(track.path), tag: track.toMediaItem()),
      ],
      initialIndex: index,
      initialPosition: initialPosition ?? Duration.zero,
    );
    await _player.setLoopMode(_loopMode);
    await _player.setShuffleModeEnabled(_shuffle);
    mediaItem.add(_tracks[index].toMediaItem());

    if (autoPlay) await play();
  }

  Future<void> appendToQueue(List<Track> tracks, {bool playNext = false}) async {
    if (tracks.isEmpty) return;
    final current = currentTrack;
    final merged = <Track>[..._tracks];
    final insertAt = playNext ? currentIndex + 1 : merged.length;
    merged.insertAll(insertAt, tracks);
    await loadQueue(
      merged,
      startIndex: currentIndex,
      initialPosition: _player.position,
      autoPlay: _player.playing,
      shuffle: _shuffle,
      repeat: _repeat,
    );
    if (current == null) return;
  }

  Future<void> playTracks(List<Track> tracks, {int startIndex = 0}) =>
      loadQueue(tracks, startIndex: startIndex, autoPlay: true, shuffle: _shuffle, repeat: _repeat);

  Future<void> setShuffle(bool enabled) async {
    _shuffle = enabled;
    await _player.setShuffleModeEnabled(enabled);
    if (enabled) {
      // Acak ulang dari posisi sekarang supaya lagu aktif tidak berubah.
      await _player.shuffle();
    }
  }

  Future<void> setRepeat(RepeatMode mode) async {
    _repeat = mode;
    await _player.setLoopMode(_loopMode);
  }

  Future<void> removeFromQueue(int index) async {
    if (index < 0 || index >= _tracks.length) return;
    final remaining = <Track>[..._tracks]..removeAt(index);
    if (remaining.isEmpty) {
      await stop();
      return;
    }
    final wasPlaying = _player.playing;
    final newIndex = index < currentIndex ? currentIndex - 1 : currentIndex;
    final position = index == currentIndex ? Duration.zero : _player.position;
    await loadQueue(
      remaining,
      startIndex: newIndex.clamp(0, remaining.length - 1),
      initialPosition: position,
      autoPlay: wasPlaying,
      shuffle: _shuffle,
      repeat: _repeat,
    );
  }

  // ------------------------------------------------------ BaseAudioHandler

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() async {
    if (_prefs.fadeOnPause) {
      await _fadeTo(0, const Duration(milliseconds: 200));
    }
    await _player.pause();
    await _player.setVolume(_lastVolume);
    await _saveSnapshot();
  }

  @override
  Future<void> stop() async {
    await _saveSnapshot();
    await _player.stop();
    await super.stop();
  }

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> skipToNext() async {
    if (_repeat == RepeatMode.one) await _player.seek(Duration.zero, index: currentIndex);
    await _player.seekToNext();
    if (!_player.playing) await _player.play();
  }

  @override
  Future<void> skipToPrevious() async {
    if (_player.position.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    await _player.seekToPrevious();
    if (!_player.playing) await _player.play();
  }

  @override
  Future<void> skipToQueueItem(int index) async {
    await _player.seek(Duration.zero, index: index);
    if (!_player.playing) await _player.play();
  }

  @override
  Future<void> seekForward(bool begin) async {
    if (begin) await _player.seek(_player.position + const Duration(seconds: 10));
  }

  @override
  Future<void> seekBackward(bool begin) async {
    if (begin) await _player.seek(_player.position - const Duration(seconds: 10));
  }

  @override
  Future<void> setSpeed(double speed) => _player.setSpeed(speed);

  // ------------------------------------------------------------- utilities

  Future<void> setVolume(double value) async {
    _lastVolume = value.clamp(0.0, 1.0);
    await _player.setVolume(_lastVolume);
  }

  double get volume => _lastVolume;

  Future<void> _fadeTo(double target, Duration duration) async {
    const steps = 8;
    final stepTime = Duration(milliseconds: duration.inMilliseconds ~/ steps);
    final start = _player.volume;
    for (var i = 1; i <= steps; i++) {
      await _player.setVolume(start + (target - start) * (i / steps));
      await Future<void>.delayed(stepTime);
    }
  }

  /// Fade-out halus lalu pause — dipakai sleep timer.
  Future<void> fadeOutAndPause({Duration fade = const Duration(seconds: 3)}) async {
    await _fadeTo(0, fade);
    await _player.pause();
    await _player.setVolume(_lastVolume);
    await _saveSnapshot();
  }

  /// File hilang / korup: lewati ke lagu berikutnya, jangan crash.
  Future<void> _skipBrokenTrack() async {
    try {
      if (_tracks.length <= 1) return;
      if (currentIndex >= _tracks.length - 1) return;
      await _player.seek(Duration.zero, index: currentIndex + 1);
      await _player.play();
    } catch (error) {
      debugPrint('[Amber] gagal skip lagu rusak: $error');
    }
  }

  /// Sisipkan artwork ke mediaItem (supaya notifikasi punya cover).
  Future<void> updateArtwork(Uri? artUri) async {
    final current = mediaItem.value;
    if (current == null) return;
    mediaItem.add(current.copyWith(artUri: artUri));
  }

  /// Simpan artwork ke file cache supaya bisa dipakai notifikasi.
  Future<Uri?> cacheArtworkBytes(List<int> bytes, int trackId) async {
    try {
      final dir = Directory('${Directory.systemTemp.path}/amber_art');
      if (!dir.existsSync()) dir.createSync(recursive: true);
      final file = File('${dir.path}/art_$trackId.jpg');
      if (!file.existsSync()) file.writeAsBytesSync(bytes, flush: true);
      return Uri.file(file.path);
    } catch (error) {
      debugPrint('[Amber] gagal cache artwork: $error');
      return null;
    }
  }

  // ------------------------------------------------------------- snapshot

  void _startSnapshotTimer() {
    _snapshotTimer?.cancel();
    _snapshotTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (_player.playing) _saveSnapshot();
    });
  }

  Future<void> _saveSnapshot() async {
    final track = currentTrack;
    if (track == null) return;
    // Simpan jendela antrian di sekitar lagu aktif biar prefs tidak bengkak.
    final start = (currentIndex - 20).clamp(0, _tracks.length);
    final end = (currentIndex + 180).clamp(0, _tracks.length);
    final window = _tracks.sublist(start, end);
    await _prefs.saveSnapshot(
      trackId: track.id,
      positionMs: _player.position.inMilliseconds,
      queue: window,
      queueIndex: currentIndex - start,
    );
  }

  /// Pulihkan sesi terakhir TANPA auto-play (anti kaget jam 3 pagi).
  Future<RestoredSession?> restoreSession({bool autoPlay = false}) async {
    final snapshot = _prefs.snapshot;
    if (snapshot == null) return null;
    try {
      final rawQueue = (snapshot['queue'] as List<dynamic>? ?? const <dynamic>[]);
      final restored = <Track>[];
      for (final item in rawQueue) {
        final track = Track.fromJson(item as Map<String, dynamic>);
        if (track.path.isEmpty) continue;
        if (!File(track.path).existsSync()) continue;
        restored.add(track);
      }
      if (restored.isEmpty) return null;

      final index = ((snapshot['queueIndex'] as num?)?.toInt() ?? 0).clamp(0, restored.length - 1);
      final position = Duration(milliseconds: (snapshot['positionMs'] as num?)?.toInt() ?? 0);

      await loadQueue(
        restored,
        startIndex: index,
        initialPosition: position,
        autoPlay: autoPlay,
        shuffle: false,
        repeat: _repeat,
      );
      return RestoredSession(
        track: restored[index],
        position: position,
        queueLength: restored.length,
        index: index,
      );
    } catch (error) {
      debugPrint('[Amber] gagal restore snapshot: $error');
      return null;
    }
  }

  @override
  Future<void> onTaskRemoved() async {
    await _saveSnapshot();
    await super.onTaskRemoved();
  }

  Future<void> disposePlayer() async {
    _snapshotTimer?.cancel();
    await _player.dispose();
  }
}

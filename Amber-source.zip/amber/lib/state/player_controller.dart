import 'dart:async';

import 'package:flutter/foundation.dart';

import '../audio/amber_audio_handler.dart';
import '../data/models/playlist.dart';
import '../data/models/track.dart';
import '../data/prefs_repository.dart';
import 'library_controller.dart';

/// Jembatan antara AudioHandler dan UI.
///
/// Posisi pemutaran sengaja ditaruh di [position] (ValueNotifier) supaya
/// progress bar bisa rebuild 4x/detik tanpa membuat seluruh layar ikut rebuild.
class PlayerController extends ChangeNotifier {
  PlayerController({
    required this.handler,
    required PrefsRepository prefs,
    required this.library,
  }) : _prefs = prefs {
    _bind();
  }

  final AmberAudioHandler handler;
  final LibraryController library;
  final PrefsRepository _prefs;

  final ValueNotifier<Duration> position = ValueNotifier<Duration>(Duration.zero);
  final ValueNotifier<Duration?> sleepRemaining = ValueNotifier<Duration?>(null);

  final List<StreamSubscription<dynamic>> _subs = <StreamSubscription<dynamic>>[];
  Timer? _sleepTicker;

  Track? _current;
  Duration _duration = Duration.zero;
  bool _playing = false;
  RepeatMode _repeat = RepeatMode.off;
  bool _shuffle = false;
  double _volume = 1;
  bool _restoredSession = false;
  int? _lastArtworkTrackId;

  Track? get current => _current;
  Duration get duration => _duration;
  bool get playing => _playing;
  bool get hasTrack => _current != null;
  RepeatMode get repeatMode => _repeat;
  bool get shuffle => _shuffle;
  double get volume => _volume;
  bool get restoredSession => _restoredSession;
  bool get sleepTimerActive => sleepRemaining.value != null;

  bool isCurrent(Track track) => _current?.id == track.id;
  bool isFavorite(int trackId) => library.favoriteIds.contains(trackId);

  void _bind() {
    _repeat = handler.repeatMode;
    _shuffle = handler.shuffleEnabled;

    _subs.add(handler.playbackState.listen((state) {
      final nowPlaying = state.playing;
      if (_playing != nowPlaying) {
        _playing = nowPlaying;
        notifyListeners();
      }
    }));

    _subs.add(handler.mediaItem.listen((item) {
      if (item == null) return;
      final id = int.tryParse(item.id);
      final track = id == null ? null : library.trackById(id);
      _duration = item.duration ?? Duration.zero;
      if (track != null && (_current?.id != track.id)) {
        _current = track;
        _restoredSession = false;
        notifyListeners();
        _attachArtwork(track);
        library.refreshRecents();
      } else if (track == null && _current == null) {
        notifyListeners();
      }
    }));

    _subs.add(handler.positionStream.listen((value) => position.value = value));
  }

  /// Ambil artwork untuk notifikasi & lock screen (best-effort).
  Future<void> _attachArtwork(Track track) async {
    if (_lastArtworkTrackId == track.id) return;
    _lastArtworkTrackId = track.id;
    try {
      final bytes = await library.artworkFor(track.id, size: 500);
      if (bytes == null) return;
      final uri = await handler.cacheArtworkBytes(bytes, track.id);
      if (uri != null) await handler.updateArtwork(uri);
    } catch (error) {
      debugPrint('[Amber] artwork gagal: $error');
    }
  }

  // ------------------------------------------------------------- commands

  Future<void> playTracks(List<Track> tracks, {int startIndex = 0}) async {
    if (tracks.isEmpty) return;
    await handler.loadQueue(tracks, startIndex: startIndex, autoPlay: true);
    _syncFromHandler();
  }

  Future<void> playOne(Track track, {List<Track>? context}) async {
    final list = context ?? <Track>[track];
    final index = list.indexWhere((t) => t.id == track.id);
    await playTracks(list, startIndex: index < 0 ? 0 : index);
  }

  Future<void> playNext(Track track) => handler.appendToQueue(<Track>[track], playNext: true);

  Future<void> addToQueue(Track track) => handler.appendToQueue(<Track>[track]);

  Future<void> togglePlay() async {
    if (_current == null && handler.currentTrack == null) return;
    if (_playing) {
      await handler.pause();
    } else {
      await handler.play();
    }
  }

  Future<void> next() => handler.skipToNext();

  Future<void> previous() => handler.skipToPrevious();

  Future<void> seek(Duration position) async {
    await handler.seek(position);
    this.position.value = position;
  }

  Future<void> toggleShuffle() async {
    _shuffle = !_shuffle;
    await handler.setShuffle(_shuffle);
    notifyListeners();
  }

  Future<void> cycleRepeat() async {
    _repeat = switch (_repeat) {
      RepeatMode.off => RepeatMode.all,
      RepeatMode.all => RepeatMode.one,
      RepeatMode.one => RepeatMode.off,
    };
    await handler.setRepeat(_repeat);
    notifyListeners();
  }

  Future<void> toggleFavoriteCurrent() async {
    final track = _current;
    if (track == null) return;
    await library.toggleFavorite(track.id);
    notifyListeners();
  }

  Future<void> setVolume(double value) async {
    _volume = value.clamp(0.0, 1.0);
    await handler.setVolume(_volume);
    notifyListeners();
  }

  Future<void> removeFromQueue(int index) => handler.removeFromQueue(index);

  /// Pulihkan lagu terakhir dari snapshot tanpa auto-play.
  Future<bool> restoreLastSession({bool autoPlay = false}) async {
    if (!_prefs.resumeOnOpen) return false;
    final session = await handler.restoreSession(autoPlay: autoPlay);
    if (session == null) return false;
    _restoredSession = true;
    _current = library.trackById(session.track.id) ?? session.track;
    position.value = session.position;
    _duration = _current?.duration ?? _duration;
    notifyListeners();
    return true;
  }

  void _syncFromHandler() {
    final track = handler.currentTrack;
    if (track != null) {
      final resolved = library.trackById(track.id) ?? track;
      if (_current?.id != resolved.id) {
        _current = resolved;
        notifyListeners();
      }
    }
  }

  // ---------------------------------------------------------- sleep timer

  void startSleepTimer(Duration duration, {bool afterCurrentTrack = false}) {
    cancelSleepTimer();
    if (afterCurrentTrack) {
      _sleepAfterTrack = true;
      sleepRemaining.value = Duration.zero;
      notifyListeners();
      return;
    }
    _sleepEndsAt = DateTime.now().add(duration);
    sleepRemaining.value = duration;
    _sleepTicker = Timer.periodic(const Duration(seconds: 1), (_) async {
      final end = _sleepEndsAt;
      if (end == null) return;
      final remaining = end.difference(DateTime.now());
      if (remaining.isNegative || remaining.inSeconds <= 0) {
        await _fireSleepTimer();
      } else {
        sleepRemaining.value = remaining;
      }
    });
    notifyListeners();
  }

  void cancelSleepTimer() {
    _sleepTicker?.cancel();
    _sleepTicker = null;
    _sleepEndsAt = null;
    _sleepAfterTrack = false;
    sleepRemaining.value = null;
    notifyListeners();
  }

  DateTime? _sleepEndsAt;
  bool _sleepAfterTrack = false;

  Future<void> _fireSleepTimer() async {
    _sleepTicker?.cancel();
    _sleepTicker = null;
    _sleepEndsAt = null;
    _sleepAfterTrack = false;
    sleepRemaining.value = null;
    await handler.fadeOutAndPause();
    notifyListeners();
  }

  /// Dipanggil UI setiap kali lagu berganti, untuk mode "akhir lagu ini".
  Future<void> onTrackChangedForSleepTimer() async {
    if (_sleepAfterTrack) await _fireSleepTimer();
  }

  @override
  void dispose() {
    for (final sub in _subs) {
      sub.cancel();
    }
    _sleepTicker?.cancel();
    position.dispose();
    sleepRemaining.dispose();
    super.dispose();
  }
}

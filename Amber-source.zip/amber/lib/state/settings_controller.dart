import 'package:flutter/material.dart';

import '../core/theme/app_palette.dart';
import '../data/prefs_repository.dart';

/// Setting yang dipakai UI: tema, aksen, dan semua switch di layar Settings.
class SettingsController extends ChangeNotifier {
  SettingsController(this._prefs) {
    _themeMode = _prefs.themeMode;
    _accent = _prefs.accent;
    _blurArtwork = _prefs.blurArtwork;
    _loadArtwork = _prefs.loadArtwork;
    _useAudioService = _prefs.useAudioService;
    _resumeOnOpen = _prefs.resumeOnOpen;
    _resumeAfterReboot = _prefs.resumeAfterReboot;
    _handleHeadset = _prefs.handleHeadset;
    _fadeOnPause = _prefs.fadeOnPause;
    _ignoreShortAudio = _prefs.ignoreShortAudio;
    _onlyMp3 = _prefs.onlyMp3;
    _lockScreenControls = _prefs.lockScreenControls;
    _excludedFolders = _prefs.excludedFolders;
    _libraryCount = _prefs.libraryCount;
    _libraryBytes = _prefs.libraryBytes;
  }

  final PrefsRepository _prefs;

  late ThemeMode _themeMode;
  late AccentPreset _accent;
  late bool _blurArtwork;
  late bool _loadArtwork;
  late bool _useAudioService;
  late bool _resumeOnOpen;
  late bool _resumeAfterReboot;
  late bool _handleHeadset;
  late bool _fadeOnPause;
  late bool _ignoreShortAudio;
  late bool _onlyMp3;
  late bool _lockScreenControls;
  late Set<String> _excludedFolders;
  late int _libraryCount;
  late int _libraryBytes;

  ThemeMode get themeMode => _themeMode;
  AccentPreset get accentPreset => _accent;
  bool get blurArtwork => _blurArtwork;
  bool get loadArtwork => _loadArtwork;
  bool get useAudioService => _useAudioService;
  bool get resumeOnOpen => _resumeOnOpen;
  bool get resumeAfterReboot => _resumeAfterReboot;
  bool get handleHeadset => _handleHeadset;
  bool get fadeOnPause => _fadeOnPause;
  bool get ignoreShortAudio => _ignoreShortAudio;
  bool get onlyMp3 => _onlyMp3;
  bool get lockScreenControls => _lockScreenControls;
  Set<String> get excludedFolders => _excludedFolders;
  int get libraryCount => _libraryCount;
  int get libraryBytes => _libraryBytes;

  Brightness resolveBrightness(Brightness platform) => switch (_themeMode) {
        ThemeMode.light => Brightness.light,
        ThemeMode.dark => Brightness.dark,
        ThemeMode.system => platform,
      };

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    notifyListeners();
    await _prefs.setThemeMode(mode);
  }

  Future<void> setAccent(AccentPreset accent) async {
    _accent = accent;
    notifyListeners();
    await _prefs.setAccent(accent);
  }

  Future<void> setBlurArtwork(bool value) async {
    _blurArtwork = value;
    notifyListeners();
    await _prefs.setBlurArtwork(value);
  }

  Future<void> setUseAudioService(bool value) async {
    _useAudioService = value;
    notifyListeners();
    await _prefs.setUseAudioService(value);
  }

  Future<void> setLoadArtwork(bool value) async {
    _loadArtwork = value;
    notifyListeners();
    await _prefs.setLoadArtwork(value);
  }

  Future<void> setResumeOnOpen(bool value) async {
    _resumeOnOpen = value;
    notifyListeners();
    await _prefs.setResumeOnOpen(value);
  }

  Future<void> setResumeAfterReboot(bool value) async {
    _resumeAfterReboot = value;
    notifyListeners();
    await _prefs.setResumeAfterReboot(value);
  }

  Future<void> setHandleHeadset(bool value) async {
    _handleHeadset = value;
    notifyListeners();
    await _prefs.setHandleHeadset(value);
  }

  Future<void> setFadeOnPause(bool value) async {
    _fadeOnPause = value;
    notifyListeners();
    await _prefs.setFadeOnPause(value);
  }

  Future<void> setIgnoreShortAudio(bool value) async {
    _ignoreShortAudio = value;
    notifyListeners();
    await _prefs.setIgnoreShortAudio(value);
  }

  Future<void> setOnlyMp3(bool value) async {
    _onlyMp3 = value;
    notifyListeners();
    await _prefs.setOnlyMp3(value);
  }

  Future<void> setLockScreenControls(bool value) async {
    _lockScreenControls = value;
    notifyListeners();
    await _prefs.setLockScreenControls(value);
  }

  Future<void> toggleExcludedFolder(String folder) async {
    final next = Set<String>.from(_excludedFolders);
    if (!next.remove(folder)) next.add(folder);
    _excludedFolders = next;
    notifyListeners();
    await _prefs.setExcludedFolders(next);
  }

  Future<void> updateLibraryStats({required int trackCount, required int totalBytes}) async {
    _libraryCount = trackCount;
    _libraryBytes = totalBytes;
    notifyListeners();
    await _prefs.setLibraryStats(trackCount: trackCount, totalBytes: totalBytes);
  }
}

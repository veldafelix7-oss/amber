import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../core/boot_log.dart';
import '../data/media_store_repository.dart';
import '../data/models/playlist.dart';
import '../data/models/track.dart';
import '../data/prefs_repository.dart';
import 'settings_controller.dart';

enum SortMode { title, artist, dateAdded, duration }

extension SortModeLabel on SortMode {
  String get label => switch (this) {
        SortMode.title => 'Judul',
        SortMode.artist => 'Artis',
        SortMode.dateAdded => 'Terbaru',
        SortMode.duration => 'Durasi',
      };
}

/// Perpustakaan: hasil scan MediaStore + filter, favorit, playlist, riwayat.
class LibraryController extends ChangeNotifier {
  LibraryController({
    required MediaStoreRepository repository,
    required PrefsRepository prefs,
    required SettingsController settings,
  })  : _repository = repository,
        _prefs = prefs,
        _settings = settings;

  final MediaStoreRepository _repository;
  final PrefsRepository _prefs;
  final SettingsController _settings;

  List<Track> _all = const <Track>[];
  Map<int, Track> _byId = const <int, Track>{};
  Set<int> _favorites = <int>{};
  List<Playlist> _playlists = const <Playlist>[];
  List<int> _recents = const <int>[];
  List<String> _folders = const <String>[];
  PermissionState _permission = PermissionState.denied;
  bool _loading = false;
  bool _scanned = false;
  String _query = '';
  SortMode _sort = SortMode.title;

  bool get loading => _loading;
  bool get scanned => _scanned;
  PermissionState get permission => _permission;
  String get query => _query;
  SortMode get sort => _sort;
  int get totalTracks => _all.length;
  List<String> get folderNames => _folders;
  Set<int> get favoriteIds => _favorites;
  List<Playlist> get playlists => _playlists;
  List<int> get recents => _recents;

  Track? trackById(int id) => _byId[id];

  List<Track> get allTracks => _all;

  /// Daftar yang sudah difilter pencarian + diurutkan.
  List<Track> get visibleTracks {
    final q = _query.trim().toLowerCase();
    Iterable<Track> list = _all;
    if (q.isNotEmpty) {
      list = list.where((t) =>
          t.title.toLowerCase().contains(q) ||
          t.displayArtist.toLowerCase().contains(q) ||
          t.displayAlbum.toLowerCase().contains(q));
    }
    final sorted = list.toList();
    switch (_sort) {
      case SortMode.title:
        sorted.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      case SortMode.artist:
        sorted.sort((a, b) {
          final byArtist = a.displayArtist.toLowerCase().compareTo(b.displayArtist.toLowerCase());
          return byArtist != 0 ? byArtist : a.title.toLowerCase().compareTo(b.title.toLowerCase());
        });
      case SortMode.dateAdded:
        sorted.sort((a, b) => b.dateAdded.compareTo(a.dateAdded));
      case SortMode.duration:
        sorted.sort((a, b) => b.duration.compareTo(a.duration));
    }
    return sorted;
  }

  List<Track> get favoriteTracks {
    final list = _all.where((t) => _favorites.contains(t.id)).toList()
      ..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    return list;
  }

  List<Track> get recentlyPlayed {
    final list = <Track>[];
    for (final id in _recents) {
      final track = _byId[id];
      if (track != null) list.add(track);
    }
    return list;
  }

  List<Track> get recentlyAdded {
    final list = _all.toList()..sort((a, b) => b.dateAdded.compareTo(a.dateAdded));
    return list.take(12).toList();
  }

  List<AlbumGroup> get albums {
    final grouped = <String, List<Track>>{};
    for (final track in _all) {
      final key = '${track.displayAlbum}__${track.displayArtist}';
      grouped.putIfAbsent(key, () => <Track>[]).add(track);
    }
    final result = grouped.entries.map((entry) {
      final tracks = entry.value..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      return AlbumGroup(
        name: tracks.first.displayAlbum,
        artist: tracks.first.displayArtist,
        tracks: tracks,
        albumId: tracks.first.albumId,
      );
    }).toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return result;
  }

  List<ArtistGroup> get artists {
    final grouped = <String, List<Track>>{};
    for (final track in _all) {
      grouped.putIfAbsent(track.displayArtist, () => <Track>[]).add(track);
    }
    final result = grouped.entries
        .map((entry) => ArtistGroup(name: entry.key, tracks: entry.value))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return result;
  }

  List<FolderGroup> get folders {
    final grouped = <String, List<Track>>{};
    for (final track in _all) {
      grouped.putIfAbsent(track.displayFolder, () => <Track>[]).add(track);
    }
    final result = grouped.entries
        .map((entry) => FolderGroup(
              name: entry.key,
              path: entry.value.first.path.replaceAll(RegExp(r'/[^/]+$'), ''),
              tracks: entry.value,
            ))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return result;
  }

  // ------------------------------------------------------------- lifecycle

  Future<void> initialize() async {
    _favorites = _prefs.favorites;
    _playlists = _prefs.playlists;
    _recents = _prefs.recents;
    notifyListeners();
    try {
      _permission = await _repository.permissionState();
    } catch (error) {
      debugPrint('[Amber] cek izin gagal: $error');
      _permission = PermissionState.denied;
    }
    notifyListeners();
    // Sejak v2.0.0 pemindaian TIDAK otomatis: user yang memulai sendiri
    // lewat tab Scan, supaya app langsung terbuka tanpa menunggu.
  }

  /// Dipanggil tab Scan: minta izin (kalau perlu) lalu pindai.
  Future<bool> scanWithPermission() async {
    if (_permission != PermissionState.granted) {
      final granted = await requestPermission();
      if (!granted) return false;
    }
    await rescan();
    return true;
  }

  Future<void> openSystemSettings() => _repository.openSettings();

  Future<bool> requestPermission() async {
    final granted = await _repository.requestPermission();
    _permission = await _repository.permissionState();
    notifyListeners();
    if (granted) await rescan();
    return granted;
  }

  List<String> _foldersOf(List<Track> tracks) {
    final names = <String>{};
    for (final track in tracks) {
      final folder = track.displayFolder;
      if (folder.isNotEmpty) names.add(folder);
    }
    return names.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
  }

  Future<void> rescan() async {
    _loading = true;
    notifyListeners();
    try {
      final tracks = await _repository.scan(
        onlyMp3: _settings.onlyMp3,
        ignoreShortAudio: _settings.ignoreShortAudio,
        excludedFolders: _settings.excludedFolders,
        // Tiap halaman langsung ditampilkan: lagu muncul bertahap, dan kalau
        // ada masalah di tengah scan, yang sudah tampil tetap bisa dipakai.
        onProgress: (partial) {
          _all = partial;
          _byId = <int, Track>{for (final t in partial) t.id: t};
          _folders = _foldersOf(partial);
          notifyListeners();
        },
      );
      _all = tracks;
      _byId = <int, Track>{for (final t in tracks) t.id: t};
      _folders = _foldersOf(tracks);
      _scanned = true;
      final bytes = tracks.fold<int>(0, (sum, t) => sum + t.size);
      await _settings.updateLibraryStats(trackCount: tracks.length, totalBytes: bytes);
      BootLog.add('OK scan: ${tracks.length} lagu, ${_folders.length} folder');
    } catch (error) {
      debugPrint('[Amber] scan gagal: $error');
      _all = const <Track>[];
      _byId = const <int, Track>{};
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  void setQuery(String value) {
    if (_query == value) return;
    _query = value;
    notifyListeners();
  }

  void setSort(SortMode mode) {
    if (_sort == mode) return;
    _sort = mode;
    notifyListeners();
  }

  // ------------------------------------------------------------- favorit

  Future<void> toggleFavorite(int trackId) async {
    final next = Set<int>.from(_favorites);
    if (!next.remove(trackId)) next.add(trackId);
    _favorites = next;
    notifyListeners();
    await _prefs.setFavorites(next);
  }

  Future<void> refreshRecents() async {
    _recents = _prefs.recents;
    notifyListeners();
  }

  // ------------------------------------------------------------ playlist

  Future<Playlist> createPlaylist(String name, {List<int> trackIds = const <int>[]}) async {
    final playlist = Playlist(
      id: const Uuid().v4(),
      name: name.trim().isEmpty ? 'Playlist baru' : name.trim(),
      trackIds: trackIds,
      createdAt: DateTime.now(),
      coverTrackId: trackIds.isEmpty ? null : trackIds.first,
    );
    _playlists = <Playlist>[..._playlists, playlist];
    notifyListeners();
    await _prefs.savePlaylists(_playlists);
    return playlist;
  }

  Future<void> renamePlaylist(String id, String name) async {
    _playlists = [
      for (final p in _playlists) p.id == id ? p.copyWith(name: name.trim()) : p,
    ];
    notifyListeners();
    await _prefs.savePlaylists(_playlists);
  }

  Future<void> deletePlaylist(String id) async {
    _playlists = _playlists.where((p) => p.id != id).toList();
    notifyListeners();
    await _prefs.savePlaylists(_playlists);
  }

  Future<void> addToPlaylist(String id, List<int> trackIds) async {
    _playlists = [
      for (final p in _playlists)
        if (p.id == id)
          p.copyWith(
            trackIds: <int>{
              ...p.trackIds,
              ...trackIds,
            }.toList(),
            coverTrackId: p.coverTrackId ?? (trackIds.isEmpty ? null : trackIds.first),
          )
        else
          p,
    ];
    notifyListeners();
    await _prefs.savePlaylists(_playlists);
  }

  Future<void> removeFromPlaylist(String id, int trackId) async {
    _playlists = [
      for (final p in _playlists)
        if (p.id == id) p.copyWith(trackIds: p.trackIds.where((t) => t != trackId).toList()) else p,
    ];
    notifyListeners();
    await _prefs.savePlaylists(_playlists);
  }

  Future<void> reorderPlaylist(String id, int oldIndex, int newIndex) async {
    _playlists = [
      for (final p in _playlists)
        if (p.id == id)
          p.copyWith(trackIds: () {
            final list = <int>[...p.trackIds];
            final item = list.removeAt(oldIndex);
            list.insert(newIndex, item);
            return list;
          }())
        else
          p,
    ];
    notifyListeners();
    await _prefs.savePlaylists(_playlists);
  }

  List<Track> tracksOfPlaylist(Playlist playlist) {
    final list = <Track>[];
    for (final id in playlist.trackIds) {
      final track = _byId[id];
      if (track != null) list.add(track);
    }
    return list;
  }

  Future<Uint8List?> artworkFor(int trackId, {int size = 300}) {
    if (!_settings.loadArtwork) return Future<Uint8List?>.value();
    final track = _byId[trackId];
    if (track == null) return Future<Uint8List?>.value();
    return _repository.artworkForPath(track.path, size: size);
  }

  MediaStoreRepository get repository => _repository;
}

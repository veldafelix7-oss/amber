/// "AI lokal" Kola: pembaca nama file → judul & artis.
///
/// 100% offline, tanpa model, tanpa internet. Cara kerjanya seperti editor
/// manusia membaca nama file unduhan:
///
///   "Ariana Grande - Bloodline (Official Music Video)"  →  artis: Ariana Grande, judul: Bloodline
///   "Bruno Mars - Locked Out Of Heaven [Lyrics]"        →  judul: Locked Out Of Heaven
///   "adamaa_x2_mp3"                                     →  judul: adamaa
///
/// Inisial kartu cover diambil dari **judul**, bukan dari nama artis.
class TitleParser {
  const TitleParser._();

  static const Set<String> _skipWords = <String>{
    'the', 'a', 'an', 'of', 'dan', 'di', 'ke', 'feat', 'ft', 'with',
  };

  static final List<RegExp> _junk = <RegExp>[
    RegExp(r'[\(\[]\s*official[^\)\]]*[\)\]]', caseSensitive: false),
    RegExp(r'[\(\[]\s*(lyrics?|lirik|lyric\s*video)[^\)\]]*[\)\]]', caseSensitive: false),
    RegExp(r'[\(\[]\s*(audio|audio\s*only|video|mv|hq|hd|4k|8k|1080p|720p|360p|remaster(ed)?)[^\)\]]*[\)\]]',
        caseSensitive: false),
    RegExp(r'[\(\[]\s*(free\s*download|download|terbaru|full\s*album)[^\)\]]*[\)\]]', caseSensitive: false),
    RegExp(r'(^|\s)official\s*(music\s*)?(video|audio)(\s|$)', caseSensitive: false),
    RegExp(r'(^|\s)(lyrics?|lirik)(\s|$)', caseSensitive: false),
    RegExp(r'(^|[\s_\.])x\s?[2-9]([\s_\.]|$)', caseSensitive: false),
    RegExp(r'\.(mp3|m4a|aac|wav|flac|ogg|opus|wma|mp4|webm)$', caseSensitive: false),
    RegExp(r'(^|\s)mp3(\s|$)', caseSensitive: false),
    RegExp(r'^\s*\d{1,3}[\s\.\-]+(?=\D)'),
  ];

  static final RegExp _separator = RegExp(r'\s+[\-–—|•·]\s+|\s*[–—]\s*');

  /// Bersihkan satu bagian teks dari sampah nama file.
  static String clean(String input) {
    var text = input.replaceAll('_', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    for (final pattern in _junk) {
      text = text.replaceAll(pattern, ' ');
    }
    text = text.replaceAll(RegExp(r'\s+'), ' ');
    text = text.replaceAll(RegExp(r'^[\s\-–—\.\,\|]+|[\s\-–—\.\,\|]+$'), '');
    return text.trim();
  }

  /// Pisahkan artis dan judul dari judul MediaStore / nama file.
  static ({String title, String artist}) parse(String rawTitle, String fileName) {
    final fromFile = clean(fileName);
    var base = clean(rawTitle);

    // Kalau judul dari MediaStore kosong / cuma sampah, pakai nama file.
    if (base.isEmpty || base.length < 2) base = fromFile;
    if (base.isEmpty) return (title: 'Tanpa judul', artist: '');

    var artist = '';
    var title = base;

    final parts = base.split(_separator).map((part) => part.trim()).where((part) => part.isNotEmpty).toList();
    if (parts.length >= 2) {
      artist = parts.first;
      title = parts.sublist(1).join(' - ');
      // Kasus "Judul - Artis" (urutan terbalik): kalau bagian kedua lebih
      // pendek dan bagian pertama lebih panjang, tetap anggap yang pertama judul.
      if (title.length <= 2 && artist.length > title.length) {
        final swap = artist;
        artist = title;
        title = swap;
      }
    }

    title = clean(title.isEmpty ? base : title);
    artist = clean(artist);

    if (title.isEmpty) title = base;
    return (title: title, artist: artist);
  }

  /// Inisial 1–2 huruf untuk kartu cover, diambil dari JUDUL lagu.
  static String initials(String title) {
    final words = title
        .split(RegExp(r'[\s\-–—_/|,\.\(\)\[\]]+'))
        .map((word) => word.replaceAll(RegExp(r'[^\p{L}\p{N}]', unicode: true), ''))
        .where((word) => word.isNotEmpty)
        .toList();
    if (words.isEmpty) return '♪';

    final picked = <String>[];
    for (final word in words) {
      if (picked.isEmpty && _skipWords.contains(word.toLowerCase())) continue;
      picked.add(word);
      if (picked.length == 2) break;
    }

    final first = picked.isNotEmpty ? picked.first : words.first;
    if (picked.length >= 2) {
      return (first[0] + picked[1][0]).toUpperCase();
    }
    if (first.length >= 2) {
      return first.substring(0, 2).toUpperCase();
    }
    return first[0].toUpperCase();
  }

  /// Apakah artis dari MediaStore perlu diganti hasil bacaan nama file.
  static bool isUnknownArtist(String? artist) {
    if (artist == null) return true;
    final value = artist.trim().toLowerCase();
    return value.isEmpty ||
        value == '<unknown>' ||
        value == 'unknown' ||
        value == 'unknown artist' ||
        value == 'artis tidak dikenal' ||
        value == 'null';
  }
}

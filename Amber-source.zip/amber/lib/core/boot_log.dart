import 'package:flutter/foundation.dart';

/// Catatan langkah start-up. Ditampilkan di layar diagnosa & Settings,
/// supaya kalau app gagal jalan di HP user, penyebabnya kelihatan tanpa logcat.
class BootLog {
  const BootLog._();

  static final List<String> lines = <String>[];

  static void add(String line) {
    final stamp = DateTime.now().toIso8601String().substring(11, 19);
    lines.add('[$stamp] $line');
    debugPrint('[Amber] $line');
  }

  static String get text => lines.isEmpty ? '(kosong)' : lines.join('\n');

  static void clear() => lines.clear();
}

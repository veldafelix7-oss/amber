import 'package:flutter/material.dart';

import 'app_palette.dart';

/// Tipografi Inter. Ukuran & weight persis spec desain Amber.
class AppText {
  const AppText._();

  static const String family = 'Inter';

  static TextStyle _base({
    required double size,
    required FontWeight weight,
    double spacing = 0,
    double height = 1.25,
    Color? color,
  }) =>
      TextStyle(
        fontFamily: family,
        fontSize: size,
        fontWeight: weight,
        letterSpacing: spacing,
        height: height,
        color: color,
      );

  static TextStyle display(Color c) => _base(size: 34, weight: FontWeight.w700, spacing: -0.8, height: 1.12, color: c);
  static TextStyle playerTitle(Color c) => _base(size: 24, weight: FontWeight.w700, spacing: -0.4, height: 1.2, color: c);
  static TextStyle section(Color c) => _base(size: 20, weight: FontWeight.w700, spacing: -0.3, color: c);
  static TextStyle title(Color c) => _base(size: 16, weight: FontWeight.w600, spacing: -0.1, color: c);
  static TextStyle subtitle(Color c) => _base(size: 13, weight: FontWeight.w500, spacing: 0, color: c);
  static TextStyle caption(Color c) => _base(size: 11, weight: FontWeight.w500, spacing: 0.2, color: c);
  static TextStyle overline(Color c) => _base(size: 11, weight: FontWeight.w600, spacing: 1.2, color: c);

  static TextStyle duration(Color c) => _base(
        size: 12,
        weight: FontWeight.w500,
        color: c,
      ).copyWith(fontFeatures: const [FontFeature.tabularFigures()]);

  /// TextTheme lengkap untuk ThemeData.
  static TextTheme theme(AppPalette p) => TextTheme(
        displayLarge: display(p.textPrimary),
        displayMedium: display(p.textPrimary),
        displaySmall: display(p.textPrimary),
        headlineLarge: display(p.textPrimary),
        headlineMedium: section(p.textPrimary),
        headlineSmall: section(p.textPrimary),
        titleLarge: playerTitle(p.textPrimary),
        titleMedium: title(p.textPrimary),
        titleSmall: title(p.textPrimary),
        bodyLarge: title(p.textPrimary),
        bodyMedium: subtitle(p.textSecondary),
        bodySmall: subtitle(p.textSecondary),
        labelLarge: title(p.textPrimary),
        labelMedium: caption(p.textSecondary),
        labelSmall: caption(p.textTertiary),
      );
}

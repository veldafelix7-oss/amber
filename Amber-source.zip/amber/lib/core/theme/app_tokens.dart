import 'package:flutter/material.dart';

/// Skala spasi 4-pt. Semua padding di app ini harus ambil dari sini.
class AppSpacing {
  const AppSpacing._();

  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 20;
  static const double xl = 24;
  static const double xxl = 32;
  static const double xxxl = 40;

  /// Padding horizontal standar tiap layar.
  static const double screenH = 20;

  /// Tinggi bottom navigation bar (belum termasuk safe area).
  static const double navBarHeight = 64;

  /// Jarak mini player dari bawah layar (di atas nav bar).
  static const double miniPlayerBottom = 104;

  /// Tinggi baris lagu di list.
  static const double rowHeight = 64;
}

class AppRadius {
  const AppRadius._();

  static const double card = 20;
  static const double sheet = 28;
  static const double artwork = 16;
  static const double button = 14;
  static const double chip = 999;
  static const double artworkSmall = 10;
  static const double artworkMedium = 12;
}

class AppMotion {
  const AppMotion._();

  static const Duration fast = Duration(milliseconds: 200);
  static const Duration normal = Duration(milliseconds: 250);
  static const Duration slide = Duration(milliseconds: 300);
  static const Duration page = Duration(milliseconds: 420);
  static const Duration spring = Duration(milliseconds: 220);

  static const Curve easeOut = Curves.easeOutCubic;
}

/// Hanya dua level elevasi di seluruh app.
class AppShadow {
  const AppShadow._();

  static List<BoxShadow> l1(Color tint) => [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.06),
          blurRadius: 12,
          offset: const Offset(0, 4),
        ),
      ];

  static List<BoxShadow> l2(Color tint) => [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.10),
          blurRadius: 24,
          offset: const Offset(0, 10),
        ),
      ];

  static List<BoxShadow> accent(Color accent) => [
        BoxShadow(
          color: accent.withValues(alpha: 0.18),
          blurRadius: 40,
          offset: const Offset(0, 12),
        ),
      ];
}

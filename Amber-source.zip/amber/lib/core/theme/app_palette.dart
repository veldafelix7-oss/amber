import 'package:flutter/material.dart';

/// Preset warna aksen. User bisa pilih di Settings.
enum AccentPreset {
  oren('Oren', Color(0xFFFF8A00), Color(0xFFFFE9CF), Color(0xFFE86E00),
      Color(0xFFFFA23A), Color(0xFFFF7A00), Color(0xFFFF9F3D), Color(0xFF3A2A17)),
  amber('Amber', Color(0xFFE8A020), Color(0xFFFBEFD0), Color(0xFFC07D00),
      Color(0xFFF5BC3F), Color(0xFFDE8F0B), Color(0xFFF0B23A), Color(0xFF3A2E12)),
  toska('Toska', Color(0xFF12968C), Color(0xFFD3EFEC), Color(0xFF0B7A72),
      Color(0xFF2FB3A8), Color(0xFF0C8A81), Color(0xFF3FBDB1), Color(0xFF12312D)),
  ungu('Ungu', Color(0xFF7C4DFF), Color(0xFFE7DEFF), Color(0xFF6534E0),
      Color(0xFF9A76FF), Color(0xFF6B3BE8), Color(0xFF8E6BFF), Color(0xFF241A3D));

  const AccentPreset(
    this.label,
    this.lightAccent,
    this.lightSoft,
    this.lightDeep,
    this.gradientStart,
    this.gradientEnd,
    this.darkAccent,
    this.darkSoft,
  );

  final String label;
  final Color lightAccent;
  final Color lightSoft;
  final Color lightDeep;
  final Color gradientStart;
  final Color gradientEnd;
  final Color darkAccent;
  final Color darkSoft;
}

/// Palet runtime. Dibaca lewat `AppPalette.of(context)`.
@immutable
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.bg,
    required this.surface,
    required this.surfaceAlt,
    required this.accent,
    required this.accentSoft,
    required this.accentDeep,
    required this.gradientStart,
    required this.gradientEnd,
    required this.textPrimary,
    required this.textSecondary,
    required this.textTertiary,
    required this.divider,
    required this.danger,
    required this.success,
    required this.isDark,
  });

  final Color bg;
  final Color surface;
  final Color surfaceAlt;
  final Color accent;
  final Color accentSoft;
  final Color accentDeep;
  final Color gradientStart;
  final Color gradientEnd;
  final Color textPrimary;
  final Color textSecondary;
  final Color textTertiary;
  final Color divider;
  final Color danger;
  final Color success;
  final bool isDark;

  LinearGradient get accentGradient =>
      LinearGradient(colors: [gradientStart, gradientEnd], begin: Alignment.topLeft, end: Alignment.bottomRight);

  /// Latar halaman: oren & putih saling melebur, bukan dua blok terpisah.
  LinearGradient get pageGradient => isDark
      ? LinearGradient(
          colors: <Color>[
            Color.alphaBlend(accent.withValues(alpha: 0.16), bg),
            bg,
            Color.alphaBlend(accent.withValues(alpha: 0.08), bg),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const <double>[0, 0.5, 1],
        )
      : LinearGradient(
          colors: <Color>[
            Color.alphaBlend(accentSoft.withValues(alpha: 0.85), bg),
            bg,
            Color.alphaBlend(accentSoft.withValues(alpha: 0.40), bg),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const <double>[0, 0.42, 1],
        );

  /// Permukaan semi-transparan (efek kaca, tanpa blur supaya tetap ringan).
  Color get glass => surface.withValues(alpha: isDark ? 0.62 : 0.74);
  Color get glassStrong => surface.withValues(alpha: isDark ? 0.80 : 0.90);
  Color get glassBorder =>
      isDark ? Colors.white.withValues(alpha: 0.10) : Colors.white.withValues(alpha: 0.90);

  /// Gradasi oren-putih untuk tombol/kartu aksen.
  LinearGradient get warmGradient => LinearGradient(
        colors: <Color>[
          gradientStart,
          gradientEnd,
          Color.alphaBlend(Colors.white.withValues(alpha: 0.22), gradientEnd),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  static AppPalette light(AccentPreset accent) => AppPalette(
        bg: const Color(0xFFFFFBF5),
        surface: const Color(0xFFFFFFFF),
        surfaceAlt: Color.alphaBlend(accent.lightSoft.withValues(alpha: 0.55), const Color(0xFFFFFFFF)),
        accent: accent.lightAccent,
        accentSoft: accent.lightSoft,
        accentDeep: accent.lightDeep,
        gradientStart: accent.gradientStart,
        gradientEnd: accent.gradientEnd,
        textPrimary: const Color(0xFF1C1917),
        textSecondary: const Color(0xFF6F675E),
        textTertiary: const Color(0xFFA9A096),
        divider: const Color(0xFFF0E6D8),
        danger: const Color(0xFFE5484D),
        success: const Color(0xFF2FA36B),
        isDark: false,
      );

  static AppPalette dark(AccentPreset accent) => AppPalette(
        bg: const Color(0xFF0E0D0C),
        surface: const Color(0xFF1A1816),
        surfaceAlt: Color.alphaBlend(accent.darkSoft.withValues(alpha: 0.7), const Color(0xFF1A1816)),
        accent: accent.darkAccent,
        accentSoft: accent.darkSoft,
        accentDeep: accent.lightAccent,
        gradientStart: accent.gradientStart,
        gradientEnd: accent.gradientEnd,
        textPrimary: const Color(0xFFF7F2EA),
        textSecondary: const Color(0xFFB5ABA0),
        textTertiary: const Color(0xFF8A8178),
        divider: const Color(0xFF2A2521),
        danger: const Color(0xFFFF6B6E),
        success: const Color(0xFF4CC38A),
        isDark: true,
      );

  static AppPalette of(BuildContext context) {
    final theme = Theme.of(context);
    return theme.extension<AppPalette>() ?? light(AccentPreset.oren);
  }

  @override
  AppPalette copyWith({
    Color? bg,
    Color? surface,
    Color? surfaceAlt,
    Color? accent,
    Color? accentSoft,
    Color? accentDeep,
    Color? gradientStart,
    Color? gradientEnd,
    Color? textPrimary,
    Color? textSecondary,
    Color? textTertiary,
    Color? divider,
    Color? danger,
    Color? success,
    bool? isDark,
  }) {
    return AppPalette(
      bg: bg ?? this.bg,
      surface: surface ?? this.surface,
      surfaceAlt: surfaceAlt ?? this.surfaceAlt,
      accent: accent ?? this.accent,
      accentSoft: accentSoft ?? this.accentSoft,
      accentDeep: accentDeep ?? this.accentDeep,
      gradientStart: gradientStart ?? this.gradientStart,
      gradientEnd: gradientEnd ?? this.gradientEnd,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textTertiary: textTertiary ?? this.textTertiary,
      divider: divider ?? this.divider,
      danger: danger ?? this.danger,
      success: success ?? this.success,
      isDark: isDark ?? this.isDark,
    );
  }

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      bg: Color.lerp(bg, other.bg, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      surfaceAlt: Color.lerp(surfaceAlt, other.surfaceAlt, t)!,
      accent: Color.lerp(accent, other.accent, t)!,
      accentSoft: Color.lerp(accentSoft, other.accentSoft, t)!,
      accentDeep: Color.lerp(accentDeep, other.accentDeep, t)!,
      gradientStart: Color.lerp(gradientStart, other.gradientStart, t)!,
      gradientEnd: Color.lerp(gradientEnd, other.gradientEnd, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textTertiary: Color.lerp(textTertiary, other.textTertiary, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
      danger: Color.lerp(danger, other.danger, t)!,
      success: Color.lerp(success, other.success, t)!,
      isDark: t < 0.5 ? isDark : other.isDark,
    );
  }
}

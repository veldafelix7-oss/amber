import 'package:flutter/material.dart';

/// Palet gradasi yang bisa dipilih user.
///
/// Semua tema adalah **gradasi tiga warna** (seperti lingkaran warna di
/// referensi desain): dipakai untuk latar halaman yang tembus pandang,
/// tombol, dan banner. Jadi saat tema diganti, gradasinya ikut berubah —
/// bukan cuma warna satu titik.
enum AccentPreset {
  cerah('Cerah', Color(0xFF8BD65B), Color(0xFFFFD24A), Color(0xFFFF8A3C), Color(0xFFD97706)),
  oren('Oren', Color(0xFFFFB03A), Color(0xFFFF8A00), Color(0xFFE5484D), Color(0xFFCC4A00)),
  senja('Senja', Color(0xFFFFC46B), Color(0xFFFF8FA3), Color(0xFFB06AB3), Color(0xFF9B4D9E)),
  mawar('Mawar', Color(0xFFFF9AA2), Color(0xFFF45C8E), Color(0xFFC026D3), Color(0xFFB01E7A)),
  ungu('Ungu', Color(0xFF9A76FF), Color(0xFF6B8AFF), Color(0xFF3B82F6), Color(0xFF5B3FD6)),
  laut('Laut', Color(0xFF5BE7F0), Color(0xFF3BA7F2), Color(0xFF4F63D2), Color(0xFF2563EB)),
  mint('Mint', Color(0xFF7BF1A8), Color(0xFF2FD4A6), Color(0xFF12A594), Color(0xFF0E8F7E)),
  lemon('Lemon', Color(0xFFE8F55B), Color(0xFF8BD65B), Color(0xFF2FD4A6), Color(0xFF3F9A3F));

  const AccentPreset(this.label, this.c1, this.c2, this.c3, this.deep);

  final String label;

  /// Tiga warna gradasi (atas-kiri → tengah → bawah-kanan).
  final Color c1;
  final Color c2;
  final Color c3;

  /// Warna pekat untuk teks/ikon di atas latar putih.
  final Color deep;

  static AccentPreset get fallback => AccentPreset.cerah;

  LinearGradient get gradient => LinearGradient(
        colors: <Color>[c1, c2, c3],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
}

/// Palet runtime. Dibaca lewat `AppPalette.of(context)`.
@immutable
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.preset,
    required this.bg,
    required this.surface,
    required this.surfaceAlt,
    required this.accent,
    required this.accentSoft,
    required this.accentDeep,
    required this.gradientStart,
    required this.gradientMid,
    required this.gradientEnd,
    required this.textPrimary,
    required this.textSecondary,
    required this.textTertiary,
    required this.divider,
    required this.danger,
    required this.success,
    required this.isDark,
  });

  final AccentPreset preset;
  final Color bg;
  final Color surface;
  final Color surfaceAlt;
  final Color accent;
  final Color accentSoft;
  final Color accentDeep;
  final Color gradientStart;
  final Color gradientMid;
  final Color gradientEnd;
  final Color textPrimary;
  final Color textSecondary;
  final Color textTertiary;
  final Color divider;
  final Color danger;
  final Color success;
  final bool isDark;

  LinearGradient get accentGradient => LinearGradient(
        colors: <Color>[gradientStart, gradientMid, gradientEnd],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  /// Latar halaman: tiga warna tema, dibuat sangat tembus pandang di atas
  /// dasar putih/ivory, jadi terlihat seperti gradasi basah ala iOS.
  LinearGradient get pageGradient => LinearGradient(
        colors: <Color>[
          Color.alphaBlend(gradientStart.withValues(alpha: isDark ? 0.22 : 0.30), bg),
          Color.alphaBlend(gradientMid.withValues(alpha: isDark ? 0.14 : 0.16), bg),
          Color.alphaBlend(gradientEnd.withValues(alpha: isDark ? 0.10 : 0.12), bg),
          bg,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        stops: const <double>[0, 0.34, 0.68, 1],
      );

  /// Permukaan kaca semi-transparan (tanpa blur agar tetap ringan).
  Color get glass => surface.withValues(alpha: isDark ? 0.62 : 0.72);
  Color get glassStrong => surface.withValues(alpha: isDark ? 0.82 : 0.90);
  Color get glassBorder =>
      isDark ? Colors.white.withValues(alpha: 0.10) : Colors.white.withValues(alpha: 0.88);

  /// Gradasi penuh untuk tombol & banner.
  LinearGradient get warmGradient => LinearGradient(
        colors: <Color>[
          gradientStart,
          gradientMid,
          Color.alphaBlend(Colors.white.withValues(alpha: 0.18), gradientEnd),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  static AppPalette light(AccentPreset accent) => AppPalette(
        preset: accent,
        bg: const Color(0xFFFFFBF5),
        surface: const Color(0xFFFFFFFF),
        surfaceAlt: Color.alphaBlend(accent.c2.withValues(alpha: 0.16), const Color(0xFFFFFFFF)),
        accent: accent.deep,
        accentSoft: Color.alphaBlend(accent.c1.withValues(alpha: 0.22), const Color(0xFFFFFFFF)),
        accentDeep: accent.deep,
        gradientStart: accent.c1,
        gradientMid: accent.c2,
        gradientEnd: accent.c3,
        textPrimary: const Color(0xFF1C1917),
        textSecondary: const Color(0xFF6F675E),
        textTertiary: const Color(0xFFA9A096),
        divider: const Color(0xFFEFE7DC),
        danger: const Color(0xFFE5484D),
        success: const Color(0xFF2FA36B),
        isDark: false,
      );

  static AppPalette dark(AccentPreset accent) => AppPalette(
        preset: accent,
        bg: const Color(0xFF0E0D0C),
        surface: const Color(0xFF1A1816),
        surfaceAlt: Color.alphaBlend(accent.c2.withValues(alpha: 0.18), const Color(0xFF1A1816)),
        accent: accent.c1,
        accentSoft: Color.alphaBlend(accent.c2.withValues(alpha: 0.28), const Color(0xFF1A1816)),
        accentDeep: accent.c2,
        gradientStart: accent.c1,
        gradientMid: accent.c2,
        gradientEnd: accent.c3,
        textPrimary: const Color(0xFFF7F2EA),
        textSecondary: const Color(0xFFB5ABA0),
        textTertiary: const Color(0xFF8A8178),
        divider: const Color(0xFF2A2521),
        danger: const Color(0xFFFF6B6E),
        success: const Color(0xFF4CC38A),
        isDark: true,
      );

  static AppPalette of(BuildContext context) {
    final theme = Theme.of(context);
    return theme.extension<AppPalette>() ?? light(AccentPreset.fallback);
  }

  @override
  AppPalette copyWith({
    AccentPreset? preset,
    Color? bg,
    Color? surface,
    Color? surfaceAlt,
    Color? accent,
    Color? accentSoft,
    Color? accentDeep,
    Color? gradientStart,
    Color? gradientMid,
    Color? gradientEnd,
    Color? textPrimary,
    Color? textSecondary,
    Color? textTertiary,
    Color? divider,
    Color? danger,
    Color? success,
    bool? isDark,
  }) {
    return AppPalette(
      preset: preset ?? this.preset,
      bg: bg ?? this.bg,
      surface: surface ?? this.surface,
      surfaceAlt: surfaceAlt ?? this.surfaceAlt,
      accent: accent ?? this.accent,
      accentSoft: accentSoft ?? this.accentSoft,
      accentDeep: accentDeep ?? this.accentDeep,
      gradientStart: gradientStart ?? this.gradientStart,
      gradientMid: gradientMid ?? this.gradientMid,
      gradientEnd: gradientEnd ?? this.gradientEnd,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textTertiary: textTertiary ?? this.textTertiary,
      divider: divider ?? this.divider,
      danger: danger ?? this.danger,
      success: success ?? this.success,
      isDark: isDark ?? this.isDark,
    );
  }

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      preset: t < 0.5 ? preset : other.preset,
      bg: Color.lerp(bg, other.bg, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      surfaceAlt: Color.lerp(surfaceAlt, other.surfaceAlt, t)!,
      accent: Color.lerp(accent, other.accent, t)!,
      accentSoft: Color.lerp(accentSoft, other.accentSoft, t)!,
      accentDeep: Color.lerp(accentDeep, other.accentDeep, t)!,
      gradientStart: Color.lerp(gradientStart, other.gradientStart, t)!,
      gradientMid: Color.lerp(gradientMid, other.gradientMid, t)!,
      gradientEnd: Color.lerp(gradientEnd, other.gradientEnd, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textTertiary: Color.lerp(textTertiary, other.textTertiary, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
      danger: Color.lerp(danger, other.danger, t)!,
      success: Color.lerp(success, other.success, t)!,
      isDark: t < 0.5 ? isDark : other.isDark,
    );
  }
}

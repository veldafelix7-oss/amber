import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/boot_log.dart';
import 'data/media_store_repository.dart';
import 'data/prefs_repository.dart';
import 'state/library_controller.dart';
import 'state/player_controller.dart';
import 'state/settings_controller.dart';
import 'ui/permission_page.dart';
import 'ui/shell/app_shell.dart';
import 'ui/splash_page.dart';

class AmberApp extends StatelessWidget {
  const AmberApp({
    super.key,
    required this.prefs,
    required this.settings,
    required this.library,
    required this.player,
  });

  final PrefsRepository prefs;
  final SettingsController settings;
  final LibraryController library;
  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: <ChangeNotifierProvider<ChangeNotifier>>[
        ChangeNotifierProvider<SettingsController>.value(value: settings),
        ChangeNotifierProvider<LibraryController>.value(value: library),
        ChangeNotifierProvider<PlayerController>.value(value: player),
      ],
      child: Consumer<SettingsController>(
        builder: (context, settings, _) {
          return MaterialApp(
            title: 'Amber',
            debugShowCheckedModeBanner: false,
            themeMode: settings.themeMode,
            theme: AppTheme.build(accent: settings.accentPreset, brightness: Brightness.light),
            darkTheme: AppTheme.build(accent: settings.accentPreset, brightness: Brightness.dark),
            home: const RootGate(),
          );
        },
      ),
    );
  }
}

/// Splash → (izin?) → AppShell.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splashDone = false;
  bool _bootstrapped = false;
  Timer? _splashTimer;

  @override
  void initState() {
    super.initState();
    _splashTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _splashDone = true);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    if (_bootstrapped) return;
    _bootstrapped = true;
    final library = context.read<LibraryController>();
    final player = context.read<PlayerController>();

    try {
      await library.initialize();
    } catch (error) {
      BootLog.add('GAGAL inisialisasi perpustakaan: $error');
    }
    try {
      // Pulihkan posisi lagu terakhir tanpa auto-play.
      await player.restoreLastSession();
    } catch (error) {
      BootLog.add('GAGAL memulihkan sesi: $error');
    }
  }

  @override
  void dispose() {
    _splashTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final library = context.watch<LibraryController>();

    if (!_splashDone) return const SplashPage();

    if (library.permission != PermissionState.granted && !library.scanned) {
      return const PermissionPage();
    }

    return const AppShell();
  }
}

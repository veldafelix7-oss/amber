import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import 'core/theme/app_theme.dart';
import 'core/boot_log.dart';
import 'data/prefs_repository.dart';
import 'state/library_controller.dart';
import 'state/player_controller.dart';
import 'state/settings_controller.dart';
import 'ui/shell/app_shell.dart';
import 'ui/splash_page.dart';

class AmberApp extends StatelessWidget {
  const AmberApp({
    super.key,
    required this.prefs,
    required this.settings,
    required this.library,
    required this.player,
  });

  final PrefsRepository prefs;
  final SettingsController settings;
  final LibraryController library;
  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: <SingleChildWidget>[
        Provider<PrefsRepository>.value(value: prefs),
        ChangeNotifierProvider<SettingsController>.value(value: settings),
        ChangeNotifierProvider<LibraryController>.value(value: library),
        ChangeNotifierProvider<PlayerController>.value(value: player),
      ],
      child: Consumer<SettingsController>(
        builder: (context, settings, _) {
          return MaterialApp(
            title: 'Kola Music',
            debugShowCheckedModeBanner: false,
            themeMode: settings.themeMode,
            theme: AppTheme.build(accent: settings.accentPreset, brightness: Brightness.light),
            darkTheme: AppTheme.build(accent: settings.accentPreset, brightness: Brightness.dark),
            home: const RootGate(),
          );
        },
      ),
    );
  }
}

/// Splash → (izin?) → AppShell.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> with WidgetsBindingObserver {
  bool _splashDone = false;
  bool _bootstrapped = false;
  Timer? _splashTimer;
  Timer? _healthyTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _splashTimer = Timer(const Duration(milliseconds: 1900), () {
      if (!mounted) return;
      setState(() => _splashDone = true);
      // Dialog izin Android muncul tepat setelah animasi pembuka selesai.
      _requestPermissionsOnce();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  /// Sesi dianggap sehat kalau app sempat dipakai sebentar atau ditinggal ke
  /// background tanpa mati. Kalau tidak, start berikutnya masuk mode aman.
  void _markHealthy() {
    _healthyTimer?.cancel();
    if (!mounted) return;
    context.read<PrefsRepository>().setStartPending(false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden) {
      _markHealthy();
    }
  }

  /// Hanya sekali seumur pemasangan: minta izin baca audio + izin notifikasi.
  Future<void> _requestPermissionsOnce() async {
    if (!mounted) return;
    final prefs = context.read<PrefsRepository>();
    final library = context.read<LibraryController>();
    try {
      if (prefs.permissionAsked) return;
      await prefs.setPermissionAsked(true);
      await library.requestPermission();
      await library.requestNotificationPermission();
      BootLog.add('izin awal Android diminta');
    } catch (error) {
      BootLog.add('izin awal dilewati: $error');
    }
  }

  Future<void> _bootstrap() async {
    if (_bootstrapped) return;
    _bootstrapped = true;
    final library = context.read<LibraryController>();
    final player = context.read<PlayerController>();

    try {
      await library.initialize();
    } catch (error) {
      BootLog.add('GAGAL inisialisasi perpustakaan: $error');
    }
    try {
      // Pulihkan posisi lagu terakhir tanpa auto-play.
      await player.restoreLastSession();
    } catch (error) {
      BootLog.add('GAGAL memulihkan sesi: $error');
    }

    _healthyTimer?.cancel();
    _healthyTimer = Timer(const Duration(seconds: 20), _markHealthy);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _splashTimer?.cancel();
    _healthyTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_splashDone) return const SplashPage();

    return const AppShell();
  }
}

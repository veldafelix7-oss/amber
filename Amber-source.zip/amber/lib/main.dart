import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'boot/boot_app.dart';
import 'core/boot_log.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  // Kalau ada error saat menggambar layar, tampilkan pesannya (jangan layar kosong).
  ErrorWidget.builder = (details) {
    BootLog.add('UI ERROR: ${details.exceptionAsString()}');
    return Container(
      color: const Color(0xFFFFFBF5),
      padding: const EdgeInsets.all(20),
      alignment: Alignment.center,
      child: Text(
        'Ada kendala tampilan:\n\n${details.exceptionAsString()}',
        style: const TextStyle(fontSize: 12, color: Color(0xFF1C1917)),
        textAlign: TextAlign.center,
      ),
    );
  };

  runApp(const BootApp());
}

import 'package:flutter/services.dart';
import 'package:on_audio_query_pluse/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

import '../core/boot_log.dart';
import 'models/track.dart';

/// Status izin storage, dipetakan jadi 3 kondisi UI.
enum PermissionState { granted, denied, permanentlyDenied }

/// Sumber kebenaran daftar lagu: MediaStore Android.
///
/// Tidak ada cache permanen — daftar lagu selalu query ulang supaya file yang
/// dihapus/ditambah di HP langsung terlihat.
class MediaStoreRepository {
  MediaStoreRepository({OnAudioQuery? query}) : _query = query ?? OnAudioQuery();

  final OnAudioQuery _query;

  /// Channel native (lihat MainActivity.kt) untuk baca cover dari dalam file.
  static const MethodChannel _artChannel = MethodChannel('amber/media');

  /// Future cover di-cache per (path, ukuran). Tujuannya: widget yang rebuild
  /// tidak memicu permintaan cover baru terus-menerus.
  final Map<String, Future<Uint8List?>> _artFutures = <String, Future<Uint8List?>>{};
  int _artErrorLogged = 0;

  Future<PermissionState> permissionState() async {
    final audio = await Permission.audio.status;
    final storage = await Permission.storage.status;
    if (audio.isGranted || storage.isGranted) return PermissionState.granted;
    if (audio.isPermanentlyDenied || storage.isPermanentlyDenied) {
      return PermissionState.permanentlyDenied;
    }
    return PermissionState.denied;
  }

  Future<bool> requestPermission() async {
    final results = await <Permission>[Permission.audio, Permission.storage].request();
    return results.values.any((status) => status.isGranted);
  }

  Future<void> openSettings() => openAppSettings();

  /// Ambil semua lagu dari MediaStore lalu terapkan filter setting user.
  Future<List<Track>> scan({
    bool onlyMp3 = false,
    bool ignoreShortAudio = true,
    Set<String> excludedFolders = const <String>{},
  }) async {
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );

    final result = <Track>[];
    for (final song in songs) {
      final track = Track.fromSong(song);
      if (track.path.isEmpty) continue;
      if (track.duration <= Duration.zero) continue;
      if (ignoreShortAudio && track.duration.inSeconds < 30) continue;
      if (onlyMp3 && !track.path.toLowerCase().endsWith('.mp3')) continue;
      if (excludedFolders.any((folder) => track.path.contains('/$folder/'))) continue;
      result.add(track);
    }
    return result;
  }

  /// Daftar semua folder yang berisi musik (buat layar exclude folder).
  Future<List<String>> folders() async {
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
    final names = <String>{};
    for (final song in songs) {
      final folder = Track.fromSong(song).displayFolder;
      if (folder.isNotEmpty) names.add(folder);
    }
    final list = names.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return list;
  }

  /// Cover lagu, diambil dari gambar yang menempel di dalam file audio.
  ///
  /// Sengaja TIDAK memakai album art MediaStore: di Android 13 itu butuh izin
  /// foto, dan kalau tidak ada izin, proses app bisa dimatikan sistem
  /// ("Amber telah berhenti"). Cara ini hanya butuh izin audio.
  Future<Uint8List?> artworkForPath(String path, {int size = 300}) {
    if (path.isEmpty) return Future<Uint8List?>.value();
    final key = '$path|$size';
    final cached = _artFutures[key];
    if (cached != null) return cached;
    if (_artFutures.length > 400) _artFutures.clear();
    final future = _loadEmbeddedArt(path, size);
    _artFutures[key] = future;
    return future;
  }

  Future<Uint8List?> _loadEmbeddedArt(String path, int size) async {
    try {
      final bytes = await _artChannel
          .invokeMethod<Uint8List>(
            'embeddedArt',
            <String, Object?>{'path': path, 'maxSize': size},
          )
          .timeout(const Duration(seconds: 8), onTimeout: () => null);
      return bytes;
    } catch (error) {
      if (_artErrorLogged < 3) {
        _artErrorLogged++;
        BootLog.add('cover dilewati: $error');
      }
      return null;
    }
  }

  void clearArtworkCache() => _artFutures.clear();
}

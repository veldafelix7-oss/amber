import 'dart:typed_data';

import 'package:on_audio_query_pluse/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

import 'models/track.dart';

/// Status izin storage, dipetakan jadi 3 kondisi UI.
enum PermissionState { granted, denied, permanentlyDenied }

/// Sumber kebenaran daftar lagu: MediaStore Android.
///
/// Tidak ada cache permanen — daftar lagu selalu query ulang supaya file yang
/// dihapus/ditambah di HP langsung terlihat.
class MediaStoreRepository {
  MediaStoreRepository({OnAudioQuery? query}) : _query = query ?? OnAudioQuery();

  final OnAudioQuery _query;
  final Map<int, Uint8List?> _artworkCache = <int, Uint8List?>{};

  Future<PermissionState> permissionState() async {
    final audio = await Permission.audio.status;
    final storage = await Permission.storage.status;
    if (audio.isGranted || storage.isGranted) return PermissionState.granted;
    if (audio.isPermanentlyDenied || storage.isPermanentlyDenied) {
      return PermissionState.permanentlyDenied;
    }
    return PermissionState.denied;
  }

  Future<bool> requestPermission() async {
    final results = await <Permission>[Permission.audio, Permission.storage].request();
    return results.values.any((status) => status.isGranted);
  }

  Future<void> openSettings() => openAppSettings();

  /// Ambil semua lagu dari MediaStore lalu terapkan filter setting user.
  Future<List<Track>> scan({
    bool onlyMp3 = false,
    bool ignoreShortAudio = true,
    Set<String> excludedFolders = const <String>{},
  }) async {
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );

    final result = <Track>[];
    for (final song in songs) {
      final track = Track.fromSong(song);
      if (track.path.isEmpty) continue;
      if (track.duration <= Duration.zero) continue;
      if (ignoreShortAudio && track.duration.inSeconds < 30) continue;
      if (onlyMp3 && !track.path.toLowerCase().endsWith('.mp3')) continue;
      if (excludedFolders.any((folder) => track.path.contains('/$folder/'))) continue;
      result.add(track);
    }
    return result;
  }

  /// Daftar semua folder yang berisi musik (buat layar exclude folder).
  Future<List<String>> folders() async {
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
    final names = <String>{};
    for (final song in songs) {
      final folder = Track.fromSong(song).displayFolder;
      if (folder.isNotEmpty) names.add(folder);
    }
    final list = names.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return list;
  }

  /// Artwork album dalam bentuk byte. Di-cache di memori (maks 120 entri).
  Future<Uint8List?> artwork(int trackId, {int size = 300}) async {
    if (_artworkCache.containsKey(trackId)) return _artworkCache[trackId];
    try {
      final bytes = await _query.queryArtwork(
        trackId,
        ArtworkType.AUDIO,
        format: ArtworkFormat.JPEG,
        size: size,
        quality: 80,
      );
      if (_artworkCache.length > 120) _artworkCache.clear();
      _artworkCache[trackId] = bytes;
      return bytes;
    } catch (_) {
      _artworkCache[trackId] = null;
      return null;
    }
  }

  void clearArtworkCache() => _artworkCache.clear();
}

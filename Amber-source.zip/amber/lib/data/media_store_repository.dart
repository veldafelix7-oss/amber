import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../core/boot_log.dart';
import 'models/track.dart';

/// Status izin storage, dipetakan jadi 3 kondisi UI.
enum PermissionState { granted, denied, permanentlyDenied }

/// Sumber kebenaran daftar lagu: MediaStore Android.
///
/// Sejak v1.2.0 query dilakukan **oleh kode native Amber sendiri**
/// (MainActivity.kt), bukan plugin pihak ketiga. Alasannya:
///  * query dibagi per halaman (400 lagu sekali ambil), jadi perpustakaan
///    berisi ribuan lagu tidak lagi menumpuk di memori sekaligus;
///  * kalau satu halaman gagal, app berhenti dengan daftar yang sudah ada —
///    tidak ikut mati;
///  * hasil tiap halaman langsung dikirim ke UI, jadi lagu muncul bertahap.
class MediaStoreRepository {
  MediaStoreRepository();

  static const MethodChannel _media = MethodChannel('amber/media');

  /// Future cover di-cache per (path, ukuran) supaya rebuild widget tidak
  /// memicu permintaan baru terus-menerus.
  final Map<String, Future<Uint8List?>> _artFutures = <String, Future<Uint8List?>>{};
  int _artErrorLogged = 0;

  /// Batas aman jumlah lagu (lebih dari ini sangat jarang untuk pemakaian
  /// pribadi, dan menjaga memori tetap wajar di HP 4 GB).
  static const int maxTracks = 20000;
  static const int pageSize = 400;

  Future<PermissionState> permissionState() async {
    final audio = await Permission.audio.status;
    final storage = await Permission.storage.status;
    if (audio.isGranted || storage.isGranted) return PermissionState.granted;
    if (audio.isPermanentlyDenied || storage.isPermanentlyDenied) {
      return PermissionState.permanentlyDenied;
    }
    return PermissionState.denied;
  }

  Future<bool> requestPermission() async {
    final results = await <Permission>[Permission.audio, Permission.storage].request();
    return results.values.any((status) => status.isGranted);
  }

  Future<void> openSettings() => openAppSettings();

  /// Ambil lagu dari MediaStore halaman demi halaman.
  ///
  /// [onProgress] dipanggil setiap halaman selesai, berisi daftar sementara
  /// yang sudah terkumpul.
  Future<List<Track>> scan({
    bool onlyMp3 = false,
    bool ignoreShortAudio = true,
    Set<String> excludedFolders = const <String>{},
    void Function(List<Track> partial)? onProgress,
  }) async {
    final result = <Track>[];
    final seenIds = <int>{};
    var offset = 0;
    var page = 1;

    while (offset < maxTracks) {
      final rows = await _queryPage(
        offset: offset,
        minDurationMs: ignoreShortAudio ? 30000 : 0,
      );
      if (rows == null) {
        BootLog.add('scan berhenti di halaman $page (data tetap dipakai)');
        break;
      }

      for (final raw in rows) {
        if (raw is! Map) continue;
        final track = Track.fromMap(raw);
        if (track.path.isEmpty) continue;
        if (track.duration <= Duration.zero) continue;
        if (ignoreShortAudio && track.duration.inSeconds < 30) continue;
        if (onlyMp3 && !_isMp3(track.path)) continue;
        if (excludedFolders.any((folder) => track.path.contains('/$folder/'))) continue;
        if (!seenIds.add(track.id)) continue;
        result.add(track);
      }

      onProgress?.call(List<Track>.unmodifiable(result));
      if (rows.length < pageSize) break;
      offset += pageSize;
      page++;
    }

    return result;
  }

  bool _isMp3(String path) {
    final lower = path.toLowerCase();
    return lower.endsWith('.mp3') || lower.contains('.mp3');
  }

  Future<List<dynamic>?> _queryPage({required int offset, required int minDurationMs}) async {
    try {
      final rows = await _media
          .invokeListMethod<dynamic>('querySongs', <String, Object?>{
            'offset': offset,
            'limit': pageSize,
            'minDurationMs': minDurationMs,
          })
          .timeout(const Duration(seconds: 25), onTimeout: () => null);
      return rows;
    } catch (error) {
      BootLog.add('scan gagal (offset $offset): $error');
      return null;
    }
  }

  /// Cover lagu, diambil dari gambar yang menempel di dalam file audio.
  ///
  /// Sengaja TIDAK memakai album art MediaStore: di Android 13 itu butuh izin
  /// foto, dan tanpa izin, sistem bisa mematikan proses app.
  Future<Uint8List?> artworkForPath(String path, {int? mediaId, int size = 300}) {
    if (path.isEmpty && mediaId == null) return Future<Uint8List?>.value();
    final key = '$path|$mediaId|$size';
    final cached = _artFutures[key];
    if (cached != null) return cached;
    if (_artFutures.length > 400) _artFutures.clear();
    final future = _loadEmbeddedArt(path, size, mediaId);
    _artFutures[key] = future;
    return future;
  }

  Future<Uint8List?> _loadEmbeddedArt(String path, int size, int? mediaId) async {
    try {
      final bytes = await _media
          .invokeMethod<Uint8List>(
            'embeddedArt',
            <String, Object?>{'path': path, 'mediaId': mediaId?.toString(), 'maxSize': size},
          )
          .timeout(const Duration(seconds: 8), onTimeout: () => null);
      return bytes;
    } catch (error) {
      if (_artErrorLogged < 3) {
        _artErrorLogged++;
        BootLog.add('cover dilewati: $error');
      }
      return null;
    }
  }

  void clearArtworkCache() => _artFutures.clear();

  /// Diagnosa: apakah berkas benar-benar bisa dibaca Android saat ini.
  Future<String> probeAudio(String path, {int? mediaId}) async {
    try {
      final result = await _media
          .invokeMethod<String>('probeAudio', <String, Object?>{
            'path': path,
            'mediaId': mediaId?.toString(),
          })
          .timeout(const Duration(seconds: 8), onTimeout: () => null);
      return result ?? 'tidak ada jawaban';
    } catch (error) {
      return 'gagal: $error';
    }
  }

  /// Laporan crash dari sesi sebelumnya (kalau ada). Ditulis native.
  Future<String?> lastCrashReport() async {
    try {
      return await _media
          .invokeMethod<String>('readCrashLog')
          .timeout(const Duration(seconds: 4), onTimeout: () => null);
    } catch (_) {
      return null;
    }
  }

  Future<void> clearCrashReport() async {
    try {
      await _media.invokeMethod<bool>('clearCrashLog');
    } catch (_) {
      // abaikan
    }
  }
}

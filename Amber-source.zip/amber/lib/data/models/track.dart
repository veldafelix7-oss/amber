import 'package:audio_service/audio_service.dart';

/// Satu lagu dari MediaStore.
class Track {
  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.path,
    required this.duration,
    required this.size,
    required this.dateAdded,
    required this.folder,
    this.albumId,
    this.trackNumber,
  });

  final int id;
  final String title;
  final String artist;
  final String album;
  final String path;
  final Duration duration;
  final int size;
  final int dateAdded;
  final String folder;
  final int? albumId;
  final int? trackNumber;

  static const String unknownArtist = 'Artis tidak dikenal';
  static const String unknownAlbum = 'Album tidak dikenal';

  String get displayArtist => artist.trim().isEmpty ? unknownArtist : artist.trim();
  String get displayAlbum => album.trim().isEmpty ? unknownAlbum : album.trim();

  /// Folder induk, mis. "Download" atau "Music".
  String get displayFolder => folder.trim().isEmpty ? 'Lainnya' : folder;

  /// Inisial buat placeholder artwork.
  String get initials {
    final words = title.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return '♪';
    if (words.length == 1) return words.first.substring(0, 1).toUpperCase();
    return words[0].substring(0, 1).toUpperCase() + words[1].substring(0, 1).toUpperCase();
  }

  /// Dibuat dari baris MediaStore (lihat querySongs di MainActivity.kt).
  factory Track.fromMap(Map<dynamic, dynamic> map) {
    final data = (map['path'] as String?) ?? '';
    final displayName = (map['displayName'] as String?) ?? '';
    final rawTitle = ((map['title'] as String?) ?? '').trim();
    final fallbackTitle = _stripExtension(displayName);
    return Track(
      id: (map['id'] as num?)?.toInt() ?? 0,
      title: rawTitle.isEmpty ? fallbackTitle : rawTitle,
      artist: ((map['artist'] as String?) ?? '').trim(),
      album: ((map['album'] as String?) ?? '').trim(),
      path: data,
      duration: Duration(milliseconds: (map['duration'] as num?)?.toInt() ?? 0),
      size: (map['size'] as num?)?.toInt() ?? 0,
      dateAdded: (map['dateAdded'] as num?)?.toInt() ?? 0,
      folder: _folderOf(data),
      albumId: (map['albumId'] as num?)?.toInt(),
      trackNumber: (map['track'] as num?)?.toInt(),
    );
  }

  static String _stripExtension(String name) {
    if (name.isEmpty) return 'Tanpa judul';
    final dot = name.lastIndexOf('.');
    final base = dot > 0 ? name.substring(0, dot) : name;
    return base.trim().isEmpty ? 'Tanpa judul' : base.trim();
  }

  static String _folderOf(String path) {
    final normalized = path.replaceAll('\\', '/');
    final parts = normalized.split('/');
    if (parts.length < 2) return '';
    return parts[parts.length - 2];
  }

  MediaItem toMediaItem() => MediaItem(
        id: '$id',
        title: title,
        artist: displayArtist,
        album: displayAlbum,
        duration: duration,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'path': path,
        'duration': duration.inMilliseconds,
        'size': size,
        'dateAdded': dateAdded,
        'folder': folder,
        'albumId': albumId,
        'trackNumber': trackNumber,
      };

  factory Track.fromJson(Map<String, dynamic> json) => Track(
        id: (json['id'] as num).toInt(),
        title: (json['title'] as String?) ?? 'Tanpa judul',
        artist: (json['artist'] as String?) ?? '',
        album: (json['album'] as String?) ?? '',
        path: (json['path'] as String?) ?? '',
        duration: Duration(milliseconds: (json['duration'] as num?)?.toInt() ?? 0),
        size: (json['size'] as num?)?.toInt() ?? 0,
        dateAdded: (json['dateAdded'] as num?)?.toInt() ?? 0,
        folder: (json['folder'] as String?) ?? '',
        albumId: (json['albumId'] as num?)?.toInt(),
        trackNumber: (json['trackNumber'] as num?)?.toInt(),
      );

  @override
  bool operator ==(Object other) => other is Track && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// Hasil pengelompokan album.
class AlbumGroup {
  const AlbumGroup({required this.name, required this.artist, required this.tracks, this.albumId});

  final String name;
  final String artist;
  final List<Track> tracks;
  final int? albumId;

  int get count => tracks.length;
  int get coverTrackId => tracks.first.id;
  Duration get totalDuration => tracks.fold(Duration.zero, (sum, t) => sum + t.duration);
}

/// Hasil pengelompokan artis.
class ArtistGroup {
  const ArtistGroup({required this.name, required this.tracks});

  final String name;
  final List<Track> tracks;

  int get count => tracks.length;
  int get albumCount => tracks.map((t) => t.displayAlbum).toSet().length;
  int get coverTrackId => tracks.first.id;
}

/// Hasil pengelompokan folder.
class FolderGroup {
  const FolderGroup({required this.name, required this.path, required this.tracks});

  final String name;
  final String path;
  final List<Track> tracks;

  int get count => tracks.length;
}

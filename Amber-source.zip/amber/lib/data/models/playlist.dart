import 'dart:convert';

/// Playlist lokal yang dibuat user.
class Playlist {
  const Playlist({
    required this.id,
    required this.name,
    required this.trackIds,
    required this.createdAt,
    this.coverTrackId,
  });

  final String id;
  final String name;
  final List<int> trackIds;
  final DateTime createdAt;
  final int? coverTrackId;

  Playlist copyWith({String? name, List<int>? trackIds, int? coverTrackId}) => Playlist(
        id: id,
        name: name ?? this.name,
        trackIds: trackIds ?? this.trackIds,
        createdAt: createdAt,
        coverTrackId: coverTrackId ?? this.coverTrackId,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'trackIds': trackIds,
        'createdAt': createdAt.millisecondsSinceEpoch,
        'coverTrackId': coverTrackId,
      };

  factory Playlist.fromJson(Map<String, dynamic> json) => Playlist(
        id: json['id'] as String,
        name: json['name'] as String? ?? 'Playlist',
        trackIds: (json['trackIds'] as List<dynamic>? ?? const <dynamic>[])
            .map((e) => (e as num).toInt())
            .toList(),
        createdAt: DateTime.fromMillisecondsSinceEpoch((json['createdAt'] as num?)?.toInt() ?? 0),
        coverTrackId: (json['coverTrackId'] as num?)?.toInt(),
      );

  static String encodeList(List<Playlist> items) =>
      jsonEncode(items.map((e) => e.toJson()).toList());

  static List<Playlist> decodeList(String? raw) {
    if (raw == null || raw.isEmpty) return const <Playlist>[];
    try {
      final data = jsonDecode(raw) as List<dynamic>;
      return data.map((e) => Playlist.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return const <Playlist>[];
    }
  }
}

/// Mode pengulangan yang dipakai UI (dipetakan ke LoopMode di audio layer).
enum RepeatMode { off, all, one }

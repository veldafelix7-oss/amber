import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme/app_palette.dart';
import 'models/playlist.dart';
import 'models/track.dart';

/// Semua data non-lagu disimpan di sini: setting, favorit, riwayat, snapshot.
class PrefsRepository {
  PrefsRepository._(this._sp);

  final SharedPreferences _sp;

  static Future<PrefsRepository> create() async {
    final sp = await SharedPreferences.getInstance();
    return PrefsRepository._(sp);
  }

  // ---------- Tampilan ----------
  ThemeMode get themeMode {
    final raw = _sp.getString('themeMode') ?? 'system';
    return switch (raw) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
  }

  Future<void> setThemeMode(ThemeMode mode) =>
      _sp.setString('themeMode', switch (mode) {
        ThemeMode.light => 'light',
        ThemeMode.dark => 'dark',
        ThemeMode.system => 'system',
      });

  AccentPreset get accent {
    final raw = _sp.getString('accent') ?? AccentPreset.oren.name;
    return AccentPreset.values.firstWhere(
      (a) => a.name == raw,
      orElse: () => AccentPreset.oren,
    );
  }

  Future<void> setAccent(AccentPreset accent) => _sp.setString('accent', accent.name);

  bool get loadArtwork => _sp.getBool('loadArtwork') ?? true;
  Future<void> setLoadArtwork(bool value) => _sp.setBool('loadArtwork', value);

  /// Penanda "sesi ini belum benar-benar sehat". Kalau app mati mendadak,
  /// nilai ini masih true saat start berikutnya → mode aman otomatis aktif.
  bool get startPending => _sp.getBool('startPending') ?? false;
  Future<void> setStartPending(bool value) => _sp.setBool('startPending', value);

  bool get blurArtwork => _sp.getBool('blurArtwork') ?? true;
  Future<void> setBlurArtwork(bool value) => _sp.setBool('blurArtwork', value);

  // ---------- Pemutaran ----------
  bool get resumeOnOpen => _sp.getBool('resumeOnOpen') ?? true;
  Future<void> setResumeOnOpen(bool v) => _sp.setBool('resumeOnOpen', v);

  bool get resumeAfterReboot => _sp.getBool('resumeAfterReboot') ?? false;
  Future<void> setResumeAfterReboot(bool v) => _sp.setBool('resumeAfterReboot', v);

  bool get handleHeadset => _sp.getBool('handleHeadset') ?? true;
  Future<void> setHandleHeadset(bool v) => _sp.setBool('handleHeadset', v);

  bool get fadeOnPause => _sp.getBool('fadeOnPause') ?? true;
  Future<void> setFadeOnPause(bool v) => _sp.setBool('fadeOnPause', v);

  // ---------- Perpustakaan ----------
  bool get ignoreShortAudio => _sp.getBool('ignoreShortAudio') ?? true;
  Future<void> setIgnoreShortAudio(bool v) => _sp.setBool('ignoreShortAudio', v);

  bool get onlyMp3 => _sp.getBool('onlyMp3') ?? false;
  Future<void> setOnlyMp3(bool v) => _sp.setBool('onlyMp3', v);

  Set<String> get excludedFolders => (_sp.getStringList('excludedFolders') ?? const <String>[]).toSet();
  Future<void> setExcludedFolders(Set<String> folders) =>
      _sp.setStringList('excludedFolders', folders.toList()..sort());

  // ---------- Notifikasi ----------
  bool get lockScreenControls => _sp.getBool('lockScreenControls') ?? true;
  Future<void> setLockScreenControls(bool v) => _sp.setBool('lockScreenControls', v);

  // ---------- Favorit & riwayat ----------
  Set<int> get favorites => (_sp.getStringList('favorites') ?? const <String>[])
      .map(int.tryParse)
      .whereType<int>()
      .toSet();

  Future<void> setFavorites(Set<int> ids) =>
      _sp.setStringList('favorites', ids.map((e) => '$e').toList());

  List<int> get recents => (_sp.getStringList('recents') ?? const <String>[])
      .map(int.tryParse)
      .whereType<int>()
      .toList();

  Future<void> pushRecent(int trackId) async {
    final list = recents..remove(trackId);
    list.insert(0, trackId);
    await _sp.setStringList('recents', list.take(20).map((e) => '$e').toList());
  }

  // ---------- Playlist ----------
  List<Playlist> get playlists => Playlist.decodeList(_sp.getString('playlists'));
  Future<void> savePlaylists(List<Playlist> items) => _sp.setString('playlists', Playlist.encodeList(items));

  // ---------- Snapshot sesi terakhir ----------
  Future<void> saveSnapshot({
    required int trackId,
    required int positionMs,
    required List<Track> queue,
    required int queueIndex,
  }) async {
    final data = <String, dynamic>{
      'trackId': trackId,
      'positionMs': positionMs,
      'queueIndex': queueIndex,
      'queue': queue.map((t) => t.toJson()).toList(),
      'savedAt': DateTime.now().millisecondsSinceEpoch,
    };
    await _sp.setString('snapshot', jsonEncode(data));
  }

  Map<String, dynamic>? get snapshot {
    final raw = _sp.getString('snapshot');
    if (raw == null || raw.isEmpty) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<void> clearSnapshot() => _sp.remove('snapshot');

  /// Jumlah lagu terakhir yang ter-scan (buat info di Settings tanpa scan ulang).
  Future<void> setLibraryStats({required int trackCount, required int totalBytes}) async {
    await _sp.setInt('libCount', trackCount);
    await _sp.setInt('libBytes', totalBytes);
  }

  int get libraryCount => _sp.getInt('libCount') ?? 0;
  int get libraryBytes => _sp.getInt('libBytes') ?? 0;
}

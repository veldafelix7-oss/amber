import 'package:amber/core/utils/format.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('format durasi', () {
    expect(Fmt.duration(const Duration(seconds: 222)), '3:42');
    expect(Fmt.duration(const Duration(seconds: 3671)), '1:01:11');
    expect(Fmt.duration(Duration.zero), '0:00');
  });

  test('format ukuran file', () {
    expect(Fmt.fileSize(0), '0 MB');
    expect(Fmt.fileSize(5 * 1024 * 1024), '5.0 MB');
  });
}

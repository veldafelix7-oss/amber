import 'package:amber/core/utils/title_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('pisahkan artis dan judul', () {
    final result = TitleParser.parse(
      'Ariana Grande - Bloodline (Official Music Video)',
      'Ariana Grande - Bloodline.mp3',
    );
    expect(result.artist, 'Ariana Grande');
    expect(result.title, 'Bloodline');
    expect(TitleParser.initials(result.title), 'BL');
  });

  test('buang penanda unduhan', () {
    final result = TitleParser.parse('adamaa_x2_mp3', 'adamaa_x2_mp3');
    expect(result.title, 'adamaa');
    expect(TitleParser.initials(result.title), 'AD');
  });

  test('artis <unknown> dianggap kosong', () {
    expect(TitleParser.isUnknownArtist('<unknown>'), isTrue);
    expect(TitleParser.isUnknownArtist(''), isTrue);
    expect(TitleParser.isUnknownArtist('Sheila On 7'), isFalse);
  });

  test('inisial dari judul, bukan potongan acak', () {
    expect(TitleParser.initials('Bloodline'), 'BL');
    expect(TitleParser.initials('Semua Tentang Kita'), 'ST');
    expect(TitleParser.initials('Hindia'), 'HI');
    expect(TitleParser.initials(''), '♪');
  });

  test('judul satu kata memakai dua huruf pertama', () {
    expect(TitleParser.initials('Alone'), 'AL');
    expect(TitleParser.initials('X'), 'X');
  });
}
